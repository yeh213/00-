// data.js - Static Content Repository

// 1. Quiz Questions (12 Questions)
// 1. Quiz Questions (30 Questions)
const quizQuestions = [
    // --- Part 1: Lifestyle (生活風格) ---
    {
        category: "Part 1: 生活風格",
        question: "1. 週末終於到了，你通常會選擇？",
        options: [
            { text: "和一群朋友去聚餐、唱歌或參加派對", score: { sales: 2, pr: 2, csm: 2, flight_attendant: 1 }, analysis: "你喜歡熱鬧與人群互動，享受社交的樂趣。" },
            { text: "待在家看書、追劇，享受一個人的時光", score: { content: 2, backend: 2, illustrator: 2, specialized_design: 1 }, analysis: "你重視獨處與內心世界，享受寧靜的充電時光。" },
            { text: "去戶外爬山、運動或是來場小旅行", score: { tour_guide: 3, fitness_coach: 2, photographer: 2, esg: 1 }, analysis: "你熱愛大自然與活動，無法忍受整天待在室內。" },
            { text: "參加工作坊或講座，充實自己的技能", score: { entrepreneur: 2, consultant: 2, projectmanager: 2, career_counselor: 1 }, analysis: "你積極進取，喜歡利用閒暇時間自我提升。" }
        ]
    },
    {
        category: "Part 1: 生活風格",
        question: "2. 旅行時，你最享受的時刻是？",
        options: [
            { text: "在飛機上或飯店裡享受被服務的感覺", score: { flight_attendant: 3, hotel_manager: 3, fnb_manager: 2, csm: 1 }, analysis: "你注重細節與體驗，懂得欣賞優質的服務。" },
            { text: "欣賞當地的特色建築、展覽與美學", score: { architect: 3, interior_design: 3, director: 2, fashion_designer: 1 }, analysis: "你對美感與空間有獨到眼光，喜歡探索文化。" },
            { text: "跟當地人聊天，了解他們的故事", score: { pr: 2, content: 2, career_counselor: 2, sales: 1 }, analysis: "你不怕生，喜歡透過人來認識這個世界。" },
            { text: "精打細算每一筆開銷，用最少錢玩最多地方", score: { accountant: 3, financial_advisor: 2, investment: 1, civil_servant: 1 }, analysis: "你精於規劃與控管資源，追求最高的 CP 值。" }
        ]
    },
    {
        category: "Part 1: 生活風格",
        question: "3. 假日有一整天的自由時間，你會選擇？",
        options: [
            { text: "去健身房重訓，或是戶外爬山運動", score: { physical_therapist: 3, firefighter: 3, police_officer: 2, fitness_coach: 3 }, analysis: "你充滿活力，喜歡挑戰體能，享受流汗的快感。" },
            { text: "畫畫、看電影、寫作，沉浸在藝術世界", score: { illustrator: 3, director: 3, fashion_designer: 2, content: 2 }, analysis: "你情感豐富，喜歡沉浸在想像與創作的流動中。" },
            { text: "研究最新的科技趨勢或寫 Side Project", score: { frontend: 2, backend: 2, devops: 2, ai: 2 }, analysis: "你對新知充滿好奇，喜歡動腦解決問題。" },
            { text: "跟朋友聚會，擴展人脈，聊聊投資機會", score: { sales: 2, investment: 3, financial_advisor: 2, entrepreneur: 2 }, analysis: "你企圖心強，重視人脈連結與未來的機會。" }
        ]
    },
    {
        category: "Part 1: 生活風格",
        question: "4. 如果要你動手做東西，你傾向？",
        options: [
            { text: "親手做一道營養均衡又美味的料理", score: { nutritionist: 3, fnb_manager: 3, veterinarian: 1, chef: 3 }, analysis: "你重視健康與生活品質，喜歡照顧他人的味蕾。" },
            { text: "自己縫製或改造一件獨一無二的衣服", score: { fashion_designer: 3, pet_groomer: 2, illustrator: 1, specialized_design: 2 }, analysis: "你手巧且有品味，喜歡創造獨特的個人風格。" },
            { text: "組裝電腦、修理壞掉的電器", score: { ic_design: 2, mechanical_engineer: 3, firmware: 2, specialized_design: 1 }, analysis: "你喜歡拆解與實作，對於機械原理很感興趣。" },
            { text: "用木頭或樂高搭建一個模型", score: { architect: 2, civil_engineer: 2, interior_design: 3, game: 1 }, analysis: "你有很好的空間概念，喜歡從無到有建構事物。" }
        ]
    },
    {
        category: "Part 1: 生活風格",
        question: "5. 你對於「動物與自然」的喜好？",
        options: [
            { text: "我超愛動物，不怕髒也不怕被咬，想天天跟牠們在一起", score: { veterinarian: 3, pet_groomer: 3, biology: 3 }, analysis: "你有無比的愛心與耐心，願意守護弱小的生命。" },
            { text: "我關心環境議題，想為地球永續盡一份力", score: { esg: 3, carbon_auditor: 3, ehs_engineer: 3, civil_servant: 1 }, analysis: "你有宏觀的視野，在乎人類與自然的共存。" },
            { text: "我喜歡大自然，但工作還是想在文明的都市裡", score: { digitalmarketing: 2, investment: 2, backend: 1, sales: 1 }, analysis: "你享受便利的現代生活，大自然是你的休閒區。" },
            { text: "我對生物結構比較感興趣，想研究生命的奧妙", score: { biotech: 3, pharmacist: 2, clinical_psychologist: 1, doctor: 2 }, analysis: "你具備科學精神，想探索生物運作的底層邏輯。" }
        ]
    },
    {
        category: "Part 1: 生活風格",
        question: "6. 當你想學習新事物時，你習慣怎麼開始？",
        options: [
            { text: "直接動手操作，從做中學，壞了再修", score: { mechanical_engineer: 3, fnb_manager: 2, ic_design: 1, chef: 2 }, analysis: "你是實戰派，相信經驗是最好的老師。" },
            { text: "先看書或找教學影片，把原理搞懂再說", score: { backend: 3, data_scientist: 2, ai: 3, civil_servant: 1 }, analysis: "你是理論派，喜歡建立完整的知識架構。" },
            { text: "找老師或教練指導，有人帶著比較快", score: { tutor: 2, hr: 2, career_counselor: 2, fitness_coach: 2 }, analysis: "你善用資源，重視效率與前人的引導。" },
            { text: "跟朋友一起組讀書會，互相討論", score: { pm: 2, csm: 2, digitalmarketing: 2, teacher: 2 }, analysis: "你喜歡透過交流與討論來激發新的想法。" }
        ]
    },
    // New Lifestyle Questions (7-10)
    {
        category: "Part 1: 生活風格",
        question: "7. 出門時，你包包裡通常一定要有？",
        options: [
            { text: "筆記本和筆，隨時記錄靈感", score: { content: 3, illustrator: 3, architect: 2, director: 2 }, analysis: "你隨時準備捕捉靈感，重視創意的積累。" },
            { text: "筆電或平板，不想與數位世界斷線", score: { frontend: 3, mobile: 3, digitalmarketing: 2, pm: 1 }, analysis: "你是重度科技使用者，工具是你的延伸。" },
            { text: "急救包、濕紙巾等備用品，以備不時之需", score: { flight_attendant: 3, hotel_manager: 2, pharmacist: 2, ehs_engineer: 2 }, analysis: "你心思細膩且周全，總能照顧到潛在需求。" },
            { text: "什麼都不帶，一支手機走天下", score: { sales: 3, entrepreneur: 2, fitness_coach: 2, creator: 2 }, analysis: "你崇尚極簡與行動力，喜歡無拘無束。" }
        ]
    },
    {
        category: "Part 1: 生活風格",
        question: "8. 你的房間通常呈現什麼狀態？",
        options: [
            { text: "極簡風格，東西很少且井然有序", score: { architect: 3, interior_design: 3, civil_servant: 2, accountant: 2 }, analysis: "你追求條理與效率，喜歡清爽的環境。" },
            { text: "雖然亂但我知道東西在哪，充滿生活感", score: { illustrator: 3, director: 2, game: 2, content: 2 }, analysis: "你是亂中有序的創意家，不拘泥於形式。" },
            { text: "有很多收藏品、模型或書本展示", score: { antique_restorer: 3, curator: 3, fashion_designer: 2, history_teacher: 2 }, analysis: "你重視物品的價值與美感，喜歡展示品味。" },
            { text: "充滿各種實用的工具或設備", score: { mechanical_engineer: 3, hardware: 3, chef: 2, firefighter: 1 }, analysis: "你是實用主義者，工欲善其事必先利其器。" }
        ]
    },
    {
        category: "Part 1: 生活風格",
        question: "9. 你比較喜歡哪種類型的電影或影集？",
        options: [
            { text: "燒腦的科幻片或懸疑推理片", score: { ai: 3, security: 3, investigative_officer: 3, judge_prosecutor: 2 }, analysis: "你熱愛智力挑戰，喜歡探索未知與真相。" },
            { text: "感人的劇情片或探討人性的電影", score: { clinical_psychologist: 3, career_counselor: 2, hr: 2, director: 2 }, analysis: "你對人性充滿好奇，擁有豐富的同理心。" },
            { text: "熱血的動作片或超級英雄電影", score: { firefighter: 3, police_officer: 3, military_officer: 2, fitness_coach: 2 }, analysis: "你崇尚正義與力量，喜歡直接的感官刺激。" },
            { text: "輕鬆的喜劇或美食旅遊節目", score: { tour_guide: 3, fnb_manager: 3, creator: 2, event_planner: 2 }, analysis: "你懂得享受生活，喜歡帶給人歡樂。" }
        ]
    },
    {
        category: "Part 1: 生活風格",
        question: "10. 買東西時，你最看重什麼？",
        options: [
            { text: "規格參數與性能表現 (CP值)", score: { hardware: 3, ic_design: 2, backend: 2, financial_advisor: 2 }, analysis: "你是理性的消費者，重視數據與實質效益。" },
            { text: "外觀設計與品牌價值", score: { brand: 3, fashion_designer: 3, ui: 2, marketing: 2 }, analysis: "你是感性的鑑賞家，重視美感與認同感。" },
            { text: "環保材質與生產過程是否永續", score: { esg: 3, csr: 3, carbon_auditor: 2, civil_servant: 1 }, analysis: "你是責任消費者，在乎選擇背後的影響。" },
            { text: "大家的評價與網紅推薦", score: { digitalmarketing: 3, pr: 2, csm: 2, sales: 1 }, analysis: "你重視口碑與社群共識，喜歡跟隨趨勢。" }
        ]
    },

    // --- Part 2: Personality (個性與價值觀) ---
    {
        category: "Part 2: 個性與價值觀",
        question: "11. 身邊有朋友心情不好或受傷，你會？",
        options: [
            { text: "很冷靜地幫他包紮傷口，或是分析病因", score: { pharmacist: 3, biotech: 2, veterinarian: 2, doctor: 2 }, analysis: "你處變不驚，能用專業與理性來解決問題。" },
            { text: "耐心傾聽他的煩惱，幫他釐清思緒", score: { clinical_psychologist: 3, career_counselor: 2, hr: 2, tutor: 1 }, analysis: "你是個很好的傾聽者，能接住他人的情緒。" },
            { text: "帶他去吃好吃的，或是做運動發洩一下", score: { nutritionist: 2, fnb_manager: 2, fitness_coach: 2, pet_groomer: 1 }, analysis: "你相信行動能轉換心情，喜歡用行動表達關心。" },
            { text: "講個笑話逗他開心，或是陪他打遊戲", score: { creator: 2, game: 1, brand: 1, content: 1 }, analysis: "你是開心果，知道如何用幽默化解低氣壓。" }
        ]
    },
    {
        category: "Part 2: 個性與價值觀",
        question: "12. 你對於「正義」與「規則」的看法？",
        options: [
            { text: "法律是道德的底線，必須嚴格執行判決", score: { judge_prosecutor: 3, lawyer: 2, civil_servant: 1, military_officer: 1 }, analysis: "你重視紀律，認為規則是維持秩序的基石。" },
            { text: "喜歡抽絲剝繭，找出隱藏在謊言背後的真相", score: { investigative_officer: 3, judge_prosecutor: 2, security: 2, journalist: 2 }, analysis: "你有偵探魂，對於挖掘真相有著執著的熱情。" },
            { text: "遇到危險或不公，我會挺身而出保護弱小", score: { police_officer: 3, firefighter: 3, military_officer: 2, lawyer: 1 }, analysis: "你充滿正義感，勇於承擔責任保護他人。" },
            { text: "規則是人定的，應該要與時俱進，適時修法", score: { civil_servant: 2, lawyer: 1, esg: 1, pr: 1 }, analysis: "你思考靈活，認為制度應當為人服務而非限制。" }
        ]
    },
    {
        category: "Part 2: 個性與價值觀",
        question: "13. 你對於「錢」的看法？",
        options: [
            { text: "錢是拿來投資滾錢的，追求財富自由", score: { investment: 3, financial_advisor: 2, blockchain: 2, entrepreneur: 1 }, analysis: "你有很好的商業頭腦，懂得利用槓桿創造價值。" },
            { text: "每一分錢都要記帳，清楚流向才安心", score: { accountant: 3, civil_servant: 2, bank_teller: 2, hr: 1 }, analysis: "你務實謹慎，擅長管理與控管風險。" },
            { text: "錢是交換價值的工具，重點是怎麼賺更多", score: { sales: 3, brand: 2, fintech: 2, entrepreneur: 2 }, analysis: "你重視開源，相信價值創造能帶來財富。" },
            { text: "夠用就好，我比較在意工作有沒有意義", score: { esg: 2, csr: 2, clinical_psychologist: 2, doctor: 1 }, analysis: "你不被物質綁架，更看重精神層面的滿足。" }
        ]
    },
    {
        category: "Part 2: 個性與價值觀",
        question: "14. 遇到意見不合或衝突時，你的反應？",
        options: [
            { text: "據理力爭，用邏輯和證據說服對方", score: { lawyer: 3, judge_prosecutor: 3, debate_coach: 2, pm: 1 }, analysis: "你邏輯清晰，堅守立場，不怕面對挑戰。" },
            { text: "安撫雙方情緒，尋找皆大歡喜的折衷方案", score: { hr: 3, pr: 3, csm: 2, mediator: 2 }, analysis: "你是和平主義者，擅長調解與整合意見。" },
            { text: "堅持自己的專業判斷，不輕易妥協", score: { director: 3, fnb_manager: 2, architect: 2, chef: 2 }, analysis: "你有專業自信，對品質與原則有堅持。" },
            { text: "我不太喜歡衝突，通常會聽從指令或默默做事", score: { administrative: 2, civil_servant: 2, librarian: 2, qa: 2 }, analysis: "你配合度高，是團隊中穩定的執行力量。" }
        ]
    },
    {
        category: "Part 2: 個性與價值觀",
        question: "15. 你最想解決哪個社會問題？",
        options: [
            { text: "氣候變遷與環境污染問題", score: { esg: 3, ehs_engineer: 3, carbon_auditor: 3, civil_engineer: 1 }, analysis: "你的眼光長遠，擔憂地球的未來。" },
            { text: "貧富差距與弱勢群體的處境", score: { csr: 3, civil_servant: 2, lawyer: 1, career_counselor: 2 }, analysis: "你有悲天憫人的心腸，想幫助被遺忘的人。" },
            { text: "流浪動物的生存權益", score: { veterinarian: 3, pet_groomer: 3, zookeeper: 2, biology: 1 }, analysis: "你認為每個生命都該被尊重與善待。" },
            { text: "假新聞氾濫與媒體識讀能力", score: { content: 2, pr: 2, high_school_teacher: 2, journalist: 3 }, analysis: "你重視真相，認為資訊正確性至關重要。" }
        ]
    },
    {
        category: "Part 2: 個性與價值觀",
        question: "16. 面對「新科技」或「新趨勢」，你的態度是？",
        options: [
            { text: "我是早期採用者 (Early Adopter)，一定要搶先嘗試", score: { blockchain: 3, ai: 3, investment: 2, trend_analyst: 2 }, analysis: "你喜歡走在時代尖端，勇於嘗試新鮮事物。" },
            { text: "我會觀察一陣子，確認有前景再投入", score: { investment: 2, pm: 2, backend: 1, strategy_manager: 2 }, analysis: "你審慎樂觀，不做沒有把握的投資。" },
            { text: "我覺得傳統工藝或經典老物比較有味道", score: { interior_design: 2, architect: 2, fashion_designer: 2, antique_restorer: 2 }, analysis: "你欣賞歷史與文化的積澱，重視原本的價值。" },
            { text: "我比較在乎穩定，不喜歡變來變去的東西", score: { civil_servant: 3, accountant: 3, hr: 2, bank_teller: 2 }, analysis: "你追求安定，認為穩定才是長久之計。" }
        ]
    },
    {
        category: "Part 2: 個性與價值觀",
        question: "17. 在團體中，你通常扮演什麼角色？",
        options: [
            { text: "負責發號施令，帶領大家往目標前進", score: { projectmanager: 3, director: 3, military_officer: 2, entrepreneur: 2 }, analysis: "你有領導風範，懂得凝聚團隊方向。" },
            { text: "負責協調溝通，確保大家氣氛融洽", score: { hr: 3, pm: 2, flight_attendant: 2, csm: 2 }, analysis: "你是團隊的潤滑劑，重視人和。" },
            { text: "負責執行細節，把分配到的任務做到完美", score: { qa: 3, accountant: 2, backend: 2, admin: 2 }, analysis: "你執行力強，是值得信賴的靠山。" },
            { text: "負責提供創意點子，當大家的智囊團", score: { marketing: 3, director: 2, brand: 2, consultant: 2 }, analysis: "你鬼點子多，總能提出令人耳目一新的想法。" }
        ]
    },
    // New Personality Questions (18-20)
    {
        category: "Part 2: 個性與價值觀",
        question: "18. 做決定時，你通常依賴什麼？",
        options: [
            { text: "客觀的數據與事實分析", score: { data_scientist: 3, dataanalysis: 3, investment: 2, scientist: 2 }, analysis: "你相信數字不說謊，追求客觀真理。" },
            { text: "直覺與當下的感受", score: { artist: 3, creator: 3, psychic: 2, fashion_designer: 2 }, analysis: "你信任自己的直覺，感性引導你的方向。" },
            { text: "詢問身邊親友或專家的意見", score: { hr: 2, pr: 2, csm: 2, student: 1 }, analysis: "你重視他人的觀點，喜歡集思廣益。" },
            { text: "過去的經驗與既有的規範", score: { civil_servant: 3, lawyer: 2, accountant: 2, history_teacher: 2 }, analysis: "你尊重傳統與經驗，傾向穩健的選擇。" }
        ]
    },
    {
        category: "Part 2: 個性與價值觀",
        question: "19. 當計畫趕不上變化，失敗了你會？",
        options: [
            { text: "立刻檢討分析原因，下次修正", score: { engineer: 2, scientist: 2, pm: 3, game: 2 }, analysis: "你有成長型思維，視失敗為學習的養分。" },
            { text: "雖然很挫折，但會找人訴苦討拍", score: { clinical_psychologist: 1, csm: 2, hr: 2, creative: 1 }, analysis: "你懂得釋放情緒，尋求支持來重新站起。" },
            { text: "不服輸，越挫越勇，再試一次", score: { entrepreneur: 3, sales: 3, athlete: 3, fire_fighter: 2 }, analysis: "你有強大的韌性，不到最後絕不放棄。" },
            { text: "山不轉路轉，直接換個目標做做看", score: { marketing: 2, creator: 3, pr: 2, startup_founder: 2 }, analysis: "你反應靈活，懂得隨機應變尋找新出路。" }
        ]
    },
    {
        category: "Part 2: 個性與價值觀",
        question: "20. 你覺得哪種特質最能代表你？",
        options: [
            { text: "聰明機智，反應快", score: { consultant: 3, lawyer: 2, comedian: 2, sales: 2 }, analysis: "你思維敏捷，能快速應對各種狀況。" },
            { text: "沈穩可靠，負責任", score: { accountant: 3, civil_servant: 3, doctor: 2, engineer: 2 }, analysis: "你穩重踏實，是大家信賴的對象。" },
            { text: "溫暖親切，好相處", score: { preschool_teacher: 3, hr: 2, nurse: 2, service: 2 }, analysis: "你心地善良，總能帶給人溫暖。" },
            { text: "獨特創新，有個性", score: { artist: 3, designer: 3, creator: 3, director: 2 }, analysis: "你與眾不同，堅持活出自己的色彩。" }
        ]
    },

    // --- Part 3: Work (職場情境) ---
    {
        category: "Part 3: 職場情境",
        question: "21. 當你瀏覽一個網站或App時，你最在意什麼？",
        options: [
            { text: "介面好不好看，動畫順不順暢", score: { ui: 3, frontend: 2, creator: 1, fashion_designer: 1 }, analysis: "你是視覺動物，在乎第一眼的美感。" },
            { text: "功能好不好用，能不能解決我的問題", score: { pm: 3, ux: 2, backend: 1, structural_engineer: 1 }, analysis: "你是實用主義者，在乎解決問題的能力。" },
            { text: "有沒有資安漏洞，我的個資安不安全", score: { security: 3, blockchain: 2, backend: 1, lawyer: 1 }, analysis: "你警覺性高，重視隱私與安全。" },
            { text: "裡面寫的文案有沒有吸引力，想不想買單", score: { digitalmarketing: 3, content: 2, sales: 1, pr: 2 }, analysis: "你容易被文字打動，也懂得如何打動人。" }
        ]
    },
    {
        category: "Part 3: 職場情境",
        question: "22. 如果要開發一款新遊戲或產品，你最想負責？",
        options: [
            { text: "設計超酷炫的角色、場景與特效", score: { game: 3, illustrator: 2, fashion_designer: 1, specialized_design: 2 }, analysis: "你想打造令人驚豔的視覺饗宴。" },
            { text: "撰寫背後的執行邏輯與程式碼", score: { backend: 3, ai: 2, cloud: 1, firmware: 2 }, analysis: "你想掌控核心運作，享受 coding 的樂趣。" },
            { text: "制定行銷策略，讓全世界都知道這個產品", score: { brand: 3, pr: 2, digitalmarketing: 1, sales: 2 }, analysis: "你想讓產品發光發熱，影響更多人。" },
            { text: "分析使用者數據，調整難度與營收模式", score: { dataanalysis: 3, investment: 1, pm: 1, business_analyst: 2 }, analysis: "你想透過數據優化產品，創造最大效益。" }
        ]
    },
    {
        category: "Part 3: 職場情境",
        question: "23. 看到路邊有大樓正在施工，你會想？",
        options: [
            { text: "這鋼骨結構安不安全？怎麼蓋才不會倒？", score: { civil_engineer: 3, architect: 2, ehs_engineer: 1, structural_engineer: 2 }, analysis: "你對結構安全有職業病，在乎穩固與否。" },
            { text: "這機械怪手是怎麼運作的？好想拆開看看", score: { mechanical_engineer: 3, firmware: 2, robotics: 2, technician: 2 }, analysis: "你對機械動力感到好奇，想一探究。" },
            { text: "未來的房價會漲多少？值得投資嗎？", score: { investment: 3, sales: 2, real_estate: 3, financial_advisor: 1 }, analysis: "你看到的是未來的增值空間與商機。" },
            { text: "好吵喔，這些噪音跟粉塵有沒有符合環保法規？", score: { civil_servant: 2, ehs_engineer: 2, esg: 1, lawyer: 1 }, analysis: "你重視生活品質與環境法規的落實。" }
        ]
    },
    {
        category: "Part 3: 職場情境",
        question: "24. 關於「教育」這件事，你比較喜歡？",
        options: [
            { text: "教小朋友認識世界，陪伴他們長大", score: { preschool_teacher: 3, elementary_teacher: 3, nanny: 2, social_worker: 2 }, analysis: "你有耐心，喜歡參與生命的啟蒙過程。" },
            { text: "傳授專業的學科知識，幫助學生升學", score: { high_school_teacher: 3, tutor: 3, professor: 2, cram_school_teacher: 2 }, analysis: "你喜歡傳道授業，幫助學生成就能量。" },
            { text: "教成人職場技能，提升他們的競爭力", score: { trainer: 3, career_counselor: 2, hr: 2, consultant: 2 }, analysis: "你想幫助他人職涯成長，創造價值。" },
            { text: "我不喜歡教人，我喜歡自己埋頭研究", score: { ic_design: 2, blockchain: 2, ai: 1, researcher: 3 }, analysis: "你適合鑽研專業，成為領域的專家。" }
        ]
    },
    {
        category: "Part 3: 職場情境",
        question: "25. 你希望未來的工作環境是？",
        options: [
            { text: "高科技實驗室或無塵室，專注研究", score: { pharmacist: 3, biotech: 3, cra: 2, ic_design: 1 }, analysis: "你喜歡安靜專注的環境，能全心投入工作。" },
            { text: "很有設計感的空間，或是可以在家工作", score: { interior_design: 2, ui: 2, creator: 2, fashion_designer: 1 }, analysis: "你需要自由與美感來激發創作靈感。" },
            { text: "嚴謹的公家機關或大企業，制度完善", score: { civil_servant: 3, hr: 2, accountant: 2, admin: 1 }, analysis: "你喜歡循規蹈矩，有明確制度讓你安心。" },
            { text: "到處跑外勤，每天都有新鮮事", score: { police_officer: 2, investigative_officer: 2, sales: 2, reporter: 2 }, analysis: "你喜歡變化與挑戰，不愛待在辦公室。" }
        ]
    },
    {
        category: "Part 3: 職場情境",
        question: "26. 你比較擅長處理「人」還是「事」？",
        options: [
            { text: "我喜歡跟人接觸，說服、談判或服務都很拿手", score: { sales: 3, pr: 3, lawyer: 2, flight_attendant: 1 }, analysis: "你是人際高手，懂得如何影響他人。" },
            { text: "我喜歡面對數據、機器或程式碼，它們不會說謊", score: { data_scientist: 3, backend: 3, security: 2, accountant: 1 }, analysis: "你相信客觀事實，喜歡與邏輯打交道。" },
            { text: "我喜歡規劃流程，確保事情按部就班完成", score: { pm: 2, civil_servant: 2, pr: 2, event_planner: 1 }, analysis: "你擅長組織與規劃，能將混亂變得有序。" },
            { text: "我喜歡憑感覺創作，不喜歡被框架限制", score: { illustrator: 3, creator: 3, fashion_designer: 2, artist: 1 }, analysis: "你跟隨直覺與靈感，討厭死板的規則。" }
        ]
    },
    {
        category: "Part 3: 職場情境",
        question: "27. 對於「時間管理」，你的工作風格是？",
        options: [
            { text: "快狠準，追求最高效率，越快做完越好", score: { investment: 2, sales: 2, pm: 2, startup_founder: 1 }, analysis: "你講求速度與結果，是效率至上者。" },
            { text: "慢工出細活，品質最重要，不惜花時間打磨", score: { fashion_designer: 3, ic_design: 2, biotech: 2, artisan: 2 }, analysis: "你是完美主義者，願意為品質把關。" },
            { text: "彈性調整，看當下狀況決定優先順序", score: { pm: 2, pr: 2, hotel_manager: 2, emergency_contact: 1 }, analysis: "你適應力強，能靈活應對各種變化。" },
            { text: "嚴格遵守排程，今日事今日畢，不喜歡拖延", score: { civil_servant: 3, accountant: 3, civil_servant: 2, admin: 1 }, analysis: "你自律甚嚴，能按部就班完成目標。" }
        ]
    },
    // New Work Questions (28-30)
    {
        category: "Part 3: 職場情境",
        question: "28. 當主管對你的工作提出批評時，你會？",
        options: [
            { text: "虛心接受，立刻思考如何改進", score: { junior_dev: 2, student: 2, civil_servant: 2, pm: 1 }, analysis: "你心態開放，願意為了成長而修正自己。" },
            { text: "提出證據解釋自己的想法，進行討論", score: { lawyer: 3, pm: 2, senior_dev: 2, consultant: 2 }, analysis: "你有主見且理性，勇於捍衛自己的專業。" },
            { text: "雖然表面接受，但心裡會不太服氣", score: { artist: 2, creative_director: 2, chef: 2, expert: 2 }, analysis: "你有傲氣與堅持，相信自己的判斷。" },
            { text: "感到沮喪，懷疑自己是不是不適合", score: { social_worker: 2, counseling: 2, administrative: 2, student: 1 }, analysis: "你自我要求高，容易對自己產生懷疑。" }
        ]
    },
    {
        category: "Part 3: 職場情境",
        question: "29. 你最討厭什麼樣的工作內容？",
        options: [
            { text: "日復一日，毫無變化的重複性工作", score: { marketing: 2, entrepreneur: 2, creator: 2, designer: 2 }, analysis: "你恐懼枯燥，渴望新鮮與變化的刺激。" },
            { text: "需要一直面對奧客，處理情緒勞動", score: { backend: 2, researcher: 2, engineer: 2, accountant: 2 }, analysis: "你偏好專注做事，不想消耗心力在人際周旋。" },
            { text: "壓力超大，隨時要待命的高壓工作", score: { librarian: 2, civil_servant: 2, administrative: 2, florist: 2 }, analysis: "你追求身心平衡，不願為了工作犧牲健康。" },
            { text: "需要複雜計算，或是邏輯太燒腦的工作", score: { sales: 2, service: 2, artist: 2, pr: 2 }, analysis: "你偏好感性或直觀的任務，不愛鑽牛角尖。" }
        ]
    },
    {
        category: "Part 3: 職場情境",
        question: "30. 想像你退休後的生活，你希望是？",
        options: [
            { text: "開一間小店或民宿，自己當老闆", score: { entrepreneur: 3, fnb_manager: 2, hotel_manager: 2, baker: 2 }, analysis: "你嚮往自由與經營的樂趣，延續夢想。" },
            { text: "環遊世界，體驗各地的文化", score: { flight_attendant: 2, tour_guide: 2, photographer: 2, writer: 2 }, analysis: "你心寬廣，想用餘生去探索世界的邊界。" },
            { text: "擔任志工或顧問，回饋社會", score: { esg: 3, csr: 3, teacher: 2, consultant: 2 }, analysis: "你退而不休，想持續發揮影響力幫助他人。" },
            { text: "在家含飴弄孫，享受簡單的平凡幸福", score: { civil_servant: 2, family_housewife: 2, admin: 2, retiree: 3 }, analysis: "你反璞歸真，懂得知足常樂的真諦。" }
        ]
    }
];

// 2. Career Details (20 Types)
const careerDetails = {
    // Tech
    'frontend': {
        title: '前端工程師 (Frontend Engineer)',
        description: '負責網站的「門面」，將設計圖變成使用者可以互動的網頁。你需要懂美感，也要懂程式邏輯。',
        tasks: ['設計網頁畫面 (HTML/CSS)', '讓按鈕會動 (JavaScript)', '串接後端資料 (API)', '優化網頁速度', '確保手機版顯示正常 (RWD)'],
        skills: ['HTML/CSS', 'JavaScript', 'React/Vue 框架', 'RWD 響應式設計', 'Git 版本控制'],
        mbti: 'ISFP, INFP, ENFP',
        quiz_analysis: '你注重細節與美感，喜歡將想法視覺化，並享受看到使用者與你創造的介面互動。你可能偏好有彈性、能發揮創意的環境，期待自己的作品能被大眾所喜愛。',
        salary: { bachelor: '40k - 55k', master: '50k - 70k' },
        companies: [{ name: 'Pinkoi', url: 'https://www.pinkoi.com/about/careers' }, { name: 'Dcard (狄卡)', url: 'https://join.dcard.tw' }],
        roadmap: ['HTML/CSS 基礎', 'JavaScript 核心', '前端框架 (React)', 'API 串接', '效能優化']
    },
    'backend': {
        title: '後端工程師 (Backend Engineer)',
        description: '網站的「大腦」，處理資料儲存、會員登入、演算法等核心邏輯。你看不到他們，但沒有他們網站就動不了。',
        tasks: ['設計資料庫 (SQL)', '撰寫伺服器邏輯 (Python/Node.js)', '資安防護', '處理高流量', 'API 設計'],
        skills: ['Python/Java', '資料庫管理', 'API 設計', 'Linux 系統', 'AWS/GCP 雲端'],
        mbti: 'INTJ, ISTJ, INTP',
        quiz_analysis: '你喜歡探究事物的本質，注重邏輯與結構，對於「看不見但至關重要」的系統運作感到著迷。比起華麗的介面，你更在乎效能、穩定性與資料的正確性。',
        salary: { bachelor: '45k - 60k', master: '55k - 75k' },
        companies: [{ name: 'LINE Taiwan (台灣連線)', url: 'https://careers.linecorp.com/jobs?ca=Taiwan' }, { name: 'Shopline (商線)', url: 'https://shopline.tw/careers' }],
        roadmap: ['程式語言基礎', '資料庫設計', 'API 開發', '伺服器部署', '系統架構設計']
    },
    'mobile': {
        title: 'App 開發工程師 (Mobile Dev)',
        description: '專門開發手機應用程式 (iOS/Android)。從滑動的手感到相機功能，都由你一手包辦。',
        tasks: ['開發 iOS/Android App', '優化 App 效能', '串接手機感測器', '上架 App Store', 'UI/UX 實作'],
        skills: ['Swift (iOS)', 'Kotlin (Android)', 'Flutter', 'UI 介面設計', 'API 串接'],
        mbti: 'ISTP, ENTP, ISFP',
        quiz_analysis: '你喜歡隨身攜帶的便利科技，對於手機 App 的互動體驗有極高的敏感度。你享受看到自己的作品被大眾在日常生活中使用，並樂於在小螢幕上創造大世界。',
        salary: { bachelor: '42k - 58k', master: '52k - 72k' },
        companies: [{ name: 'Gogoro (睿能創意)', url: 'https://www.gogoro.com/tw/careers/' }, { name: '91APP (九易宇軒)', url: 'https://www.91app.com/careers/' }],
        roadmap: ['語言基礎 (Swift/Kotlin)', 'UI 佈局', '手機硬體串接', 'App 上架流程', '跨平台開發']
    },
    'ai': {
        title: 'AI 科學家 (AI Scientist)',
        description: '訓練電腦像人一樣思考。從 ChatGPT 到自動駕駛，你正在創造未來。',
        tasks: ['訓練 AI 模型', '數據分析與清洗', '閱讀最新論文', '優化演算法', '部署 AI 服務'],
        skills: ['Python', 'PyTorch/TensorFlow', '資料探勘'],
        mbti: 'INTP, INTJ, ENTJ',
        quiz_analysis: '你充滿好奇心，喜歡挑戰未解的難題，對於「智慧」的本質有深刻的思考。你享受在數據的大海中尋找規律，並渴望用最先進的技術改變人類的未來。',
        salary: { bachelor: '50k - 70k', master: '65k - 100k+' },
        companies: [{ name: 'Appier (沛星互動)', url: 'https://www.appier.com/zh-hant/careers' }, { name: 'NVIDIA AI R&D Center', url: 'https://www.nvidia.com/zh-tw/about-nvidia/careers/' }],
        roadmap: ['數學/統計基礎', '機器學習演算法', '深度學習框架', 'NLP/CV 應用', 'MLOps']
    },
    'game': {
        title: '遊戲開發者 (Game Developer)',
        description: '創造虛擬世界的造物主。從角色移動、戰鬥系統到物理碰撞，你打造玩家的快樂體驗。',
        tasks: ['遊戲邏輯程式撰寫', '圖學渲染 (Shader)', '物理引擎調整', '效能優化', '工具開發'],
        skills: ['C# / C++', 'Unity / Unreal Engine', '3D 數學', '圖學原理'],
        mbti: 'INTP, ENTP, ISTP',
        quiz_analysis: '你擁有一顆赤子之心，夢想著創造出讓人沉浸其中的虛擬世界。你結合了技術與創意，享受每一個互動細節帶來的樂趣，並希望能為玩家帶來感動或快樂。',
        salary: { bachelor: '38k - 55k', master: '48k - 65k' },
        companies: [{ name: 'Rayark (雷亞遊戲)', url: 'https://www.rayark.com/zh/jobs/' }, { name: 'Garena', url: 'https://careers.garena.com/' }],
        roadmap: ['程式語言 (C#/C++)', '遊戲引擎 (Unity/Unreal)', '3D 數學與物理', '遊戲設計模式', '多人連線開發']
    },
    'cloud': {
        title: '雲端架構師 (Cloud Architect)',
        description: '設計能承載百萬人的雲端系統。你需要懂 AWS/GCP，也要懂如何省錢又高效。',
        tasks: ['規劃雲端架構', '成本控管', '災難備援設計', '自動化部署', '容器化管理'],
        skills: ['AWS / GCP / Azure', 'Docker / Kubernetes', '網路架構', 'IaC (Terraform)'],
        mbti: 'ISTJ, INTJ, ESTJ',
        quiz_analysis: '你具有宏觀的視野，擅長規劃與佈局。你喜歡建構龐大而穩定的系統，享受掌控全局的感覺，並致力於讓資源利用達到最佳化。',
        salary: { bachelor: '45k - 65k', master: '60k - 85k' },
        companies: [{ name: 'Trend Micro (趨勢科技)', url: 'https://www.trendmicro.com/zh_tw/about/careers.html' }, { name: 'KKCompany', url: 'https://careers.kkcompany.com/' }],
        roadmap: ['網路基礎', 'Linux 系統管理', '雲端平台證照', '容器化技術', '架構設計模式']
    },
    'security': {
        title: '資安工程師 (Security Engineer)',
        description: '網路世界的保全。尋找系統漏洞、抵禦駭客攻擊，保護使用者的資料安全。',
        tasks: ['滲透測試', '漏洞掃描', '資安事件處理', '惡意程式分析', '安全架構審查'],
        skills: ['網路協定', '逆向工程', 'Cryptography', 'Scripting (Python/Bash)'],
        mbti: 'INTJ, ISTP, ESTJ',
        quiz_analysis: '你具有敏銳的觀察力與懷疑精神，喜歡找出系統中的破綻。你享受攻防之間的智力較量，並對於守護重要的資產與隱私感到使命感。',
        salary: { bachelor: '45k - 60k', master: '55k - 80k' },
        companies: [{ name: 'TeamT5 (杜浦數位安全)', url: 'https://teamt5.org/tw/careers/' }, { name: 'CyCraft (奧義智慧)', url: 'https://www.cycraft.com/zh-hant/careers' }],
        roadmap: ['網路與系統基礎', '常見漏洞原理', '滲透測試工具', '資安證照 (CEH/OSCP)', '攻防演練實戰']
    },
    'blockchain': {
        title: '區塊鏈工程師 (Blockchain Eng)',
        description: '開發去中心化應用 (DApp) 或智能合約。這是 Web3 的核心，充滿機會與挑戰。',
        tasks: ['撰寫智能合約 (Solidity)', 'DApp 前後端開發', '共識演算法研究', '資安審計', '鏈上數據分析'],
        skills: ['Solidity / Rust', 'Cryptography', 'Web3.js / Ethers.js', 'Smart Contract Security'],
        mbti: 'INTJ, INTP, ENTJ',
        quiz_analysis: '你是新科技的信徒，對於去中心化與價值互聯網的概念深信不疑。你勇於探索未知的領域，挑戰傳統的體制，並渴望用程式碼建立信任的新機制。',
        salary: { bachelor: '55k - 75k', master: '70k - 100k+' },
        companies: [{ name: 'MaiCoin', url: 'https://www.maicoin.com/careers' }, { name: 'Binance', url: 'https://www.binance.com/en/careers' }],
        roadmap: ['區塊鏈原理', '智能合約開發', 'DApp 整合', '密碼學基礎', 'DeFi/NFT 應用']
    },
    'devops': {
        title: 'DevOps 工程師',
        description: '開發與維運的橋樑。負責自動化流程 (CI/CD)，讓程式碼能順利且穩定地上線。',
        tasks: ['建立 CI/CD 流程', '監控系統狀態', '自動化腳本撰寫', '除錯與維護', '協助開發流程順暢'],
        skills: ['Jenkins / GitLab CI', 'Docker / K8s', 'Linux', 'Scripting'],
        mbti: 'ESTJ, ISTJ, ENTP',
        quiz_analysis: '你喜歡追求效率與自動化，討厭重複無效的勞動。你擅長協調與串接不同的環節，確保軟體從開發到交付的過程如流水般順暢穩定。',
        salary: { bachelor: '50k - 65k', master: '60k - 85k' },
        companies: [{ name: '91APP', url: 'https://www.91app.com/careers/' }, { name: 'KKday', url: 'https://careers.kkday.com/' }],
        roadmap: ['Linux 基礎', '版控與 CI/CD', '容器化技術', '雲端服務管理', '監控與日誌系統']
    },
    'qa': {
        title: '軟體測試工程師 (QA Engineer)',
        description: '產品品質的守門員。設計測試案例，找出潛在的 Bug，確保使用者有好的體驗。',
        tasks: ['撰寫測試計畫', '執行手動/自動化測試', '追蹤 Bug 修復', '壓力測試', '確保產品品質'],
        skills: ['測試自動化 (Selenium)', 'Bug Tracking (Jira)', 'Scripting', '細心與邏輯'],
        mbti: 'ISFJ, ISTJ, ESFJ',
        quiz_analysis: '你細心、嚴謹，對於細節有著超乎常人的堅持。你無法容忍瑕疵的存在，喜歡系統性地檢查與驗證，確保出手的產品具有最高品質。',
        salary: { bachelor: '40k - 55k', master: '50k - 70k' },
        companies: [{ name: 'Shopee (蝦皮)', url: 'https://careers.shopee.tw/' }, { name: 'Synology (群暉)', url: 'https://www.synology.com/zh-tw/company/career' }],
        roadmap: ['軟體測試概念', '測試案例設計', '自動化測試工具', 'API 測試', '效能測試']
    },

    // Design
    'ui': {
        title: 'UI 設計師 (UI Designer)',
        description: '專注於產品的視覺呈現。顏色、排版、按鈕樣式，確保介面美觀且符合品牌形象。',
        tasks: ['繪製介面設計圖', '建立 Design System', '設計 Icon 與插圖', '與工程師溝通實作', 'Prototype 製作'],
        skills: ['Figma/Sketch', '色彩學', '字體排印', '排版佈局', '微互動'],
        mbti: 'ISFP, INFP, INFJ',
        quiz_analysis: '你對美感有著極高的敏銳度，並且在意使用者的感受。你擅長運用色彩與排版來說故事，致力於創造出既美觀又易用的數位產品，讓每一次的點擊都是享受。',
        salary: { bachelor: '35k - 50k', master: '45k - 60k' },
        companies: [{ name: 'Pinkoi', url: 'https://www.pinkoi.com/about/careers' }, { name: 'GoShare (睿能創意)', url: 'https://www.ridegoshare.com' }],
        roadmap: ['設計基礎 (色彩/排版)', '設計軟體 (Figma)', 'Design System', '動效設計', '切版概念']
    },
    'ux': {
        title: 'UX 研究員 (UX Researcher)',
        description: '挖掘使用者的潛在需求。透過訪談、數據分析，設計出好用且流暢的產品流程。',
        tasks: ['使用者訪談', '可用性測試', '繪製 Wireframe', '分析使用者數據', '優化操作流程'],
        skills: ['使用者研究', '線框圖繪製', '邏輯流程', '心理學', '數據分析'],
        mbti: 'INFJ, ENFJ, INTP',
        quiz_analysis: '你對人類的行為與心理充滿好奇，喜歡探究「為什麼」。你擅長透過訪談與數據挖掘使用者的真實需求，並將這些洞察轉化為更好的產品體驗，是使用者的代言人。',
        salary: { bachelor: '38k - 55k', master: '48k - 65k' },
        companies: [{ name: 'Shopee TW (蝦皮購物)', url: 'https://careers.shopee.tw' }, { name: 'AJA Creative (大予)', url: 'https://www.aja.com.tw' }],
        roadmap: ['使用者心理學', '訪談與測試技巧', 'Wireframe 繪製', '資訊架構 (IA)', '數據驅動設計']
    },

    // Data & PM
    'dataanalysis': {
        title: '數據分析師 (Data Analyst)',
        description: '從雜亂的數據中找出黃金。用數據說故事，幫助公司做出正確的商業決策。',
        tasks: ['資料視覺化', '製作報表 (Dashboard)', 'SQL 撈取資料', '商業邏輯分析', '預測市場趨勢'],
        skills: ['SQL', 'Excel', 'Tableau/PowerBI', '統計學', 'Python'],
        mbti: 'ISTJ, INTP, ENTJ',
        quiz_analysis: '你對數字極為敏感，相信數據背後隱藏著客觀的真理。你喜歡從龐大的資料中抽絲剝繭，找出關鍵的洞察與趨勢，為商業決策提供最堅實的科學依據。',
        salary: { bachelor: '40k - 55k', master: '50k - 70k' },
        companies: [{ name: 'Momo (富邦媒)', url: 'https://www.momoshop.com.tw' }, { name: 'Gogoro (睿能創意)', url: 'https://www.gogoro.com/tw/careers/' }],
        roadmap: ['Excel 與統計', 'SQL 資料庫查詢', '視覺化工具 (Tableau)', '商業分析思維', 'Python 資料處理']
    },
    'pm': {
        title: '產品經理 (Product Manager)',
        description: '產品的 CEO。負責規劃產品藍圖，協調設計與工程，確保產品準時上線且符合市場需求。',
        tasks: ['制定產品規格 (PRD)', '畫 Wireframe', '專案時程管理', '跨部門溝通', '分析用戶回饋'],
        skills: ['溝通能力', '專案管理', '邏輯思維', '線框圖繪製', '數據敏感度'],
        mbti: 'ENTJ, ENFJ, ESTJ',
        quiz_analysis: '你擁有宏觀的視野與清晰的羅輯，擅長整合資源與溝通協調。你享受將一個模糊的概念打磨成具體的產品，並帶領團隊克服困難，實現產品的市場價值。',
        salary: { bachelor: '40k - 60k', master: '50k - 80k' },
        companies: [{ name: 'KKday (酷遊)', url: 'https://www.kkday.com/zh-tw/careers' }, { name: 'Dcard (狄卡)', url: 'https://join.dcard.tw' }],
        roadmap: ['需求分析能力', '專案管理 (Agile)', '原型繪製', '數據分析基礎', '產品策略思維']
    },
    'projectmanager': {
        title: '專案經理 (Project Manager)',
        description: '確保事情被完成的人。控管時間、成本、品質，解決專案過程中的所有障礙。',
        tasks: ['時程規劃 (Gantt Chart)', '風險管理', '資源分配', '主持會議', '利害關係人溝通'],
        skills: ['PMP 證照', '溝通能力', '風險管理', 'Jira/Trello', '領導力'],
        mbti: 'ESTJ, ENTJ, ISTJ',
        quiz_analysis: '你是天生的執行者與規劃家，擅長在變動的環境中建立秩序。你重視效率與目標達成，能夠冷靜應對各種突發狀況，排除萬難確保專案如期如質完成。',
        salary: { bachelor: '38k - 55k', master: '48k - 70k' },
        companies: [{ name: 'ASUS (華碩)', url: 'https://www.asus.com/tw/employment/' }, { name: 'Wistron (緯創)', url: 'https://www.wistron.com' }],
        roadmap: ['專案管理流程', '溝通與談判', '風險評估', '敏捷開發 (Scrum)', 'PMP 證照']
    },

    // Marketing
    'digitalmarketing': {
        title: '數位行銷 (Digital Marketing)',
        description: '網路世界的推銷員。操作 FB/Google 廣告，分析數據，用最少的預算帶來最大的流量。',
        tasks: ['廣告投放 (Ads)', '社群經營', '成效分析 (GA4)', '活動企劃', 'SEO 優化'],
        skills: ['Google Ads 廣告', 'Facebook Ads 廣告', 'Google Analytics 分析', '文案撰寫', '創意發想'],
        mbti: 'ENFP, ENTP, ESFP',
        quiz_analysis: '你反應靈敏，對市場趨勢有著獵犬般的嗅覺。你擅長透過數據與創意來吸引目光，享受在瞬息萬變的網路世界中操盤，看著流量與成效節節攀升的快感。',
        salary: { bachelor: '35k - 50k', master: '42k - 60k' },
        companies: [{ name: 'Ogilvy TW (奧美)', url: 'https://www.ogilvy.com/tw' }, { name: 'Dentsu TW (電通)', url: 'https://www.dentsu.com/tw/zh' }],
        roadmap: ['行銷基礎與文案', '社群媒體經營', '廣告投放操作', '數據分析 (GA4)', '行銷策略規劃']
    },
    'content': {
        title: '內容創作者 (Content Creator)',
        description: '用文字、影音說故事的人。如果你喜歡拍片、寫文章，並能引起共鳴，這就是你的舞台。',
        tasks: ['腳本撰寫', '影片拍攝剪輯', '社群貼文製作', '網紅媒合', '流量操作'],
        skills: ['影片剪輯', '文案撰寫', '說故事能力', '攝影技巧', '趨勢敏感度'],
        mbti: 'ENFP, ISFP, INFP',
        quiz_analysis: '你擁有豐富的創造力與情感，擅長用故事打動人心。你喜歡將腦中的創意轉化為文字或影像，享受創作過程中的心流，並期待你的作品能引起廣大迴響。',
        salary: { bachelor: '32k - 45k', master: '38k - 55k' },
        companies: [{ name: 'Taiwan Bar (臺灣吧)', url: 'https://taiwanbar.cc' }, { name: 'PressPlay (瑞奧)', url: 'https://www.pressplay.cc' }],
        roadmap: ['腳本與文案', '攝影與剪輯', '社群互動技巧', '個人品牌經營', '創意變現模式']
    },
    'seo': {
        title: 'SEO 專員 (SEO Specialist)',
        description: '讓網站在 Google 搜尋第一頁的魔術師。研究關鍵字，優化網站結構，帶來免費流量。',
        tasks: ['關鍵字研究', '網站架構優化', '內容優化', '連結建設', '搜尋排名監控'],
        skills: ['關鍵字研究', '技術 SEO', '內容策略', '連結建設', 'HTML 基礎'],
        mbti: 'ISTJ, INTP, INTJ',
        quiz_analysis: '你具備分析思維與耐心，喜歡鑽研規則背後的邏輯。你像是一位網路世界的軍師，透過精準的策略與長期的佈局，讓品牌在搜尋引擎的戰場上攻佔高地。',
        salary: { bachelor: '38k - 52k', master: '45k - 65k' },
        companies: [{ name: 'awoo (阿物)', url: 'https://awoo.ai' }, { name: 'Ranking (樂客)', url: 'https://ranking.works' }],
        roadmap: ['搜尋引擎原理', '關鍵字策略', '內容優化 (On-page)', '技術優化 (Technical)', '數據分析與報表']
    },

    // Business
    'sales': {
        title: '業務開發 (BD / Sales)',
        description: '公司的狩獵部隊。尋找潛在客戶，談判合約，將公司的產品賣出去，為公司帶進營收。',
        tasks: ['開發陌生客戶', '產品簡報', '合約談判', '維持客戶關係', '市場調查'],
        skills: ['談判技巧', '溝通能力', '簡報技巧', '市場調查', 'CRM系統'],
        mbti: 'ESTP, ESFJ, ENFJ',
        quiz_analysis: '你充滿行動力與野心，喜歡挑戰高目標。你擅長與人建立連結，擁有極佳的說服力與談判技巧，享受在競爭激烈的市場中攻城掠地，創造實質業績的成就感。',
        salary: { bachelor: '35k + Bonus', master: '45k + Bonus' },
        companies: [{ name: 'Gogoro (睿能創意)', url: 'https://www.gogoro.com' }, { name: 'iChef (資廚)', url: 'https://www.ichefpos.com/zh-tw/career' }],
        roadmap: ['溝通與銷售技巧', '客戶關係管理', '談判與成交', '市場開發策略', '高階顧問式銷售']
    },
    'csm': {
        title: '客戶成功經理 (CSM)',
        description: '這不是客服，而是顧問。你幫助已經購買的客戶用得更好，確保他們續約並推薦給別人。',
        tasks: ['客戶教育訓練', '解決使用問題', '提升續約率', '收集產品回饋', '策略建議'],
        skills: ['同理心', '解決問題', '產品知識', '溝通能力', '數據分析'],
        mbti: 'ESFJ, ENFJ, ISFJ',
        quiz_analysis: '你樂於助人與分享，在意他人的滿意度與成功。你擅長維護長期的合作關係，能夠深入理解客戶的痛點並提供解決方案，是客戶最信任的長期夥伴。',
        salary: { bachelor: '38k - 55k', master: '48k - 65k' },
        companies: [{ name: '91APP (九易宇軒)', url: 'https://www.91app.com' }, { name: 'Gogolook (走著瞧)', url: 'https://gogolook.com' }],
        roadmap: ['產品深度掌握', '客戶溝通技巧', '問題解決能力', '數據分析與洞察', '客戶保留策略']
    },
    'hr': {
        title: '人資/招募 (HR / Recruiter)',
        description: '企業的星探與保母。挖掘頂尖人才，建立良好的公司文化，照顧員工的薪資福利。',
        tasks: ['面試篩選', '招募管道經營', '薪酬計算', '員工教育訓練', '績效考核'],
        skills: ['面試技巧', '勞動法令', '溝通能力', '人才數據分析', '同理心'],
        mbti: 'ESFJ, ENFJ, INFJ',
        quiz_analysis: '你喜歡與人互動，善於傾聽與觀察。你關心他人的福祉，並且有極佳的溝通協調能力，願意成為團隊中溫暖的支持力量。',
        salary: { bachelor: '35k - 50k', master: '42k - 60k' },
        companies: [{ name: '104 Corp (人力銀行)', url: 'https://corp.104.com.tw' }, { name: 'Yourator (新創求職)', url: 'https://www.yourator.co' }],
        roadmap: ['招募與面試技巧', '勞動法令基礎', '薪酬福利制度', '績效管理', '組織文化發展']
    },

    // Impact
    'esg': {
        title: 'ESG 顧問 (ESG Consultant)',
        description: '企業的綠色醫生。診斷公司的碳排放與社會責任表現，提出改進策略，撰寫永續報告書。',
        tasks: ['撰寫 ESG 報告', '碳盤查計算', '永續策略規劃', '供應鏈管理', '法規研究'],
        skills: ['永續發展', '報告撰寫', '碳盤查', '法規研究', '簡報技巧'],
        mbti: 'INFJ, ENFJ, INTJ',
        quiz_analysis: '你關心社會與環境議題，擁有宏觀的視野與使命感。你希望透過企業的力量來改善世界，並且具備分析問題與推動改變的策略思考能力。',
        salary: { bachelor: '42k - 60k', master: '50k - 75k' },
        companies: [{ name: 'PwC TW (資誠)', url: 'https://www.pwc.tw' }, { name: 'KPMG TW (安侯)', url: 'https://home.kpmg/tw/zh/home.html' }],
        roadmap: ['永續發展概論', 'GRI/SASB 準則', '碳排計算 (ISO)', '永續報告撰寫', '企業轉型策略']
    },
    'csr': {
        title: 'CSR 專員 (CSR Specialist)',
        description: '企業的親善大使。負責規劃公益活動、志工日、偏鄉教育，建立公司的良好社會形象。',
        tasks: ['公益活動企劃', '非營利組織合作', '志工招募管理', '成效評估', '內部溝通'],
        skills: ['活動企劃', '溝通能力', '專案管理', '同理心', '寫作能力'],
        mbti: 'ENFJ, ESFJ, INFP',
        quiz_analysis: '你充滿愛心與熱忱，喜歡投身於公益與社會服務。你擅長連結資源與人脈，並享受看到你的付出為他人帶來溫暖與幫助。',
        salary: { bachelor: '35k - 48k', master: '42k - 55k' },
        companies: [{ name: 'Cathay Financial (國泰金)', url: 'https://www.cathayhomemyhome.com.tw' }, { name: 'Delta (台達電)', url: 'https://www.deltaww.com' }],
        roadmap: ['活動企劃與執行', 'NPO 合作模式', '專案管理', '公關與媒體溝通', '社會影響力評估']
    },
    'carbon_auditor': {
        title: '碳審計師 (Carbon Auditor)',
        description: '氣候變遷的精算師。專門計算與驗證企業的碳排放數據，協助企業取得國際認證，邁向淨零碳排。',
        tasks: ['溫室氣體盤查', '碳足跡計算', '第三方查證', '減碳效益評估', '能源稽核'],
        skills: ['ISO 14064', 'GHG Protocol', '稽核技巧', '數據分析', '法規研究'],
        mbti: 'ISTJ, ESTJ, INTJ',
        quiz_analysis: '你心思縝密，對於數據與標準有著極高的要求。你像是環境的會計師，運用專業知識確保每一個數字的準確，為地球的永續發展把關。',
        salary: { bachelor: '45k - 60k', master: '55k - 80k' },
        companies: [{ name: 'BSI (英國標準協會)', url: 'https://www.bsigroup.com/zh-TW/' }, { name: 'SGS (台灣檢驗)', url: 'https://www.sgs.com.tw' }],
        roadmap: ['環境工程基礎', 'ISO 查證員課程', '能源管理系統', '碳權交易機制', '企業永續策略']
    },

    // --- New: Hardware ---
    'ic_design': {
        title: 'IC 設計工程師 (IC Design Engineer)',
        description: '晶片的建築師。使用硬體描述語言 (Verilog) 設計電路邏輯，將數億個電晶體塞進指甲大小的晶片中。',
        tasks: ['電路規格制定', 'RTL 程式撰寫', '電路模擬驗證', 'FPGA 原型測試', '晶片除錯'],
        skills: ['Verilog/VHDL', 'C/C++', '數位電路', 'FPGA', 'Linux 系統'],
        mbti: 'INTJ, INTP, ISTP',
        quiz_analysis: '你擁有極強的邏輯思維與微觀視野，能夠在肉眼看不見的世界裡建構複雜而精密的迷宮。你追求極致的效能與精序，願意為了突破物理極限而投入心血。',
        salary: { bachelor: '70k - 90k', master: '90k - 120k+' },
        companies: [{ name: 'MediaTek (聯發科)', url: 'https://careers.mediatek.com' }, { name: 'Realtek (瑞昱)', url: 'https://www.realtek.com/zh-tw/careers' }],
        roadmap: ['數位邏輯設計', 'Verilog 語法', '計算機結構', 'IC 設計流程 (APR)', '系統晶片 (SoC) 架構']
    },
    'firmware': {
        title: '韌體工程師 (Firmware Engineer)',
        description: '軟硬體的翻譯官。撰寫控制硬體的底層程式，讓晶片能夠聽懂指令並開始運作。',
        tasks: ['驅動程式開發', 'MCU 程式設計', '硬體周邊控制 (I2C/SPI)', '系統效能調校', 'Board Bring-up'],
        skills: ['C 語言', '組合語言', 'MCU 微控制器', '作業系統原理', '電路圖閱讀'],
        mbti: 'ISTP, INTP, ISTJ',
        quiz_analysis: '你是軟體與硬體的橋樑，擅長掌控機器的靈魂。你務實且邏輯清晰，喜歡看得到、摸得到的成果，享受用程式碼讓冰冷的金屬動起來的成就感。',
        salary: { bachelor: '55k - 75k', master: '70k - 95k' },
        companies: [{ name: 'ASUS (華碩)', url: 'https://www.asus.com/tw/employment/' }, { name: 'Garmin (台灣國際航電)', url: 'https://www.garmin.com/zh-TW/careers/' }],
        roadmap: ['C 語言指標與記憶體', '微處理機原理', '通訊協定 (UART/I2C)', 'RTOS 即時作業系統', 'Linux Kernel']
    },
    'process': {
        title: '製程工程師 (Process Engineer)',
        description: '晶片良率的守護者。在無塵室中監控與改善生產流程，解決機台與製程的各種疑難雜症。',
        tasks: ['製程參數設定', '良率分析與改善', '異常產品處理', '新製程導入', '跨部門溝通'],
        skills: ['物理/化學', '數據分析', 'SPC 統計製程管制', '解決問題', 'JMP/Excel 分析'],
        mbti: 'ISTJ, ESTJ, INTJ',
        quiz_analysis: '你擅長從繁雜的數據中尋找蛛絲馬跡，追求生產流程的完美與穩定。你像是一位精密工廠的醫生，運用科學方法診斷問題，確保每一顆晶片都能健康出廠。',
        salary: { bachelor: '50k - 65k', master: '65k - 85k' },
        companies: [{ name: 'TSMC (台積電)', url: 'https://www.tsmc.com' }, { name: 'Micron (美光)', url: 'https://tw.micron.com' }],
        roadmap: ['半導體物理', '單元製程 (黃光/蝕刻)', '統計分析工具', '實驗設計 (DOE)', '良率提升工程']
    },
    'equipment': {
        title: '設備工程師 (Equipment Engineer)',
        description: '機台的守護神。負責半導體機台的安裝、維護與故障排除，確保生產線 24 小時不停機。',
        tasks: ['機台定期保養 (PM)', '突發當機處理', '零件庫存管理', '機台效能改善 (CIP)', '輪班與供應商溝通'],
        skills: ['機台維修', '電路圖閱讀', '氣壓/油壓原理', '英文手冊閱讀', '溝通能力'],
        mbti: 'ISTP, ESTP, ISTJ',
        quiz_analysis: '你喜歡動手解決實際問題，不畏懼面對龐大的機器巨獸。你擁有冷靜的頭腦與靈巧的雙手，是維持高科技工廠運轉不可或缺的急救醫生。',
        salary: { bachelor: '55k - 75k', master: '65k - 90k' },
        companies: [{ name: 'TSMC (台積電)', url: 'https://www.tsmc.com' }, { name: 'ASML', url: 'https://www.asml.com' }],
        roadmap: ['基礎電子電路', '機構原理', '氣/油壓系統', '半導體設備訓練', '設備改善專案']
    },
    'integration': {
        title: '製程整合工程師 (Integration Eng.)',
        description: '製程的指揮家。串聯黃光、蝕刻、擴散等各個模組，優化整體生產流程，提升晶片良率。',
        tasks: ['產品良率分析', '設定製程流程', '跨部門溝通協調', '異常產品處理', '客戶技術支援'],
        skills: ['Semiconductor Physics', '良率分析', '邏輯思考', '溝通協調', 'JMP/Excel 分析'],
        mbti: 'ENTJ, INTJ, ESTJ',
        quiz_analysis: '你擁有宏觀的視野與強大的整合能力，能在複雜的生產流程中找出最佳化的路徑。你是溝通的橋樑，也是問題的終結者，確保每一片晶圓都能完美產出。',
        salary: { bachelor: '60k - 80k', master: '75k - 100k+' },
        companies: [{ name: 'TSMC (台積電)', url: 'https://www.tsmc.com' }, { name: 'UMC (聯電)', url: 'https://www.umc.com' }],
        roadmap: ['Semiconductor Physics', 'VLSI 製程技術', 'SPC 統計製程管制', '良率分析技術', '專案管理']
    },
    'process_rd': {
        title: '半導體研發工程師 (R&D Engineer)',
        description: '未來科技的開拓者。探索新材料、新架構 (如 GAA, 2nm)，突破物理極限，定義下一世代的晶片技術。',
        tasks: ['先進製程開發', '新材料研究', 'TCAD 模擬', '專利佈局', '國際論文發表'],
        skills: ['Solid State Physics', 'Quantum Mechanics', 'TCAD', 'English Writing', 'Innovation'],
        mbti: 'INTP, INTJ, ENTP',
        quiz_analysis: '你對未知充滿好奇，擁有深厚的科學底蘊與挑戰極限的勇氣。你致力於在原子尺度上進行雕刻，每一個微小的突破，都將引領人類科技邁向新的紀元。',
        salary: { bachelor: 'N/A', master: '85k - 120k+', phd: '120k - 150k+' },
        companies: [{ name: 'TSMC (台積電)', url: 'https://www.tsmc.com' }, { name: 'Intel', url: 'https://www.intel.com' }],
        roadmap: ['Quantum Mechanics', 'Advanced Devices', 'TCAD 模擬工具', 'Patent Analysis', 'Paper Writing']
    },


    // --- New: Medical ---
    'pharmacist': {
        title: '藥師 (Pharmacist)',
        description: '用藥安全的守門員。不僅是配藥，更需審核處方、提供藥物諮詢，確保病人正確用藥不發生副作用。',
        tasks: ['處方調劑', '用藥諮詢', '庫存管理', '藥物交互作用檢查', '衛教宣導'],
        skills: ['藥理學', '病人照護品質', '細心謹慎', '溝通能力', '專業執照'],
        mbti: 'ISFJ, ISTJ, ESFJ',
        quiz_analysis: '你細心、負責，對於「正確性」有著不可妥協的堅持。你樂於運用專業知識協助他人，是大家眼中值得信賴的健康顧問，守護著病人的用藥安全。',
        salary: { bachelor: '60k - 80k', master: '70k - 90k' },
        companies: [{ name: 'Medical Center (各大醫學中心)', url: '#' }, { name: 'Watsons (屈臣氏)', url: 'https://www.watsons.com.tw' }],
        roadmap: ['藥理學基礎', '國家藥師執照考取', '醫院實習', '臨床藥學', '藥事行政管理']
    },
    'biotech': {
        title: '生技研究員 (Biotech Researcher)',
        description: '生命的探索者。在實驗室中研發新藥、疫苗或檢測技術，將科學發現轉化為拯救生命的產品。',
        tasks: ['實驗設計與執行', '數據分析', '細胞/微生物培養', '文獻探討', '專利申請'],
        skills: ['分子生物學', '實驗技術', '數據分析', '英文閱讀', '論文寫作'],
        mbti: 'INTP, INTJ, ISTJ',
        quiz_analysis: '你對於生命的奧秘充滿好奇，喜歡在實驗室裡探索未知的領域。你具備科學家的嚴謹精神，願意投入長時間的研發，期盼能為人類醫療帶來突破。',
        salary: { bachelor: '40k - 55k', master: '50k - 70k' },
        companies: [{ name: 'TaiMed (中裕新藥)', url: '#' }, { name: 'Adimmune (國光生技)', url: '#' }],
        roadmap: ['生物化學/分生', '實驗室操作規範', '實驗數據統計', '學術論文發表', '轉譯醫學']
    },
    'cra': {
        title: '臨床試驗專員 (CRA)',
        description: '新藥上市的推進器。負責監督臨床試驗的進行，確保數據準確且符合法規與倫理，保障受試者權益。',
        tasks: ['試驗案監測 (Monitoring)', '文件審核', '醫院協調', '法規遵循確認', '副作用通報'],
        skills: ['GCP 臨床試驗規範', '溝通能力', '細心謹慎', '醫學知識', '英文能力'],
        mbti: 'ISTJ, ESTJ, ISFJ',
        quiz_analysis: '你擅長專案管理與溝通協調，能夠穿梭在醫院與藥廠之間，確保複雜的臨床試驗順利進行。你一絲不苟的態度，是新藥安全上市最重要的保障。',
        salary: { bachelor: '45k - 60k', master: '55k - 75k' },
        companies: [{ name: 'IQVIA', url: 'https://www.iqvia.com' }, { name: 'Syneos Health', url: 'https://www.syneoshealth.com' }],
        roadmap: ['醫藥相關背景', 'GCP 證書', '臨床研究助理 (CRA)', '專案管理能力', '跨國試驗管理']
    },

    // --- New: Education ---
    'elementary_teacher': {
        title: '國小老師 (Elementary Teacher)',
        description: '孩子的啟蒙導師。這不僅是教學，更是班級經營與生活常規的養成，像第二個父母般陪伴孩子成長。',
        tasks: ['全科教學 (包班)', '班級經營', '親師溝通', '學生輔導', '作業批改'],
        skills: ['班級經營', '耐心', '溝通能力', '學科教學', '兒童發展'],
        mbti: 'ESFJ, ISFJ, ENFJ',
        quiz_analysis: '你喜愛孩子，擁有一顆包容與溫暖的心。你享受陪伴他人成長的過程，願意花時間引導與教育，對於塑造孩子的未來充滿使命感。',
        salary: { bachelor: '40k - 60k', master: '48k - 70k' },
        companies: [{ name: 'Public Schools (公立國小)', url: '#' }, { name: 'Private Schools (私立小學)', url: '#' }],
        roadmap: ['修習教育學分', '教師檢定考', '半年教育實習', '教師甄試 (教甄)', '代理代課歷練（累積經驗）']
    },
    'high_school_teacher': {
        title: '國高中老師 (High School Teacher)',
        description: '青春期的引路人。專精於特定學科教學，同時引導處於叛逆期或迷惘期的青少年找到方向。',
        tasks: ['學科專業教學', '升學輔導', '班級經營', '青少年心理輔導', '社團帶領'],
        skills: ['學科專業', '青少年心理', '諮商技巧', '升學輔導', '班級經營'],
        mbti: 'ENTJ, ESTJ, ENFJ',
        quiz_analysis: '你對特定知識領域有深入研究，並熱衷於傳授。你善於溝通與引導，能夠理解青少年的心聲，希望成為他們人生路上的重要導師。',
        salary: { bachelor: '40k - 65k', master: '48k - 75k' },
        companies: [{ name: 'High Schools (公私立中學)', url: '#' }, { name: 'Cram Schools (補習班)', url: '#' }],
        roadmap: ['學科系所畢業', '中等教育學程', '教師檢定與實習', '教師甄試 (教甄)', '學科展覽或競賽指導']
    },
    'preschool_teacher': {
        title: '幼教老師 (Preschool Teacher)',
        description: '探索世界的玩伴。透過遊戲、律動與故事，啟發幼兒的感官與認知，並照顧他們的生活起居。',
        tasks: ['教案與活動設計', '生活常規訓練', '幼兒安全照護', '親師聯絡簿', '節慶活動舉辦'],
        skills: ['幼兒教育', '活動設計', '安全照護', '耐心', '創造力'],
        mbti: 'ESFP, ENFP, ISFJ',
        quiz_analysis: '你充滿活力與童心，喜歡用遊戲與故事來認識世界。你的耐心與創造力，能讓孩子在快樂中學習，是孩子們最喜愛的大玩伴。',
        salary: { bachelor: '32k - 45k', master: '38k - 50k' },
        companies: [{ name: 'Kindergartens (幼兒園)', url: '#' }, { name: 'Daycare Centers (托嬰中心)', url: '#' }],
        roadmap: ['幼保/幼教系畢', '幼兒園教師證', '保母證照', '教具製作能力', '蒙特梭利/華德福培訓']
    },
    'tutor': {
        title: '線上家教 (Online Tutor)',
        description: '打破時空的傳道授業。利用數位平台進行遠距教學，客製化教學內容，幫助學生突破學習盲點。',
        tasks: ['視訊授課', '備課與教材準備', '學生進度追蹤', '作業批改', '家長溝通'],
        skills: ['學科專業', '線上教學', '溝通能力', '耐心', '科技素養'],
        mbti: 'INFJ, INFP, ISFJ',
        quiz_analysis: '你喜歡一對一的深度互動，擅長針對個人的通點進行解惑。你善用科技工具，享受自由彈性的工作模式，並能精準地幫助學生提升能力。',
        salary: { bachelor: '時薪 400 - 1500+', master: '時薪 600 - 2000+' },
        companies: [{ name: 'AmazingTalker', url: 'https://tw.amazingtalker.com' }, { name: 'Snapask', url: 'https://snapask.com' }],
        roadmap: ['學科專業知識', '數位教學工具 (Zoom/Meet)', '溝通表達能力', '建立個人品牌', '教學成效口碑']
    },
    'trainer': {
        title: '企業講師 (Corporate Trainer)',
        description: '職場能力的教練。針對企業需求設計培訓課程，提升員工的專業技能或軟實力，增強企業競爭力。',
        tasks: ['培訓需求調查', '課程講授', '工作坊帶領', '教案開發', '培訓成效追蹤'],
        skills: ['公眾演說', '工作坊引導', '課程開發', '人力資源發展', '教練引導'],
        mbti: 'ENFJ, ENTJ, ENFP',
        quiz_analysis: '你擁有極佳的公眾演說魅力與引導技巧，渴望影響他人。你擅長將複雜的概念轉化為易懂的實務技巧，是激發團隊潛能與成長的推手。',
        salary: { bachelor: '45k - 70k', master: '55k - 90k' },
        companies: [{ name: 'DDI', url: '#' }, { name: 'Corporate HR Dept', url: '#' }],
        roadmap: ['專業領域深耕', '公眾演說技巧', '引導技術 (Facilitation)', '人力資源發展 (HRD)', '顧問諮詢能力']
    },

    // --- New: Service ---
    'hotel_manager': {
        title: '飯店經理 (Hotel Manager)',
        description: '極致款待的指揮家。管理飯店營運，從房務清潔到櫃台接待，確保每位旅客都有賓至如歸的體驗。',
        tasks: ['營運目標管理', '客戶滿意度監控', '員工排班管理', '客訴處理', '跨部門協調'],
        skills: ['餐旅管理', '領導力', '危機處理', '外語能力', '服務熱忱'],
        mbti: 'ESTJ, ESFJ, ENTJ',
        quiz_analysis: '你具有卓越的服務精神與領導魅力，善於營造賓至如歸的氛圍。你注重細節與體驗，並能指揮若定地處理各種突發狀況，是創造美好回憶的幕後推手。',
        salary: { bachelor: '40k - 60k', master: '50k - 80k' },
        companies: [{ name: 'Regent (晶華酒店)', url: '#' }, { name: 'Marriott (萬豪國際)', url: '#' }],
        roadmap: ['前台/房務實務', '顧客服務技巧', '營運管理知識', '外語能力', '領導統御']
    },
    'flight_attendant': {
        title: '空服員 (Flight Attendant)',
        description: '雲端的守護天使。不僅是提供餐點，更重要的是維護客艙安全，處理緊急狀況，照顧乘客需求。',
        tasks: ['飛行安全檢查', '客艙服務', '緊急逃生引導', '機上免稅品銷售', '特殊旅客協助'],
        skills: ['安全程序', '服務禮儀', '外語能力', '危機應變', '團隊合作'],
        mbti: 'ESFP, ESTP, ESFJ',
        quiz_analysis: '你熱愛飛行與探索世界，擁有親切的笑容與強大的抗壓性。你是高空中的安全守護者，在每一次旅程中，用你的專業與溫暖讓旅客感到安心與舒適。',
        salary: { bachelor: '50k - 80k', master: '50k - 80k' },
        companies: [{ name: 'EVA Air (長榮航空)', url: '#' }, { name: 'China Airlines (華航)', url: '#' }],
        roadmap: ['外語檢定', '航空面試準備', '職前安全訓練', '客艙服務實務', '座艙長晉升']
    },
    'fnb_manager': {
        title: '餐飲營運督導 (F&B Area Manager)',
        description: '美食帝國的區長。管理多家分店的營運狀況，確保餐點品質統一、服務到位，並達成業績目標。',
        tasks: ['門市巡店稽核', '損益表分析 (P&L)', '標準作業流程 (SOP) 優化', '人員培訓', '行銷活動執行'],
        skills: ['門市營運', '財務分析', '領導力', 'SOP 制定', '品質控管'],
        mbti: 'ESTJ, ENTJ, ISTJ',
        quiz_analysis: '你對餐飲業充滿熱情，並具備敏銳的商業頭腦。你擅長制定標準與管理團隊，能夠確保每一道菜、每一次服務都維持高品質，帶領品牌擴張版圖。',
        salary: { bachelor: '45k - 65k', master: '55k - 75k' },
        companies: [{ name: 'Wowprime (王品集團)', url: '#' }, { name: 'Starbucks (星巴克)', url: '#' }],
        roadmap: ['基層服務經驗', '店長管理職', '多店管理技巧', '財務報表分析', '連鎖加盟策略']
    },

    // --- New: Finance ---
    'investment': {
        title: '投資分析師 (Investment Analyst)',
        description: '資本市場的偵探。深入研究產業趨勢與公司財報，撰寫研究報告，提供買進或賣出的投資建議。',
        tasks: ['產業研究', '財務模型建置', '公司拜訪 (Call Company)', '研究報告撰寫', '投資決策支援'],
        skills: ['財務建模', '會計學', 'Excel 試算表', 'CFA 證照', '產業分析'],
        mbti: 'INTJ, ENTJ, ISTJ',
        quiz_analysis: '你對數字極為敏感，喜歡抽絲剝繭分析事物的真實價值。你擁有冷靜理性的判斷力，享受在變動的市場與海量的資訊中，精準找出致勝關鍵的快感。',
        salary: { bachelor: '50k - 80k', master: '60k - 100k+' },
        companies: [{ name: 'Morgan Stanley', url: '#' }, { name: 'Yuanta (元大投顧)', url: '#' }],
        roadmap: ['會計與財管基礎', 'CFA 證照考取', '產業研究方法', '財務估值模型', '基金經理人']
    },
    'financial_advisor': {
        title: '金融理專 (Financial Advisor)',
        description: '財富的規劃師。根據客戶的財務目標與風險承受度，量身打造投資組合，協助客戶累積資產。',
        tasks: ['客戶理財諮詢', '投資商品銷售', '資產配置建議', '市場資訊更新', '客戶關係維護'],
        skills: ['業務銷售', '理財規劃', '溝通能力', '信任感', '市場嗅覺'],
        mbti: 'ESFJ, ENFJ, ESTP',
        quiz_analysis: '你善於傾聽與溝通，能建立深厚的信任關係。你結合了專業財金知識與貼心的服務特質，協助他人實現人生目標與財富自由，是客戶最依賴的夥伴。',
        salary: { bachelor: '40k + Bonus', master: '45k + Bonus' },
        companies: [{ name: 'CTBC (中信銀)', url: '#' }, { name: 'Cathay (國泰世華)', url: '#' }],
        roadmap: ['金融證照模組', '銷售與溝通技巧', '理財規劃實務', '高資產客戶經營', '私人銀行家']
    },
    'accountant': {
        title: '會計師 (Accountant)',
        description: '企業語言的翻譯者。記錄與查核企業的財務狀況，編製財務報表，確保公司帳務清楚且符合法規。',
        tasks: ['帳務處理', '財務報表編製', '稅務申報', '審計查核', '內控流程檢視'],
        skills: ['會計原則', '稅務法規', 'Excel 試算表', '細心謹慎', '誠信正直'],
        mbti: 'ISTJ, ESTJ, ISFJ',
        quiz_analysis: '你條理分明、正直誠信，對於規則與準確性有著高標準的要求。你是企業的守門員，透過嚴謹的專業確保財務的透明與合規，是組織中不可或缺的穩定力量。',
        salary: { bachelor: '38k - 50k', master: '45k - 60k' },
        companies: [{ name: 'Deloitte (勤業眾信)', url: '#' }, { name: 'EY (安永)', url: '#' }],
        roadmap: ['中級會計學', 'CPA 會計師執照', '事務所審計經驗', '稅務法規專研', '財務長 (CFO)']
    },

    // --- New: Marketing/Business Additions ---
    'pr': {
        title: '公關專員 (PR Specialist)',
        description: '品牌的化妝師。負責維護企業形象，處理媒體關係，在發生危機時第一時間進行溝通與滅火。',
        tasks: ['新聞稿撰寫', '媒體關係維護', '記者會舉辦', '危機處理', '品牌活動執行'],
        skills: ['媒體關係', '危機處理', '文案撰寫', '溝通能力', '活動企劃'],
        mbti: 'ENFP, ENFJ, ESFP',
        quiz_analysis: '你反應靈敏、擅長表達，並且擁有極佳的社交手腕。你知道如何與媒體和公眾打交道，善於塑造故事與形象，是企業面對外面世界的最佳代言人。',
        salary: { bachelor: '35k - 50k', master: '42k - 60k' },
        companies: [{ name: 'Ogilvy PR (奧美公關)', url: '#' }, { name: 'Elite PR (精英公關)', url: '#' }],
        roadmap: ['新聞寫作技巧', '媒體生態了解', '公關策略規劃', '危機處理演練', '品牌聲譽管理']
    },
    'brand': {
        title: '品牌經理 (Brand Manager)',
        description: '品牌的守護神。定義品牌的核心價值與定位，確保所有行銷活動都說著同一個品牌故事，佔領消費者心智。',
        tasks: ['品牌策略制定', '年度行銷規劃', '跨部門整合', '品牌資產管理', '市場分析'],
        skills: ['品牌策略', '行銷組合', '專案管理', '創意指導', '分析能力'],
        mbti: 'ENFJ, ENTJ, ENFP',
        quiz_analysis: '你具有戰略思維與創意眼光，懂得挖掘產品的獨特價值。你是品牌的總指揮，統合資源與創意，賦予產品生命力，讓消費者成為忠實的信仰者。',
        salary: { bachelor: '45k - 65k', master: '55k - 80k' },
        companies: [{ name: 'P&G (寶僑)', url: '#' }, { name: 'Unilever (聯合利華)', url: '#' }],
        roadmap: ['行銷基礎與實務', '消費者行為分析', '品牌識別系統 (CIS)', '整合行銷溝通 (IMC)', '品牌總監']
    },
    'devops': {
        title: 'DevOps 工程師 (DevOps Engineer)',
        description: '開發與維運的橋樑。引入自動化工具與流程，讓程式碼從開發到上線像工廠流水線一樣順暢。',
        tasks: ['CI/CD 流程建立', '基礎設施程式碼化 (IaC)', '系統監控與告警', '容器編排管理', '效能優化'],
        skills: ['Jenkins/GitLab CI', 'Docker/K8s', 'Linux 系統', '腳本語言', '雲端技術'],
        mbti: 'ISTP, INTP, ISTJ',
        quiz_analysis: '你討厭沒有效率的工作模式，喜歡用工具來自動化一切。你擅長整合開發與維運的流程，追求系統的穩定與快速交付，是軟體工程背後的加速器。',
        salary: { bachelor: '60k - 80k', master: '70k - 100k+' },
        companies: [{ name: 'Canonical (Ubuntu)', url: '#' }, { name: 'kkday', url: '#' }],
        roadmap: ['Linux 系統管理', '版本控制 (Git)', '自動化構建工具', '容器化生態系', 'SRE 可靠性工程']
    },
    'qa': {
        title: '測試工程師 (QA Engineer)',
        description: '軟體品質的守門員。在產品上線前找出所有潛在的 Bug，設計自動化測試腳本，確保使用者體驗完美。',
        tasks: ['測試計畫制定', 'Bug 追蹤與回報', '自動化測試開發', '壓力測試', '使用者驗收測試 (UAT)'],
        skills: ['測資設計', 'Selenium/Appium', 'Python/Java', '防呆機制', '細節導向'],
        mbti: 'ISTJ, ISFJ, ISTP',
        quiz_analysis: '你擁有鷹眼般的觀察力，絕不放過任何一個小瑕疵。你喜歡破壞，也喜歡建設，透過嚴格的把關確保軟體的品質，是開發團隊最堅實的後盾。',
        salary: { bachelor: '40k - 60k', master: '50k - 70k' },
        companies: [{ name: 'Line', url: '#' }, { name: 'Shopee', url: '#' }],
        roadmap: ['軟體測試理論', '測試案例設計', '自動化測試工具', '效能測試', '持续集成測試']
    },
    'blockchain': {
        title: '區塊鏈工程師 (Blockchain Engineer)',
        description: 'Web3 的建構者。開發智能合約與去中心化應用 (DApp)，打造不需信任中介的新一代網路服務。',
        tasks: ['智能合約撰寫', 'DApp 開發', '鏈上資料分析', '安全性審計', '共識演算法研究'],
        skills: ['Solidity', 'Web3.js', '密碼學', '智能合約', 'Go/Rust'],
        mbti: 'INTJ, INTP, ENTP',
        quiz_analysis: '你對去中心化技術充滿熱情，相信程式碼即法律。你勇於挑戰現狀，致力於構建透明、安全且不可篡改的新世界，是 Web3 革命的先鋒。',
        salary: { bachelor: '60k - 90k', master: '70k - 120k+' },
        companies: [{ name: 'Binance (幣安)', url: '#' }, { name: 'Ethereum Foundation', url: '#' }],
        roadmap: ['區塊鏈原理', '智能合約開發 (Solidity)', '前端與錢包串接', '資安與審計', 'Defi/NFT 應用']
    },

    // --- New: Engineering ---
    'civil_engineer': {
        title: '土木工程師 (Civil Engineer)',
        description: '城市建設的奠基者。從橋樑、道路到高樓大廈，根據力學原理設計並監造結構，確保公共安全。',
        tasks: ['結構計算', '工程監造', '施工圖繪製', '預算編列', '承包商協調'],
        skills: ['AutoCAD', '結構分析', '專案管理', '建築法規', '工地監造'],
        mbti: 'ISTJ, ESTJ, ISTP',
        quiz_analysis: '你個性穩重實在，喜歡看到成果平地而起。你重視安全與基礎，願意為了眾人的福祉，一磚一瓦地建構出城市的骨架與血脈。',
        salary: { bachelor: '40k - 60k', master: '45k - 70k' },
        companies: [{ name: 'CEC (大陸工程)', url: '#' }, { name: 'Sinotech (中興工程)', url: '#' }],
        roadmap: ['力學基礎 (靜力/動力)', '結構分析', '測量學實習', '工程法規', '土木技師執照']
    },
    'mechanical_engineer': {
        title: '機械工程師 (Mechanical Engineer)',
        description: '動力系統的創造者。設計自動化設備、機器人或交通工具的機構，讓機器動起來。',
        tasks: ['機構設計', '3D 建模', '公差分析', '熱流分析', '樣品測試'],
        skills: ['SolidWorks', '機電整合', '熱力學', '材料科學', '解決問題'],
        mbti: 'ISTP, INTP, ISTJ',
        quiz_analysis: '你對機械結構充滿興趣，喜歡拆解與組裝。你擁有優秀的空間概念與力學知識，享受解決複雜的機構問題，創造出精密運作的機械傑作。',
        salary: { bachelor: '42k - 65k', master: '50k - 80k' },
        companies: [{ name: 'HIWIN (上銀)', url: '#' }, { name: 'Gogoro', url: '#' }],
        roadmap: ['工程圖學', '機械加工實習', '自動控制原理', '有限元素分析 (FEA)', '專案開發經驗']
    },
    'ehs_engineer': {
        title: '環安衛工程師 (EHS Engineer)',
        description: '職場安全的守護者。評估工作場所風險，建立安全規範，確保工廠符合環保與職業安全法規。',
        tasks: ['風險評估', '安全教育訓練', '化學品管理', '廢棄物處理規劃', 'ISO 稽核'],
        skills: ['ISO 14001/45001', '風險評估', '化學品安全', '教育訓練', '緊急應變'],
        mbti: 'ISTJ, ISFJ, ESTJ',
        quiz_analysis: '你重視生命安全與環境保護，做事一絲不苟且原則分明。你願意承擔責任，為他人建立一道安全防線，確保每一位工作者都能平安回家。',
        salary: { bachelor: '38k - 55k', master: '45k - 65k' },
        companies: [{ name: 'TSMC (台積電)', url: '#' }, { name: '3M', url: '#' }],
        roadmap: ['工安法規詳讀', '甲級/乙級職業安全衛生業務主管', '環工技師', '緊急應變演練', '企業永續推動']
    },

    // --- New: Public Sector ---
    'civil_servant': {
        title: '公務員 (Civil Servant)',
        description: '國家運作的螺絲釘。依法行政，執行國家政策，服務民眾，享有穩定的工作環境與福利。',
        tasks: ['公文撰寫', '行政流程辦理', '民眾諮詢服務', '專案執行', '政策宣導'],
        skills: ['行政法', '文書處理', '公共服務', '溝通能力', '誠信正直'],
        mbti: 'ISTJ, ISFJ, ESTJ',
        quiz_analysis: '你追求穩定與秩序，願意奉獻自己服務大眾。你做事規矩、負責，適合在制度完善的體系中發揮所長，成為國家機器運轉的重要齒輪。',
        salary: { bachelor: '37k - 50k', master: '47k - 60k (高考)' },
        companies: [{ name: 'City Hall (市政府)', url: '#' }, { name: 'Ministries (中央部會)', url: '#' }],
        roadmap: ['法學緒論', '行政學', '高普考/特考準備', '實務訓練', '公共管理進修']
    },
    'judge_prosecutor': {
        title: '法官/檢察官 (Judge/Prosecutor)',
        description: '正義的捍衛者。檢察官負責偵查犯罪與提起公訴，法官負責審判案件，確保司法公正。',
        tasks: ['開庭偵訊', '閱卷分析', '撰寫起訴書/判決書', '現場履勘', '法律見解研究'],
        skills: ['民刑法', '法律邏輯', '批判性思考', '寫作能力', '專業倫理'],
        mbti: 'INTJ, ISTJ, ENTJ',
        quiz_analysis: '你擁有清晰的邏輯與強烈的正義感，能夠冷靜客觀地分析事實。你願意承擔重大的責任，捍衛法律的尊嚴與社會的公義，是社會秩序的最後一道防線。',
        salary: { bachelor: '100k+', master: '100k+' },
        companies: [{ name: 'District Court (地方法院)', url: '#' }, { name: 'Prosecutors Office (地檢署)', url: '#' }],
        roadmap: ['法律系畢', '律師/司法官國考 (極難)', '司法官學院受訓', '候補法官/檢察官', '實任司法官']
    },
    'investigative_officer': {
        title: '調查局人員 (Investigator)',
        description: '國家安全的守衛。負責反間諜、防制重大經濟犯罪與毒品查緝，工作極具挑戰性與神秘感。',
        tasks: ['跟監蒐證', '情報分析', '詢問筆錄', '洗錢防制', '國家安全維護'],
        skills: ['犯罪偵查', '觀察力', '資訊安全', '體能', '執法能力'],
        mbti: 'ISTP, INTJ, ESTP',
        quiz_analysis: '你智勇雙全，對於隱藏的真相有著敏銳的嗅覺。你熱愛挑戰高難度任務，願意在暗處默默守護國家的安全，是打擊犯罪的隱形英雄。',
        salary: { bachelor: '75k+', master: '80k+' },
        companies: [{ name: 'MJIB (法務部調查局)', url: '#' }],
        roadmap: ['調查局特考', '幹部訓練所受訓', '外勤據點歷練', '專案小組辦案', '情報分析專業']
    },

    // --- New: Art & Media ---
    'director': {
        title: '導演 (Director)',
        description: '影像世界的創世主。並非只坐在椅子上喊卡，而是統合攝影、美術、演員，將腦中的想像化為影像。',
        tasks: ['劇本解讀', '分鏡繪製', '演員指導', '現場調度', '剪輯指導'],
        skills: ['說故事能力', '領導力', '運鏡攝影', '創造力', '溝通能力'],
        mbti: 'ENTP, ENFP, INFJ',
        quiz_analysis: '你擁有天馬行空的想像力與強大的執行力。你像是個造夢者，擅長集結眾人的才華，將腦中抽象的概念具象化為動人的影像故事，引領觀眾進入你的世界。',
        salary: { bachelor: '專案制 (不穩)', master: '名導天價' },
        companies: [{ name: 'Production House (製作公司)', url: '#' }, { name: 'Film Studio', url: '#' }],
        roadmap: ['短片創作', '劇組實習 (場記/助導)', '廣告/MV 導演', '長片劇本開發', '影展參展']
    },
    'illustrator': {
        title: '插畫家 (Illustrator)',
        description: '視覺故事的繪製者。用畫筆為文章、書籍、產品或遊戲創造獨特的視覺風格與角色。',
        tasks: ['草圖發想', '數位繪圖', '角色設計', '商業接案溝通', '個人品牌經營'],
        skills: ['手繪技巧', 'Procreate/PS', '構圖能力', '色彩學', '創造力'],
        mbti: 'INFP, ISFP, INFJ',
        quiz_analysis: '你對色彩與線條有獨特的敏感度，習慣用圖像思考。你喜歡在畫紙上揮灑創意，用視覺語言傳達情感與故事，讓每一筆創作都充滿靈魂與溫度。',
        salary: { bachelor: '接案制', master: '知名度決定' },
        companies: [{ name: 'Game Studio', url: '#' }, { name: 'Publishing House', url: '#' }],
        roadmap: ['素描基礎', '軟體電繪技巧', '作品集累積', '社群經營', '周邊商品開發']
    },
    'fashion_designer': {
        title: '服裝設計師 (Fashion Designer)',
        description: '時尚潮流的引領者。從布料選擇到版型剪裁，將設計理念轉化為可穿著的藝術品。',
        tasks: ['趨勢分析', '布料挑選', '設計稿繪製', '立體剪裁', '秀場籌備'],
        skills: ['縫紉', '打版', '素描', '趨勢分析', '紡織學'],
        mbti: 'ISFP, ENFP, ESFP',
        quiz_analysis: '你對美學有獨到的見解，勇於展現自我風格。你敏銳地捕捉流行趨勢，喜歡透過材質與剪裁的實驗，創造出能展現個人魅力與自信的服飾作品。',
        salary: { bachelor: '35k - 60k', master: '45k - 80k' },
        companies: [{ name: 'Fashion Brand', url: '#' }, { name: 'Textile Industry', url: '#' }],
        roadmap: ['服裝構成學', '打版與縫紉', '設計師助理', '個人系列發表', '創立品牌']
    },

    // --- New: Sports & Health ---

    'physical_therapist': {
        title: '物理治療師 (Physical Therapist)',
        description: '動作功能的修復師。利用運動治療、徒手治療與儀器，協助病人恢復身體功能，遠離疼痛。',
        tasks: ['評估診斷', '徒手治療', '運動處方指導', '輔具建議', '衛教諮詢'],
        skills: ['復健醫學', '肌動學', '徒手治療', '溝通能力', '耐心'],
        mbti: 'ISFJ, ESFJ, INFJ',
        quiz_analysis: '你喜歡幫助人們重拾健康，對人體結構與運作充滿興趣。你耐心且細心，願意透過雙手與專業知識，陪伴患者走過復健之路，找回自由活動的快樂。',
        salary: { bachelor: '45k - 70k', master: '50k - 80k' },
        companies: [{ name: 'Hospitals', url: '#' }, { name: 'Rehab Clinics', url: '#' }],
        roadmap: ['物理治療系畢', '國考證照', '皮拉提斯/紅繩證照', '骨科/神經專科', '成立治療所']
    },
    'nutritionist': {
        title: '營養師 (Nutritionist)',
        description: '健康飲食的規劃師。針對個人健康狀況或團體需求，設計營養均衡的菜單，預防疾病。',
        tasks: ['營養諮詢', '團膳菜單設計', '食安管理', '衛教講座', '體重管理'],
        skills: ['營養學', '飲食規劃', '食品安全', '諮商技巧', '生物學'],
        mbti: 'ISFJ, ESFJ, ISTJ',
        quiz_analysis: '你深信「人如其食」，對於食物與健康的關係有深入研究。你樂於分享正確的飲食觀念，設計美味又健康的方案，幫助大家吃出活力與自信。',
        salary: { bachelor: '35k - 55k', master: '40k - 65k' },
        companies: [{ name: 'Hospitals', url: '#' }, { name: 'Weight Loss Clinic', url: '#' }],
        roadmap: ['食品營養系畢', '營養師國考', 'HACCP 證照', '糖尿病衛教資格', '運動營養專長']
    },

    // --- New: Uniformed Services ---
    'police_officer': {
        title: '警察 (Police Officer)',
        description: '人民保母。維持公共秩序，保護社會安全，處理各類刑事案件與交通違規，工作充滿變數。',
        tasks: ['巡邏勤務', '受理報案', '交通疏導', '犯罪偵查', '為民服務'],
        skills: ['執法能力', '防身術', '觀察力', '溝通能力', '情緒穩定'],
        mbti: 'ESTJ, ISTJ, ESTP',
        quiz_analysis: '你充滿正義感，勇氣十足，願意為了維護社會秩序而挺身而出。你行動力強、反應快，在面對突發狀況時能冷靜應對，是民眾最依賴的安全屏障。',
        salary: { bachelor: '55k - 70k+', master: '官階更高' },
        companies: [{ name: 'NPA (警政署)', url: '#' }],
        roadmap: ['警察特考/警專', '入校受訓', '派出所實務', '專業單位 (刑警/交警)', '警官晉升']
    },
    'firefighter': {
        title: '消防員 (Firefighter)',
        description: '火場逆行者。在危難時刻挺身而出，執行滅火、救護與災害搶救任務，需要極佳的體能與抗壓性。',
        tasks: ['火災搶救', '緊急救護 (EMT)', '災害預防宣導', '消防安檢', '體能訓練'],
        skills: ['消防技能', 'EMT 緊急救護', '體力', '勇氣', '團隊合作'],
        mbti: 'ESTP, ISTP, ESFP',
        quiz_analysis: '你擁有一顆無私奉獻的心，越是危險的地方越能看見你的身影。你的勇氣與體能是你最強的武器，在每一個生死關頭，你都竭盡全力守護每一個生命。',
        salary: { bachelor: '60k - 80k+', master: '危險加給多' },
        companies: [{ name: 'Fire Dept (消防局)', url: '#' }],
        roadmap: ['消防特考/警專', '消防訓練中心受訓', '分隊實務', 'EMT-P 高級救護員', '特搜隊受訓']
    },
    'military_officer': {
        title: '職業軍人 (Military Officer)',
        description: '國家守護者。保衛國家領土安全，精實戰備訓練，學習領導統御與戰略規劃。',
        tasks: ['部隊訓練', '裝備保養', '戰備演訓', '領導管理', '行政業務'],
        skills: ['領導力', '紀律', '戰略規劃', '體能', '武器操作'],
        mbti: 'ISTJ, ESTJ, ENTJ',
        quiz_analysis: '你忠誠、堅毅，重視團隊紀律與榮譽。你願意接受嚴格的訓練磨練心智，為了國家的安全與和平，時刻準備好貢獻自己的一份力量。',
        salary: { bachelor: '50k - 100k+', master: '隨階級晉升' },
        companies: [{ name: 'MND (國防部)', url: '#' }],
        roadmap: ['軍校/ROTC/志願役', '入伍新訓', '專長訓', '部隊歷練', '指參學院進修']
    },

    // --- New Additions: Emerging & Lifestyle ---

    // Medical
    'clinical_psychologist': {
        title: '諮商心理師 (Counseling Psychologist)',
        description: '心靈的修復師。透過晤談與心理衡鑑，協助個案處理情緒困擾、心理創傷，找回生活的平衡。',
        tasks: ['心理衡鑑與診斷', '心理諮商與治療', '病歷撰寫', '團體治療帶領', '跨專業會議'],
        skills: ['諮商技巧', '同理心', '變態心理學', '積極傾聽', '專業倫理'],
        mbti: 'INFJ, INFP, ENFJ',
        quiz_analysis: '你對人的內心世界充滿好奇，擁有敏銳的洞察力與無限的包容。你願意成為他人情緒的垃圾桶與心靈的避風港，陪伴迷失的人找回自我與力量。',
        salary: { bachelor: 'N/A (需碩士)', master: '45k - 65k+' },
        companies: [{ name: 'Hospitals (各大醫院)', url: '#' }, { name: 'Clinics (身心診所)', url: '#' }],
        roadmap: ['心理系畢', '諮商心理所碩士', '全職實習一年', '諮商心理師高考', '執業執照申請']
    },
    'veterinarian': {
        title: '獸醫師 (Veterinarian)',
        description: '毛小孩的守護神。診斷與治療動物的疾病，從內科用藥到外科手術，守護人類最忠實的朋友。',
        tasks: ['臨床門診', '動物手術', '檢驗報告判讀', '飼主衛教', '預防注射'],
        skills: ['獸醫學', '手術技能', '愛心耐心', '溝通能力', '反應能力'],
        mbti: 'ISFP, ISFJ, ENFP',
        quiz_analysis: '你熱愛動物，對於生命充滿憐憫與尊重。你不怕髒、不怕累，願意用專業的醫療技術，為無法說話的毛孩子解除病痛，守護每一個小小的生命。',
        salary: { bachelor: '40k - 60k', master: '50k - 80k+' },
        companies: [{ name: 'Vet Clinics (動物醫院)', url: '#' }, { name: 'Zoos (動物園)', url: '#' }],
        roadmap: ['獸醫系畢 (5年)', '獸醫師國考', 'PGY 臨床訓練', '專科醫師訓練 (如眼科/外科)', '自行開業']
    },

    // Design
    'interior_design': {
        title: '室內設計師 (Interior Designer)',
        description: '空間的魔術師。結合美學與機能，將原本空蕩蕩或老舊的房子，打造成舒適、有風格的居住或商業空間。',
        tasks: ['業主需求訪談', '平面配置圖繪製', '3D 效果圖製作', '工程報價與監工', '建材挑選'],
        skills: ['AutoCAD', 'SketchUp/3ds Max', '空間規劃', '溝通能力', '美學素養'],
        mbti: 'ISFP, ENFP, ESFP',
        quiz_analysis: '你對空間感有天生的直覺，喜歡打造舒適且具美感的環境。你善於傾聽需求，並能巧妙平衡美學與實用性，為人們創造出理想的生活空間。',
        salary: { bachelor: '30k - 45k', master: '35k - 50k' },
        companies: [{ name: 'Design Studios', url: '#' }, { name: 'IKEA', url: '#' }],
        roadmap: ['設計圖學基礎', '繪圖軟體精通', '施工工法與法規', '工地監工實務', '乙級室內裝修證照']
    },
    'architect': {
        title: '建築師 (Architect)',
        description: '城市風貌的推手。設計安全、實用且具美感的建築物，從摩天大樓到私人住宅，改變我們的天際線。',
        tasks: ['建築規劃設計', '法規檢討', '建照申請', '施工圖繪製', '工地監造'],
        skills: ['Revit/BIM', 'AutoCAD', '法規條例', '結構概念', '設計思考'],
        mbti: 'INTJ, INTP, ISTJ',
        quiz_analysis: '你兼具理性邏輯與感性美學，喜歡在大尺度的畫布上揮灑創意。你思考周全、注重細節，享受著看著自己的設計從藍圖變成矗立在地表上的實體建築。',
        salary: { bachelor: '35k - 50k', master: '40k - 60k' },
        companies: [{ name: 'Architecture Firms', url: '#' }, { name: 'Construction Co.', url: '#' }],
        roadmap: ['建築系畢 (5年)', '建築事務所實習', '建築師高考 (超難)', '開業或是合夥', '著名建築獎項']
    },
    'video_editor': {
        title: '影音剪輯師 (Video Editor)',
        description: '故事的剪裁者。透過剪輯節奏、特效與配樂，將零碎的素材組合成引人入勝的影片，是 YouTuber 幕後最大功臣。',
        tasks: ['影片剪輯', '字幕與特效製作', '音效處理', '調色 (Color Grading)', '檔案管理與輸出'],
        skills: ['Premiere Pro', 'After Effects', 'Storytelling', 'Rhythm', 'Communication'],
        mbti: 'ISFP, ENFP, INFP',
        quiz_analysis: '你對節奏與畫面有極高的掌控力，擅長用影像敘事。你像是一個魔術師，能將平凡的素材轉化為令人目不轉睛的影片，操控著觀眾的情緒起伏。',
        salary: { bachelor: '32k - 45k', master: '35k - 50k' },
        companies: [{ name: 'YouTuber Teams', url: '#' }, { name: 'Production House', url: '#' }],
        roadmap: ['剪輯軟體操作', '鏡頭語言與敘事', '動態圖形 (Motion Graphics)', '風格建立', '導演思維']
    },

    // Marketing 
    'creator': {
        title: '自媒體創作者 (Content Creator)',
        description: '個人品牌的經營者。利用社群平台 (IG/YouTube/Podcast) 產出內容，吸引粉絲，創造流量與影響力。',
        tasks: ['企劃發想', '內容製作 (拍攝/撰寫)', '社群互動', '數據分析', '業配洽談'],
        skills: ['Content Marketing', 'Video/Photo Editing', 'Personal Branding', 'Social Media', 'Creativity'],
        mbti: 'ENFP, ENTP, ESFP',
        quiz_analysis: '你充滿魅力與個人特色，喜歡分享生活與觀點。你不畏懼鏡頭與人群，享受成為眾人矚目的焦點，並渴望用創意與內容影響這個世界。',
        salary: { bachelor: '不穩定 (0 - 百萬)', master: '不穩定' },
        companies: [{ name: 'Self-Employed', url: '#' }, { name: 'MCN Agencies', url: '#' }],
        roadmap: ['利基市場 (Niche) 選擇', '內容產出SOP', '粉絲增長策略', '變現模式建立', '團隊化經營']
    },

    // Business
    'lawyer': {
        title: '律師 (Lawyer)',
        description: '正義的辯護人。運用法律專業，為當事人爭取權益，處理訴訟爭議，或提供法律諮詢避免觸法。',
        tasks: ['訴訟代理 (開庭)', '法律諮詢', '合約審閱', '法律書狀撰寫', '談判協調'],
        skills: ['Civil/Criminal Law', 'Logical Thinking', 'Debate', 'Writing', 'Negotiation'],
        mbti: 'ENTJ, ESTJ, INTJ',
        quiz_analysis: '你辯才無礙，思維敏捷，善於在衝突中尋找解決方案。你喜歡挑戰與辯證，為了維護權益可以據理力爭，是攻防戰場上最犀利的戰士。',
        salary: { bachelor: '50k - 70k (受雇)', master: '55k - 80k' },
        companies: [{ name: 'Law Firms', url: '#' }, { name: 'In-house Legal', url: '#' }],
        roadmap: ['法律系畢', '律師高考 (及格率低)', '實習律師 (5個月)', '受雇律師', '合夥律師']
    },
    'ip_specialist': {
        title: '智財專員 (IP Specialist)',
        description: '創意的守門員。專門保護企業的專利、商標與著作權，確保研發成果不被侵權，是科技業極為重視的角色。',
        tasks: ['專利檢索與分析', '專利申請 (Drafting)', '侵權鑑定', '智財策略佈局', '商標註冊'],
        skills: ['Patent Law', 'Technical Background', 'Analysis', 'English', 'Writing'],
        mbti: 'ISTJ, INTJ, INTP',
        quiz_analysis: '你兼具理工與法律的雙重專長，擅長保護無形的智慧資產。你細心嚴謹，能看見創新技術背後的價值並加以防護，是企業競爭力最重要的守護者。',
        salary: { bachelor: '45k - 60k', master: '50k - 70k' },
        companies: [{ name: 'TSMC', url: '#' }, { name: 'Patent Firms', url: '#' }],
        roadmap: ['理工背景+法律知識', '專利師證照', '專利事務所磨練', '企業內部智財法務', '智財顧問']
    },

    // Service
    'pet_groomer': {
        title: '寵物美容師 (Pet Groomer)',
        description: '毛孩的造型師。不僅讓寵物變漂亮，更需注意牠們的情緒與皮膚狀況，提供洗澡、剪毛等專業護理。',
        tasks: ['寵物洗澡與吹整', '造型修剪', '皮膚狀況檢查', '安撫寵物情緒', '環境清潔消毒'],
        skills: ['Pet Handling', 'Grooming Skills', 'Patience', 'Observation', 'Customer Service'],
        mbti: 'ISFP, ISFJ, ESFP',
        quiz_analysis: '你對小動物毫無抵抗力，有無限的耐心與愛心。你享受與寵物相處的時光，並能用巧手讓牠們煥然一新，帶給飼主與毛孩滿滿的幸福感。',
        salary: { bachelor: '30k - 45k + 抽成', master: 'N/A' },
        companies: [{ name: 'Pet Salons', url: '#' }, { name: 'Pet Hotels', url: '#' }],
        roadmap: ['寵物美容證照 (C/B/A級)', '助理實務經驗', '獨立作業美容師', '特殊造型進修', '開設工作室']
    },

    // Education
    'career_counselor': {
        title: '職涯諮詢師 (Career Counselor)',
        description: '迷惘時的引路人。運用測評工具與諮詢技巧，協助人們釐清優勢、價值觀與職業興趣，規劃職涯發展路徑。',
        tasks: ['一對一諮詢', '履歷與面試輔導', '職涯測評解析', '職涯工作坊帶領', '就業市場分析'],
        skills: ['Counseling', 'Career Theory', 'Empathy', 'Listening', 'Resume Editing'],
        mbti: 'INFJ, ENFJ, ENFP',
        quiz_analysis: '你擅長發掘他人的潛能，並樂於助人成功。你善於傾聽與引導，能夠幫助迷惘的人看清方向，找到熱情所在，是大家職涯路上最溫暖的燈塔。',
        salary: { bachelor: '時薪 800 - 3000+', master: '時薪 1200 - 5000+' },
        companies: [{ name: 'Consulting Firms', url: '#' }, { name: 'Universities', url: '#' }],
        roadmap: ['心理/人資背景', '職涯諮詢師證照 (CDA/GCDF)', '諮詢實務累積', '建立個人品牌', '企業培訓講師']
    }
};

// 3. Company Data (Dialogs)
// SDG 8 Statistics Details for Homepage Modals
const sdgStatsData = {
    'jobs': {
        title: "全球需創造 6 億個新職位",
        content: `
            <p>根據世界銀行與國際勞工組織的預測，為了應對全球人口增長，到 2030 年之前，全球需要創造約 <strong>6 億個新的工作機會</strong>，才能維持目前的就業率。</p>
            <p>這不僅是數量的挑戰，更是「質量」的挑戰。我們需要的是符合 SDG 8 定義的「體面工作 (Decent Work)」，即由自由選擇、提供權利保障、足夠收入及社會保護的工作。</p>
            <ul style="margin-top:1rem; padding-left:1.5rem;">
                <li>📉 <strong>挑戰：</strong> 自動化與 AI 可能取代部分傳統職位。</li>
                <li>🚀 <strong>機會：</strong> 綠色經濟、數位轉型將帶來新興職缺。</li>
            </ul>
        `,
        link: "https://www.worldbank.org/en/topic/jobsanddevelopment",
        source: "World Bank"
    },
    'neet': {
        title: "23.5% 青年處於 NEET 狀態",
        content: `
            <p><strong>NEET</strong> 指的是「未就業、未受教育、未接受培訓 (Not in Employment, Education or Training)」的青年族群。</p>
            <p>目前的數據顯示，全球有近四分之一的年輕人處於這種困境，其中女性比例遠高於男性。這代表著巨大的人力資本浪費，也可能導致長期的社會不穩定。</p>
            <p>SDG Target 8.6 的目標即是在 2020 年前大幅減少這一比例（雖已過期，但仍是 2030 議程的重點）。</p>
        `,
        link: "https://www.ilo.org/global/publications/books/WCMS_853321/lang--en/index.htm",
        source: "ILO Global Employment Trends for Youth"
    },
    'paygap': {
        title: "20% 性別薪資差距",
        content: `
            <p>在全球範圍內，女性的平均收入比男性低約 <strong>20%</strong>。這意味著女性每工作一小時，僅能獲得男性約 80% 的報酬。</p>
            <p>造成這一差距的原因包括：</p>
            <ul style="margin-top:1rem; padding-left:1.5rem;">
                <li>👩‍💼 <strong>職業隔離：</strong> 女性多集中於低薪產業（如照護、服務業）。</li>
                <li>👶 <strong>母職懲罰：</strong> 因生育照顧而中斷職涯或減少工時。</li>
                <li>🚫 <strong>玻璃天花板：</strong> 高層管理職位缺乏女性代表。</li>
            </ul>
            <p style="margin-top:1rem;">SDG Target 8.5 明確要求實現「同工同酬 (Equal Pay for Work of Equal Value)」。</p>
        `,
        link: "https://www.ilo.org/global/about-the-ilo/newsroom/news/WCMS_650553/lang--en/index.htm",
        source: "ILO Global Wage Report"
    },
    'safety': {
        title: "Target 8.8：職場安全與健康",
        content: `
            <p>工作不應以犧牲健康為代價。根據 ILO 統計，全球每年有約 <strong>278 萬</strong> 工人死於職業災害或職業病。</p>
            <p>SDG Target 8.8 致力於保護勞工權利，推動人人享有安全和可靠的工作環境，包括弱勢移工與不穩定就業工人在內。</p>
            <p><strong>關鍵行動：</strong></p>
             <ul style="margin-top:1rem; padding-left:1.5rem;">
                <li>⛑️ 加強職場安全法規與檢查。</li>
                <li>🧠 重視職場心理健康（Mental Health at Work）。</li>
            </ul>
        `,
        link: "https://sdg-tracker.org/economic-growth#targets-8.8",
        source: "SDG Tracker"
    }
};

const companyData = {
    'tsmc': {
        title: '台積電 (TSMC)',
        tags: ['Semiconductor', 'Manufacturing'],
        keyMetrics: [
            { label: '製程水回收率', value: '90.3%' },
            { label: '再生能源使用', value: 'RE100 承諾' }
        ],
        relatedCategory: 'hardware',
        reportUrl: 'https://esg.tsmc.com/en/update/sustainabilityReport/',
        content: `
            <p><strong>SDG 8 重點：</strong> 提供具競爭力的薪酬與優質工作環境。</p>
            <ul style="margin: 1rem 0 1rem 1.5rem; text-align: left;">
                <li>推動「多元與共融」職場，尊重員工差異。</li>
                <li>提供完善的全球輪調與學習資源，支持終身學習。</li>
                <li>承諾供應鏈安全與勞工權益保障。</li>
            </ul>
        `
    },
    'starbucks': {
        title: '星巴克 (Starbucks)',
        tags: ['Retail', 'Service'],
        keyMetrics: [
            { label: '全球綠色門市', value: '6,091 家' },
            { label: '社區共好計畫', value: '100% 投入' }
        ],
        relatedCategory: 'business',
        reportUrl: 'https://stories.starbucks.com/stories/planet/',
        content: `
            <p><strong>SDG 8 重點：</strong> 咖啡農的公平貿易 (Fair Trade) 與青年就業支持。</p>
            <ul style="margin: 1rem 0 1rem 1.5rem; text-align: left;">
                <li>C.A.F.E. Practices：確保道德採購，保障農民收益。</li>
                <li>僱用弱勢青年與身心障礙夥伴，提供平等就業機會。</li>
            </ul>
        `
    },
    'patagonia': {
        title: 'Patagonia (巴塔哥尼亞)',
        tags: ['Retail', 'Impact'],
        keyMetrics: [
            { label: '公平貿易認證', value: '85,000+ 員工受惠' },
            { label: '地球稅', value: '1% 營收捐贈' }
        ],
        relatedCategory: 'impact',
        reportUrl: 'https://www.patagonia.com/on/demandware.static/-/Library-Sites-PatagoniaShared/default/dw15d66669/PDF-US/2024-BCorp-Report.pdf',
        content: `
            <p><strong>SDG 8 重點：</strong> 直球對決供應鏈勞工權益。</p>
            <ul style="margin: 1rem 0 1rem 1.5rem; text-align: left;">
                <li><strong>公平貿易 (Fair Trade)：</strong> 確保每一件衣服背後的工人都獲得生活工資。</li>
                <li><strong>不必要的消費就是浪費：</strong> 鼓勵消費者「修補代替購買」，反對過度生產。</li>
            </ul>
        `
    },
    'google': {
        title: 'Google',
        tags: ['Tech', 'Software'],
        keyMetrics: [
            { label: '無碳能源營運', value: '64%' },
            { label: '營運廢棄物轉化', value: '85%' }
        ],
        relatedCategory: 'tech',
        reportUrl: 'https://www.gstatic.com/gumdrop/sustainability/google-2024-environmental-report.pdf',
        content: `
            <p><strong>SDG 8 重點：</strong> 創新工作文化與數位技能普及。</p>
            <ul style="margin: 1rem 0 1rem 1.5rem; text-align: left;">
                <li>提供 Google Career Certificates，協助無學歷背景者進入科技業。</li>
                <li>開放且彈性的工作環境，鼓勵 20% 時間進行創新專案。</li>
            </ul>
        `
    },
    'ikea': {
        title: 'IKEA',
        tags: ['Retail', 'Furniture'],
        keyMetrics: [
            { label: '氣候正效益', value: '2030 目標' },
            { label: '性別平等', value: '50/50 比例' }
        ],
        relatedCategory: 'design',
        reportUrl: 'https://www.ikea.com/global/en/images/IKEA_SUSTAINABILITY_Report_FY_23_20240125_1b190c008f.pdf',
        content: `
            <p><strong>SDG 8 重點：</strong> 社會企業合作與公平就業。</p>
            <ul style="margin: 1rem 0 1rem 1.5rem; text-align: left;">
                <li>與社會企業合作生產產品，為弱勢群體創造就業機會。</li>
                <li>致力於性別平等，各層級管理者性別比例趨近 50/50。</li>
            </ul>
        `
    },
    'you': {
        title: '您的未來企業',
        tags: ['Startup', 'Future'],
        keyMetrics: [
            { label: '無限可能', value: '∞' },
            { label: '改變世界', value: '100%' }
        ],
        relatedCategory: 'all',
        reportUrl: '#',
        content: `
            <p><strong>未來由你定義！</strong></p>
            <p>無論你選擇創業或加入企業，你都可以成為推動 SDG 8 的一份子：</p>
            <ul style="margin: 1rem 0 1rem 1.5rem; text-align: left;">
                <li>同工同酬</li>
                <li>拒絕強迫勞動</li>
                <li>支持創新與創業精神</li>
            </ul>
        `
    }
};

// 4. SDG Slides
// 4. SDG Slides
const sdgSlides = [
    {
        icon: "📈",
        title: "SDG 8.1 經濟成長",
        desc: "依據國情維持人均經濟成長，尤其最低度開發國家（以下簡稱LDCs）的國內生產毛額（GDP）成長率，每年至少需達7%。"
    },
    {
        icon: "💡",
        title: "SDG 8.2 多元創新",
        desc: "透過多元化、技術升級與創新，實現更高水平的經濟生產力，包括將焦點集中在高附加價值與勞動密集產業。"
    },
    {
        icon: "🚀",
        title: "SDG 8.3 創業就業",
        desc: "推動開發導向的政策，促進支持生產活動、創造合宜就業機會、創業精神、創意與創新，並透過提供財務服務等方式，鼓勵微型與中小企業實現正規化與成長。"
    },
    {
        icon: "♻️",
        title: "SDG 8.4 資源效率",
        desc: "2030年前，逐步改善全球的資源使用與生產效率，依據「永續消費和生產的十年計畫（10-year framework of programmes）」，努力使經濟增長與環境退化脫鉤，且已開發國家應成為表率。"
    },
    {
        icon: "🤝",
        title: "SDG 8.5 全面就業",
        desc: "2030年前，實現全面生產性就業，且每個成年人都能獲得合宜工作，包括青年與身心障礙者，並具同工同酬的待遇。"
    },
    {
        icon: "🎓",
        title: "SDG 8.6 青年培力",
        desc: "2020年前，大幅降低失業、未受教育或培訓的青年比例。"
    },
    {
        icon: "🚫",
        title: "SDG 8.7 消除奴役",
        desc: "立即採取有效措施來消除強迫勞動、結束現代奴隸制度、人口販賣，確保禁止與消除最惡劣形式的童工，包括童兵的招募使用，並在2025年終結一切形式的童工。"
    },
    {
        icon: "🛡️",
        title: "SDG 8.8 勞工權益",
        desc: "保護勞工的權益，為所有工人創造安全和有保障的工作環境，包括外籍移工，尤其是婦女移工以及從事危險工作的勞工。"
    },
    {
        icon: "✈️",
        title: "SDG 8.9 永續觀光",
        desc: "2030年前，制定及實施政策推動永續觀光旅遊產業，以創造就業機會，並推廣地方文化與產品。"
    },
    {
        icon: "🏦",
        title: "SDG 8.10 金融普及",
        desc: "強化國內金融機構的能力，鼓勵且拓展所有人取得銀行、保險和金融服務的機會。"
    }
];

// 5. Skill Glossary (Detailed Descriptions)
// Used for popups when clicking on tags
const skillGlossary = {
    // --- Tech: Frontend ---
    'HTML/CSS': '網頁開發的基石。HTML 負責網頁的結構（標題、段落），CSS 負責樣式美化（顏色、排版）。精通這兩者能讓你從零打造出符合設計稿、且在各種螢幕尺寸下都完美的響應式網頁。',
    'JavaScript': '網頁的靈魂，讓靜態畫面動起來的程式語言。從簡單的按鈕互動、資料驗證，到複雜的單頁應用程式 (SPA) 都離不開它。它是目前世界上最流行的程式語言之一。',
    'React/Vue': '現代前端開發的主流框架。透過「元件化」設計，讓程式碼像積木一樣可重複利用，並能高效管理網頁狀態 (State)。React 由 Meta 開發，Vue 則以易學著稱，兩者都是就業熱門選擇。',
    'RWD': '響應式網頁設計 (Responsive Web Design)。讓網頁能自動偵測裝置（電腦、手機），調整排版以提供最佳閱讀體驗。在行動流量超越桌機的時代，這是不可或缺的技能。',
    'Git': '版本控制系統。像遊戲存檔一樣，記錄每一次程式碼修改。寫壞了可隨時「讀檔」；團隊合作時，它能自動合併多人寫的程式碼，是軟體工程師的必備工具。',

    // Roadmap Keys (Frontend)
    'HTML/CSS 基礎': '學習 HTML 標籤語意化 (Semantic Tags) 與 CSS 盒模型 (Box Model)、Flexbox/Grid 排版系統。這是所有網頁開發的起點。',
    'JavaScript 核心': '掌握變數、迴圈、函式、DOM 操作、事件處理 (Event Listener) 以及非同步處理 (Promise/Async Await)。',
    '前端框架 (React)': '學習 React 的元件生命週期、Hooks (useState, useEffect) 以及如何管理全域狀態 (Redux/Context API)。',
    'API 串接': '學習如何使用 fetch 或 axios 向後端伺服器請求資料，並將回傳的 JSON 資料顯示在網頁上。',
    '效能優化': '了解如何優化圖片載入、減少程式碼體積 (Minify)、使用快取 (Cache) 機制，讓網頁載入速度飛快。',

    // --- Tech: Backend ---
    'Python': '語法簡潔優雅的程式語言。易於學習且功能強大，廣泛應用於網站後端 (Django/Flask)、數據分析、AI 等領域。是初學者入門首選，也是資深的瑞士刀。',
    'Python/Node.js': '後端熱門選擇。Python 適合快速開發與數據處理；Node.js 讓前端工程師能用 JavaScript 寫後端，擅長處理高併發的即時應用 (如聊天室)。',
    'SQL': '結構化查詢語言。與資料庫「溝通」的標準語言。無論是要撈取會員資料、統計訂單，還是更新庫存，都需要使用 SELECT, INSERT, UPDATE 等指令。',
    'Database': '資料庫管理。了解如何設計高效率的資料表結構 (Schema)，選擇合適的資料庫 (關聯式 MySQL vs 非關聯式 MongoDB)，確保資料安全且快速存取。',
    'API Design': '設計前後端溝通的橋樑。定義前端該如何「點菜」(Request) 以及後端如何「上菜」(Response)。RESTful 與 GraphQL 是常見設計風格。',
    'Linux': '伺服器最常用的作業系統。熟悉 Command Line 指令操作是部署程式、管理雲端機器、排查系統問題的必備基本功。',
    'AWS/GCP': '雲端服務平台。學習如何操作 Amazon (AWS) 或 Google (GCP) 的雲端資源，如開虛擬機 (EC2)、雲端儲存 (S3)、資料庫託管 (RDS) 等。',

    // Roadmap Keys (Backend)
    '程式語言基礎': '選擇 Python、Java 或 Go，深入理解變數型態、物件導向 (OOP)、資料結構與演算法。',
    '資料庫設計': '學習正規化 (Normalization) 避免資料冗餘，設計索引 (Index) 加速查詢，並了解交易 (Transaction) 安全性。',
    'API 開發': '實作 RESTful API，處理 HTTP 狀態碼 (200, 404, 500)，並撰寫 API 文件 (Swagger)。',
    '伺服器部署': '將程式碼放上雲端伺服器 (Linux)，設定 Nginx/Apache 網頁伺服器，讓全世界都能訪問你的服務。',
    '系統架構設計': '學習如何設計可擴展 (Scalable) 的系統，包含負載平衡 (Load Balancer)、快取 (Redis) 與微服務 (Microservices)。',

    // --- Tech: Mobile ---
    'Swift (iOS)': 'Apple 推出的 iOS 開發語言。強調安全、快速與現代語法。學習 Swift 能開發出在 iPhone/iPad 上運行流暢、體驗精緻的原生 App。',
    'Kotlin (Android)': 'Google 推薦的 Android 開發首選。與 Java 相容但語法更簡潔安全。現代 Android App 幾乎都已轉向使用 Kotlin 開發。',
    'Flutter': 'Google 的跨平台框架。只寫一套程式碼 (Dart 語言) 就能同時輸出 iOS 和 Android App。大幅降低開發成本，是新創公司的最愛。',
    'UI Design': '介面設計。雖然工程師不一定要會畫圖，但要有基本的排版美感與 UX 概念，才能將設計稿完美還原成 App 畫面。',

    // Roadmap Keys (Mobile)
    '語言基礎 (Swift/Kotlin)': '掌握 Swift 的 Optional 概念或 Kotlin 的 Null Safety，這是寫出不崩潰 App 的關鍵。',
    'UI 佈局': '學習 iOS Auto Layout 或 Android XML/Compose，適應不同尺寸的手機螢幕。',
    '手機硬體串接': '學習如何使用相機、GPS 定位、藍芽、陀螺儀等手機硬體功能。',
    'App 上架流程': '了解 Apple App Store 與 Google Play 的審查規範，憑證簽署與上架發布流程。',
    '跨平台開發': '進階學習 Flutter 或 React Native，一次開發雙平台，提升職場競爭力。',

    // --- Tech: data & AI ---
    'Machine Learning': '機器學習。讓電腦透過分析數據「學會」預測。不需要明確寫規則，機器能自己找出規律。應用於推薦系統、股價預測等。',
    'PyTorch/TensorFlow': '深度學習框架。提供強大的工具庫，讓你像蓋房子一樣架構神經網絡。TensorFlow 適合工業部署，PyTorch 適合研究實驗。',
    'Data Mining': '資料探勘。從海量雜亂的數據中，利用統計與演算法挖掘出有價值的資訊，例如找出「買尿布的人也會買啤酒」的關聯。',
    'Tableau/PowerBI': '商業智慧 (BI) 工具。將枯燥的 Excel 表格轉換成互動式儀表板 (Dashboard)，讓決策者一眼看懂業績趨勢與市場分佈。',
    'Excel': '數據處理神器。不只是填表格，善用樞紐分析 (Pivot Table) 與 VLOOKUP，能快速從雜亂資料中整理出邏輯。',
    'Statistics': '統計學。平均數、標準差、P值...這些數學工具能幫你分辨看到的趨勢是真的有意義，還是只是隨機巧合。',

    // Roadmap Keys (Data/AI)
    'Python 與數學': '打好微積分、線性代數與機率統計基礎，並熟悉 Python 的 NumPy, Pandas 套件。',
    '機器學習原理': '理解監督式學習 (回歸/分類)、非監督式學習 (分群) 等核心演算法原理。',
    '深度學習框架': '實作神經網絡 (CNN, RNN, Transformer)，應用於影像辨識或自然語言處理。',
    '模型訓練與調校': '學習如何避免過擬合 (Overfitting)，調整超參數 (Hyperparameters) 以提升模型準確度。',
    'AI 論文實作': '閱讀頂級會議 (CVPR, NeurIPS) 論文，並嘗試復現其程式碼，保持技術最前線。',
    'Excel 與統計': '掌握 Excel 進階函數，並具備描述性統計與推論統計的基本觀念。',
    'SQL 資料庫查詢': '熟練 SQL 語法，能從龐大的資料倉儲中精準撈取所需的分析資料。',
    '視覺化工具 (Tableau)': '學習如何選擇正確的圖表來呈現數據，說出有說服力的數據故事。',
    '商業分析思維': '不僅懂技術，更要懂商業。能定義問題、提出假設，並用數據驗證，提供行動建議。',
    'Python 資料處理': '使用 Pandas 進行資料清洗 (Data Cleaning) 與預處理，這是數據分析最花時間但也最重要的步驟。',

    // --- Tech: Game ---
    'Unity/Unreal': '兩大遊戲引擎。Unity (C#) 輕量跨平台，適合手遊；Unreal (C++) 畫質極致，是 3A 大作首選。掌握其一就能創造虛擬世界。',
    'C# / C++': '遊戲開發語言。C# 語法友善開發快；C++ 效能極致，能榨乾硬體效能。根據想開發的遊戲類型選擇。',
    '3D Math': '遊戲數學。向量、矩陣、四元數。你需要用它們計算移動、旋轉、碰撞，是遊戲物理的基礎。',
    'Shaders': '著色器。控制光影如何渲染在物體表面。想做出炫砲的魔法特效或逼真的水面波動，全靠它。',
    'Networking': '網路連線。在多人遊戲中，如何確保玩家A開槍時，玩家B能瞬間看到並扣血，涉及極致的延遲優化。',

    // Roadmap Keys (Game)
    '程式基礎 (C#/C++)': '深入理解記憶體管理、物件導向與設計模式 (Design Patterns)，寫出高效能的程式碼。',
    '遊戲引擎 (Unity)': '熟悉 Unity 介面、Component 系統、Prefab 管理以及場景切換。',
    '2D/3D 數學': '不要怕數學！向量運算與座標轉換是讓遊戲角色動起來的核心。',
    '物理與渲染': '了解剛體 (Rigidbody)、碰撞器 (Collider) 以及材質球 (Material) 的運作原理。',
    '多人連線架構': '學習 Client-Server 架構、狀態同步與延遲補償 (Lag Compensation) 技術。',

    // --- Tech: Cloud & Security ---
    'Docker/K8s': '容器化技術。Docker 把程式跟環境打包，確保到處都能跑；K8s 則是管理成千上萬個容器的指揮官。',
    'Security': '資安概論。了解常見攻擊手法 (OWASP Top 10)，如 SQL Injection, XSS，並知道如何防禦。',
    'Cryptography': '密碼學。加密與解密。HTTPS、區塊鏈都基於此。了解對稱/非對稱加密與雜湊 (Hash) 函數。',
    'Hacking Tools': '駭客工具。Kali Linux, Metasploit, Burp Suite。白帽駭客需要會用這些工具來模擬攻擊，找出漏洞。',
    'Scripting': '腳本語言。Bash 或 Python。用來自動化執行的腳本，能快速處理大量重複的資安掃描任務。',
    'Linux': '作業系統。熟悉權限管理、檔案系統、Process 管理，因為絕大多數伺服器都跑在 Linux 上。',

    // Roadmap Keys (Cloud/Security)
    'Linux 系統管理': '能夠熟練使用 Shell 指令，管理使用者、磁碟空間與系統服務。',
    '網路基礎知識': '理解 OSI 模型、TCP/IP、DNS、HTTP 協定，這是除錯網路問題的基礎。',
    '雲端服務 (AWS)': '考取 AWS/GCP 證照，熟悉雲端運算、儲存、網路與資料庫服務的配置。',
    '容器化技術 (Docker)': '學會撰寫 Dockerfile，製作輕量級的容器映像檔 (Image)。',
    '自動化部署 (CI/CD)': '建立 Jenkins 或 GitHub Actions 流程，讓程式碼從 Commit 到上線全自動化。',
    '網路與系統基礎': '深入理解作業系統原理與網路協定，這是資安攻防的戰場。',
    '腳本語言 (Python)': '能夠撰寫 Python 腳本來自動化蒐集情資或進行漏洞掃描。',
    '攻防原理 (CTF)': '參加奪旗賽 (CTF)，在實戰中磨練 Web、Crypto、Reverse Engineering 攻擊技巧。',
    '滲透測試工具': '熟練使用 Nmap, Wireshark 等工具進行網路偵查與封包分析。',
    '資安防護架構': '學習如何規劃縱深防禦 (Defense in Depth)，配置防火牆、WAF 與 SIEM 監控。',

    // --- Design & UX ---
    'Figma/Sketch': '介面設計神器。Figma 支援雲端協作，讓你跟團隊一起畫圖、做 Prototype。是目前業界標準。',
    'Color Theory': '色彩學。了解色彩心理學與配色對比。不同顏色能引導使用者情緒，如藍色代表信任，紅色代表急迫。',
    'Typography': '字體排印學。字體選擇、行高、字距。好的排版能讓資訊層級分明，閱讀起來舒適愉悅。',
    'Layout': '排版佈局。Grid System (格線系統) 的運用。確保畫面平衡、整齊，且符合視覺動線。',
    'Micro-interaction': '微互動。按鈕按下去的回饋、滑鼠移過去的特效。這些細節能大幅提升產品的精緻度與手感。',
    'User Research': '使用者研究。透過訪談、問卷、易用性測試，了解使用者真實需求。不是「猜」他們要什麼，是「觀察」。',
    'Wireframing': '線框圖。在畫精美 UI 前，先用線條方塊規劃功能與動線。幫助團隊聚焦在流程而非顏色。',
    'Logic Flow': '邏輯流程。畫出使用者操作的 Flowchart。確保每個按鈕點下去都有反應，沒有死路。',
    'Psychology': '心理學。理解認知負荷、席克定律 (Hick\'s Law) 等。設計符合人類直覺的產品，減少使用者思考時間。',
    'Data Analysis': '數據分析(UX)。根據 GA 或 Hotjar 的數據 (熱點圖、點擊率) 來優化設計，用數據而非直覺說話。',

    // Roadmap Keys (Design)
    '設計基礎 (色彩/排版)': '培養美感，訓練對細節的敏銳度。多看 Dribbble, Pinterest 累積靈感。',
    '設計軟體 (Figma)': '精通 Figma 的 Auto Layout, Components, Variants 功能，提升作圖效率。',
    'Design System': '建立一套標準化的設計規範 (Design System)，確保產品風格統一且易於維護。',
    '動效設計': '使用 Protopie 或 After Effects 製作轉場動畫，向工程師展示動態效果。',
    '切版概念': '了解 HTML/CSS 基礎，設計出工程師「做得出來」的切版，減少溝通成本。',
    '使用者心理學': '研讀《設計的心理學》，了解人類如何與物體互動。',
    '訪談與測試技巧': '學習如何設計訪談大綱，以及如何進行不具引導性的使用者測試。',
    'Wireframe 繪製': '能夠快速將想法轉化為低保真 (Low-fi) 原型，進行快速驗證。',
    '資訊架構 (IA)': '學習如何分類與組織資訊，讓使用者能在網站中直覺地找到想要的東西。',
    '數據驅動設計': '學習 A/B Testing 觀念，驗證不同設計方案的成效。',

    // --- PM & Business (Data Analysis in Tech section) ---
    'Communication': '溝通技巧。PM 與 Sales 的核心。清晰表達想法、傾聽他人需求、在衝突中尋求共識，讓專案順利推動。',
    'Project Management': '專案管理。控管時間、成本、品質。確保團隊在期限內做出對的東西。',
    'Logic': '邏輯思維。PM 需釐清需求的因果關係，拆解複雜問題。確保產品規格沒有邏輯漏洞。',
    'Data Sense': '數據敏感度。看到數字能直覺反應出背後的意義。業績掉 10%，是流量少了？還是轉換率低了？',
    'PMP': '國際專案管理師證照。證明你熟悉標準專案管理流程 (五大流程、十大知識領域)。大型企業 PM 的加分項。',
    'Risk Management': '風險管理。預想「萬一出錯怎麼辦」。制定備案 (Plan B)，在危機發生時能冷靜應對。',
    'Jira/Trello': '專案協作工具。用看板 (Kanban) 或衝刺 (Sprint) 管理任務。讓進度透明化，不再漏東漏西。',
    'Leadership': '領導力。不只是發號施令，而是激勵團隊、扛起責任、排除障礙，帶領大家往目標前進。',
    'Negotiation': '談判技巧。尋求「雙贏」。在客戶需求與公司利益之間找到平衡點，讓合約順利成交。',
    'Presentation': '簡報技巧。好的簡報能說服老闆撥預算、說服客戶買單。重點是「聽眾想聽什麼」，而非你想講什麼。',
    'Market Research': '市場調查。了解競爭對手在做什麼、市場趨勢往哪走。知己知彼，百戰不殆。',
    'CRM': '客戶關係管理系統 (Salesforce 等)。記錄與客戶的每一次互動，分析數據以提升成交率與回購率。',
    'Empathy': '同理心。CSM 與 HR 的必備能力。真正站在對方角度思考，感受到他的焦慮或需求，才能提供溫暖的服務。',
    'Problem Solving': '解決問題能力。客戶遇到問題時，能迅速釐清狀況，調動資源找到解法，化危機為轉機。',
    'Product Knowledge': '產品知識。CSM 需比客戶更懂產品，才能教客戶怎麼用，甚至發現客戶沒想到的用法。',
    'Interviewing': '面試技巧。HR 需透過提問，在短時間內判斷候選人的能力與文化契合度，並展現公司專業形象。',
    'Labor Law': '勞動法令。熟悉勞基法，處理合約、加班費、資遣等問題，避免勞資糾紛，保護公司也保護員工。',
    'People Analytics': '人才數據分析。用數據看人力資源。離職率為什麼高？哪個管道招的人績效好？用數據優化管理。',

    // Roadmap Keys (PM/Business)
    '需求分析能力': '學習如何將客戶模糊的許願，轉化為具體的產品規格 (Spec)。',
    '專案管理 (Agile)': '熟悉敏捷開發 (Agile) 思維，透過短週期的迭代 (Iteration) 快速回應市場變化。',
    '原型繪製': 'PM 也要會畫簡單的 Wireframe，因為一張圖勝過千言萬語的規格書。',
    '數據分析基礎': '不需要成為分析師，但要會看 GA 報表，懂得用 SQL 撈簡單的數據驗證想法。',
    '產品策略思維': '思考產品的定位 (Positioning) 與價值主張 (Value Proposition)，而不只是做功能。',
    '專案管理流程': '熟悉啟動、規劃、執行、監控、結案的標準流程。',
    '溝通與談判': '學習非暴力溝通與哈佛談判術，解決跨部門的利益衝突。',
    '風險評估': '學習製作風險矩陣 (Risk Matrix)，評估風險發生的機率與衝擊。',
    '敏捷開發 (Scrum)': '深入了解 Scrum Master 角色，如何主持站立會議、回顧會議。',
    'PMP 證照': '系統化學習 PMI 的 PMBOK 指南，建立紮實的專案管理知識體系。',
    '溝通與銷售技巧': '學習 SPIN 銷售法或顧問式銷售，引導客戶說出需求。',
    '客戶關係管理': '學習如何對客戶進行分級 (Segmentation)，將資源投在最有價值的客戶上。',
    '談判與成交': '學習在價格談判中守住底線，並運用心理學技巧促成成交 (Closing)。',
    '市場開發策略': '學習如何制定 Go-to-Market (GTM) 策略，將新產品推向市場。',
    '高階顧問式銷售': '從「賣產品」轉變為「賣解決方案」，成為值得客戶信賴的合作夥伴。',
    '產品深度掌握': '不只要懂操作，更要懂產品背後的設計邏輯與限制。',
    '客戶溝通技巧': '學習如何優雅地拒絕不合理要求，以及如何安撫憤怒的客戶。',
    '問題解決能力': '運用 8D 或 5 Why 分析法，找出問題的根本原因 (Root Cause)。',
    '數據分析與洞察': '分析客戶的使用數據，主動發現客戶可能流失的徵兆 (Churn Prediction)。',
    '客戶保留策略': '設計客戶成功計畫 (Success Plan)，定期檢視客戶是否達成預期目標。',
    '招募與面試技巧': '學習行為面試法 (STAR)，從過去行為預測未來表現。',
    '勞動法令基礎': '隨時關注勞基法修法動態，確保公司制度合規。',
    '薪酬福利制度': '設計具競爭力的薪資結構與激勵獎金，吸引並留住優秀人才。',
    '績效管理': '設定 SMART 目標，並學習如何進行有效的績效面談與回饋。',
    '組織文化發展': '舉辦 Team Building 活動，塑造開放、當責的公司文化。',

    // --- Marketing & Content & SEO ---
    'Google Ads': '關鍵字廣告。在使用者搜尋時，讓你的廣告精準出現在最上方。需懂關鍵字挑選、出價策略與文案優化。',
    'Facebook Ads': '社群廣告。利用 FB/IG 強大的受眾標籤，把廣告投給「對的人」。需懂受眾設定、素材測試與像素 (Pixel) 追蹤。',
    'Google Analytics': '網站分析 (GA4)。數據分析神器。誰來了網站？看了什麼？在哪離開？數據是行銷優化的基礎。',
    'Copywriting': '文案撰寫。不只是寫作，而是用文字「銷售」。無論是標語、貼文還是 EDM，好文案能直擊人心，激發購買慾。',
    'Creative': '創意發想。在資訊爆炸時代，只有夠有創意、夠吸睛的內容，才能讓使用者停下大拇指多看一眼。',
    'Video Editing': '影片剪輯。剪接節奏、字幕、特效。短影音當道，會剪輯就是掌握了流量密碼。',
    'Storytelling': '說故事能力。同樣的產品，生硬規格 vs 動人故事，後者價值翻倍。行銷就是說一個好故事。',
    'Photography': '攝影。構圖、光影、修圖。一張好的照片勝過千言萬語，是社群素材的基礎。',
    'Trend Sense': '趨勢敏感度。知道現在流行什麼梗？什麼話題最熱？借勢行銷 (Newsjacking) 能用最少力氣換最大流量。',
    'Keyword Research': '關鍵字研究。SEO 的第一步。找出使用者都在搜什麼？競爭度如何？鎖定對的關鍵字才能帶來有效流量。',
    'Technical SEO': '技術 SEO。提升網站速度、優化程式碼結構、設定 robots.txt，確保 Google 爬蟲能順利讀懂你的網站。',
    'Content Strategy': '內容策略。不只是寫文章，而是規劃「內容地圖」。針對使用者不同階段 (認知/考慮/轉換) 提供對應的內容。',
    'Link Building': '連結建設。讓其他權威網站連結到你的網站 (Backlinks)。這像是別人對你的「投票」，能大幅提升搜尋排名。',
    'HTML Basics': 'HTML 基礎。SEO 專家要懂基本的標籤 (H1, Meta Tags, Alt)，才能跟工程師溝通如何優化。',

    // Roadmap Keys (Marketing/Content/SEO)
    '行銷基礎與文案': '了解 4P/STP 等行銷理論，並透過大量練習磨練文案感染力。',
    '社群媒體經營': '熟悉 FB, IG, LinkedIn 等平台的演算法特性，經營互動率高的社群。',
    '廣告投放操作': '實際操作廣告後台，學習 A/B Test 素材與受眾，優化 ROAS (廣告投資報酬率)。',
    '數據分析 (GA4)': '考取 GAIQ 證照，深入理解工作階段、轉換率、歸因模式等數據指標。',
    '行銷策略規劃': '能夠整合多種行銷渠道 (Omni-channel)，制定完整的一年度行銷計畫。',
    '腳本與文案': '學習電影編劇結構 (起承轉合)，寫出能留住觀眾的影片腳本。',
    '攝影與剪輯': '熟練 Premiere 或 CapCut，並培養對畫面美感的直覺。',
    '社群互動技巧': '學習如何回覆留言、舉辦活動，將粉絲轉化為鐵粉。',
    '個人品牌經營': '不僅幫公司做，也要懂得經營自己。建立鮮明的人設與專業形象。',
    '創意變現模式': '了解業配、聯盟行銷、知識付費等商業模式，將流量變現。',
    '搜尋引擎原理': '了解 Google 演算法如何爬取、索引與排序網頁。',
    '關鍵字策略': '使用 Ahrefs 或 SEMrush 工具，挖掘出高流量低競爭的長尾關鍵字。',
    '內容優化 (On-page)': '優化標題、Meta Description、內文結構，讓內容既給人看也給機器看。',
    '技術優化 (Technical)': '學習使用 Search Console 排除索引錯誤，處理轉址 (301) 與標準網址 (Canonical)。',
    '數據分析與報表': '定期追蹤關鍵字排名與自然流量，製作 SEO 成效報表提出優化建議。',

    // --- Impact (ESG/CSR) ---
    'Sustainability': '永續發展。滿足當代需求，且不損及後代滿足其需求的能力。包含環境 (E)、社會 (S) 與治理 (G)。',
    'Report Writing': '報告書撰寫。將企業的永續績效，轉化為符合國際準則 (GRI/SASB/TCFD) 的專業報告書。',
    'Carbon Accounting': '碳盤查。計算企業排放了多少溫室氣體 (範疇一二三)。這是減碳策略的基礎，就像記帳一樣重要。',
    'Regulation': '法規研究。歐盟 CBAM、金管會永續路徑圖。永續法規日新月異，需隨時掌握以降低企業合規風險。',
    'Event Planning': '活動企劃。規劃淨灘、偏鄉教育等公益活動。從流程、預算到雨天備案，考驗細心與執行力。',
    'Writing': '寫作能力。CSR 需要撰寫溫暖人心的活動新聞稿，也要撰寫嚴謹的官方聲明。',
    'Project Management': '專案管理(NPO)。跨部門協調志工、物資與合作夥伴。確保公益專案能產生實際影響力。',

    // Roadmap Keys (Impact)
    '永續發展概論': '閱讀聯合國 SDGs 細項目標，建立對全球永續議題的宏觀認識。',
    'GRI/SASB 準則': '深入研讀全球最通用的永續報告準則，了解各產業需揭露的關鍵指標。',
    '碳排計算 (ISO)': '學習 ISO 14064 溫室氣體盤查標準，具備實際計算碳足跡的能力。',
    '永續報告撰寫': '練習閱讀優秀企業的 ESG 報告書，模仿其架構與敘事邏輯。',
    '企業轉型策略': '思考如何將 ESG 融入企業核心商業模式，創造共享價值 (CSV)。',
    '活動企劃與執行': '從小型志工活動開始，練習撰寫企劃書與預算表。',
    'NPO 合作模式': '了解非營利組織的運作生態，建立企業與 NPO 的夥伴關係。',
    '專案管理': '學習如何管理利害關係人 (Stakeholders)，平衡各方期待。',
    '公關與媒體溝通': '學習如何將公益成果轉化為品牌形象，提升企業聲譽。',
    '社會影響力評估': '學習 SROI (社會投資報酬率) 方法，將做的好事「量化」為具體價值。',

    // --- New Categories: Hardware ---
    'Verilog/VHDL': '硬體描述語言。IC 設計工程師用來描述晶片邏輯行為的語言。就像軟體工程師用 C++ 寫程式，IC 設計師用 Verilog 設計電路。',
    'FPGA': '現場可程式化邏輯閘陣列。一種可以重複編程的晶片，常用於驗證 IC 設計或加速特定運算。',
    'Circuit Design': '電路設計。從電晶體層級設計類比或數位電路，考量電壓、電流、雜訊等物理特性。',
    'Semiconductor Physics': '半導體物理。理解電子與電洞在矽晶圓中的移動方式，是優化製程與提升良率的基礎。',
    'PCB Layout': '印刷電路板佈線。將設計好的電路圖轉化為實際的電路板圖，需考量訊號干擾與散熱問題。',

    // Hardware Roadmap
    '數位邏輯設計': '學習布林代數、邏輯閘 (AND/OR/NOT) 與時序電路 (Flip-Flops)，這是電腦運作的基礎。',
    'HDL 語言 (Verilog)': '熟練 Verilog 語法，能夠撰寫 Testbench 進行功能驗證。',
    '計算機組織': '理解 CPU 指令集 (ISA)、管線 (Pipeline) 與記憶體階層 (Memory Hierarchy)。',
    'FPGA 實作': '將設計的電路燒錄到 FPGA 開發板上，觀察實際運作情形。',
    '晶片佈局 (Layout)': '學習如何將電路轉換為光罩圖案 (Mask)，並通過 DRC/LVS 驗證。',

    // New Hardware Skills
    '機台維修': 'Equipment Maintenance。熟悉板手、螺絲起子等手工具與電表操作，排除機台故障。',
    '氣壓/油壓原理': 'Pneumatics/Hydraulics。半導體機台充滿了氣壓缸與閥門，了解流體動力是維修基礎。',
    '氣/油壓系統': '同上，Pneumatics/Hydraulics。負責機台動力傳輸的關鍵系統，需掌握其作動原理以進行維修。',
    '英文手冊閱讀': 'Technical Reading。原廠手冊 (Manual) 都是英文，必須能看懂 SOP 與 Error Code。',
    '機構原理': 'Mechanism。了解馬達、滑軌、培林等機械元件如何運作與傳動。',
    '半導體設備訓練': 'Equipment Training。原廠提供的專業訓練，學習特定機型 (如曝光機、蝕刻機) 的構造與維修。',
    '設備改善專案': 'CIP (Continuous Improvement Process)。不只是修好，更要透過改機讓機台跑得更快、更穩。',
    '良率分析': 'Yield Analysis。像偵探一樣分析晶圓測試數據 (Wafer Sort)，找出導致良率下降的製程站點。',
    '良率分析技術': '同上，Yield Analysis。利用統計工具與資料探勘技巧，提升與穩定晶片生產的良率。',
    'VLSI 製程技術': '超大型積體電路製程。深入了解黃光、蝕刻、擴散、薄膜等四大模組的詳細原理。',
    'Solid State Physics': '固態物理。研究固體材料的物理性質，是理解半導體元件運作的理論核心。',
    '基礎電子電路': 'Basic Electronics。了解電壓、電流、電阻的基本關係 (歐姆定律)，以及二極體、電晶體的工作原理。',
    'Quantum Mechanics': '量子力學。在奈米尺度下，古典物理失效，需用量子力學才能解釋電子行為。',
    'TCAD': 'Technology CAD。製程模擬軟體。在實際做實驗前，先用電腦模擬製程參數對元件特性的影響，省錢又省時。',
    'TCAD 模擬工具': '同上，Technology CAD。製程模擬軟體，用於預測半導體製程結果與元件特性。',
    'English Writing': '英文寫作。撰寫技術報告與國際期刊論文，與全球專家交流。',
    'Innovation': '創新思維。不被既有框架限制，勇於嘗試新材料、新結構與新方法。',
    'Advanced Devices': '先進元件。GAA、CFET 等超越傳統 FinFET 的新世代電晶體結構。',
    'Patent Analysis': '專利分析。研究競爭對手的專利佈局，找出技術突破點或迴避侵權。',


    // --- New Categories: Finance ---
    'Accounting': '會計學。企業的語言。記錄並彙總所有的財務交易，編製資產負債表與損益表，反映公司真實營運狀況。',
    'Financial Analysis': '財務分析。解讀財報數字背後的意義，評估企業的償債能力、獲利能力與經營效率。',
    'Investment Strategy': '投資策略。根據風險承受度與財務目標，配置資產 (股票、債券、這動產)，以追求長期資產增值。',
    'Tax Law': '稅法。了解所得稅、營業稅等稅務規定，協助個人或企業合法節稅。',
    'Risk Management (Fin)': '金融風險管理。運用衍生性金融商品 (期貨、選擇權) 避險，降低市場波動對資產的衝擊。',

    // Finance Roadmap
    '會計學原理': '掌握借貸法則、會計循環與四大財務報表編製。',
    '財務管理': '學習貨幣時間價值 (Time Value of Money)、資本預算 (NPV/IRR) 與資金成本。',
    '投資學': '認識各種金融商品 (股票/債券/基金) 特性，與投資組合理論 (Portfolio Theory)。',
    '證照考取': '考取證券商高級業務員、初級會計師或 CFA Level 1，作為入行門票。',
    '總體經濟分析': '關注升息、通膨、GDP 等總經指標，判斷市場景氣循環。',

    // --- New Categories: Medical & Psychology ---
    'Pharmacology': '藥理學。研究藥物如何作用於人體 (藥效動力學) 以及人體如何代謝藥物 (藥物動力學)。',
    'Anatomy': '解剖學。人體構造地圖。了解骨骼、肌肉、神經與臟器的位置與功能，是所有醫學的基礎。',
    'Counseling': '諮商技巧。運用傾聽、同理、面質等技巧，建立安全的諮商關係，引導個案探索自我。',
    'Psychopathology': '變態心理學。研究異常行為與心理疾病 (如憂鬱症、思覺失調症) 的成因與診斷標準 (DSM-5)。',
    'Clinical Trials': '臨床試驗。新藥上市前的嚴格測試流程 (Phase I-IV)，確保藥物的安全性與有效性。',

    // Medical Roadmap
    '基礎醫學/心理學': '修習生解、病理、藥理或普心、發展、社心等核心課程。',
    '實驗室/實習經驗': '進入實驗室學習操作儀器，或至醫院見習臨床實務流程。',
    '國考證照': '通過藥師、醫師、臨床心理師或護理師國家考試，取得執業資格。',
    '臨床專業訓練': 'PGY (不分科住院醫師) 或實習心理師階段，在此階段累積大量臨床案例。',
    '持續教育 (CME)': '醫學進展日新月異，需透過研討會與期刊閱讀，保持專業知識更新。',

    // --- New Categories: Education ---
    'Pedagogy': '教學法。研究「如何教」的學問。根據學生特性設計適合的教學策略，提升學習動機與成效。',
    'Curriculum Design': '課程設計。運用 ADDIE 模型 (分析/設計/開發/實施/評估)，規劃有系統且目標明確的學習課程。',
    'Instructions': '教學指令。清晰、精準地傳達學習任務，讓學生知道該做什麼、如何做。',
    'Assessment': '學習評量。設計多元評量方式 (紙筆測驗/實作/報告)，準確檢核學生的學習成果。',
    'Classroom Mgmt': '班級經營。建立良好的師生關係與班級常規，營造積極正向的學習氛圍。',

    // Education Roadmap
    '教育心理學': '了解人類學習的認知歷程與發展階段 (皮亞傑/維高斯基)。',
    '教學原理與設計': '學習撰寫教案，設定明確的學習目標 (Bloom 認知分類)。',
    '溝通與表達': '訓練口語表達的邏輯與感染力，讓學生(或聽眾)願意聽你說。',
    '數位教學工具': '運用 Kahoot, Notion, AI 助教等科技工具，提升教學互動性。',
    '諮詢與輔導': '學習基本的輔導技巧，協助學生解決學習或生活上的困擾。',

    // --- New Categories: Service ---
    'Customer Service': '顧客服務。不只是微笑，而是預判顧客需求，提供超出預期的服務體驗。',
    'Crisis Management': '危機處理。面對客訴或突發狀況 (如飛機誤點) 時，能冷靜應變，將負面影響降到最低。',
    'Hospitality': '款待精神。源自 "Host" (主人)。把顧客當作朋友招待，讓他們感到賓至如歸。',
    'SOP Adherence': '標準作業程序。服務業講求品質一致性，嚴格遵守 SOP 是專業的表現。',
    'Foreign Language': '外語能力。英語是基本，第二外語 (日/韓/西) 能讓你服務更廣泛的客群，提升競爭力。',

    // Service Roadmap
    '服務禮儀': '學習專業的儀態、應對進退與電話禮儀，展現品牌形象。',
    '情緒管理': '服務業是高度情緒勞動，需學習如何消化負面情緒，保持專業態度。',
    '溝通與防衛': '學習在奧客面前保護自己，運用溝通技巧化解衝突。',
    '多工處理能力': '在忙碌的現場 (如餐廳/機艙)，能同時處理多項任務而不慌亂。',
    '管理階層培訓': '進修排班管理、成本控管、人員培訓技巧，從一線人員晉升為管理者。',

    // --- New Categories: Legal ---
    'Civil Law': '民法。規範私人之間的法律關係 (財產、契約、婚姻)。是生活中最常遇到的法律。',
    'Criminal Law': '刑法。規範犯罪行為與刑罰。界定什麼是犯罪，以及國家如何行使刑罰權。',
    'Litigation': '訴訟程序。民事訴訟法/刑事訴訟法。了解打官司的遊戲規則，如何在法庭上攻防。',
    'Contract Drafting': '合約撰寫。將商業共識轉化為法律文字，封堵風險漏洞，保障雙方權益。',
    'Legal Research': '法律檢索。在浩瀚的法條與判決書海中，找到支持自己論點的依據。',

    // Legal Roadmap
    '法學緒論': '建立法律金字塔 (憲法/法律/命令) 與法律解釋的基礎觀念。',
    '實體法精研': '深入研讀民法、刑法、行政法等核心法典。',
    '程序法掌握': '熟悉訴訟流程，唯有程序正義才能保障實體正義。',
    '案例研析': '閱讀大量判決書，分析法官的判決邏輯與心證形成過程。',
    '法庭實務': '至法庭旁聽或參與模擬法庭，學習律師的辯論技巧與法官的指揮訴訟。',

    // --- GAP FILLING: Missing Skills for New Roles ---

    // Hardware & Firmware
    'Digital Circuit': '數位電路。處理 0 與 1 的電子電路，是所有電腦硬體、手機與晶片的基礎邏輯。',
    'C Language': 'C 語言。程式語言的始祖，執行效率極高，廣泛用於作業系統與嵌入式系統開發。',
    'Assembly': '組合語言。最接近機器的語言，直接對 CPU 下指令。韌體工程師需懂它來進行極致的效能優化。',
    'MCU': '微控制器 (Microcontroller)。將 CPU、記憶體與周邊整合在單一晶片上的微型電腦，家電、遙控器都靠它。',
    'OS Concepts': '作業系統原理。了解 Process、Thread、排程與記憶體管理，確保程式在晶片上穩定運行。',
    'Schematic Reading': '電路圖閱讀。看懂電子電路符號與連接關係，才能在硬體出問題時拿著電表找 Bug。',
    'Physics/Chem': '物理與化學。半導體製程涉及複雜的材料特性與化學反應，基礎科學知識是解題關鍵。',
    'SPC (統計製程管制)': 'Statistical Process Control。運用統計學 (如管制圖) 監控生產過程，預防不良品產生。',
    'JMP/Excel': '數據分析工具。工程師常用 JMP 進行統計分析，或用 Excel 處理實驗數據，找出製程變異的原因。',

    // Medical & Biotech
    'Patient Quality Care': '病人照護品質。以病人為中心，提供安全、舒適且尊嚴的醫療照護服務。',
    'Attention to Detail': '細心謹慎。在醫療與製藥領域，一個小數點的錯誤都可能攸關人命，必須極度專注細節。',
    'License': '專業執照。藥師、醫師等專業人員需通過國家考試取得證書，才能合法執業。',
    'Molecular Biology': '分子生物學。從 DNA、RNA 與蛋白質層次研究生命現象，是研發新藥與生技產品的核心知識。',
    'Lab Techniques': '實驗技術。PCR、西方墨點法、細胞培養等。手巧且精確的實驗操作是產生可信數據的前提。',
    'English Reading': '英文閱讀。最新的醫學新知與研究論文多為英文，需具備快速抓重點的閱讀能力。',
    'Paper Writing': '論文寫作。將研究成果撰寫成符合學術規範的期刊論文，與全球科學界交流。',
    'GCP (臨床試驗規範)': 'Good Clinical Practice。確保臨床試驗符合倫理與科學標準的國際規範，保障受試者人權。',
    'Medical Knowledge': '醫學知識。對疾病機轉、藥物治療有基本認識，才能精確判斷臨床狀況。',

    // Education & Training
    'Subject Expertise': '學科專業。要教別人，自己必須先精通。對數學、英文或程式等該科目的深刻理解。',
    'Online Teaching': '線上教學。面對鏡頭展現熱情，運用數位白板與互動工具，抓住螢幕另一端學生的注意力。',
    'Tech Savvy': '科技素養。熟悉各種軟體與數位工具的操作，能快速解決教學時遇到的技術問題。',
    'Public Speaking': '公眾演說。口條清晰、語調抑揚頓挫，能自信地在眾人面前表達想法，感染聽眾。',
    'Workshop Facilitation': '工作坊引導。設計互動環節，引導參與者討論、發想與實作，而非單向講課。',
    'HRD': '人力資源發展。透過培訓與組織發展策略，提升員工能力，達成組織目標。',
    'Coaching': '教練引導。不直接給答案，而是透過提問引發思考，協助他人發揮潛能找到自己的答案。',

    // Service & Hospitality
    'Hospitality Management': '餐旅管理。結合服務心理學與管理學，提供客人賓至如歸的體驗，同時兼顧營運效率。',
    'Service Mindset': '服務思維。主動發現顧客需求，樂於助人，將「解決客人問題」視為成就感來源。',
    'Safety Procedure': '安全程序。熟悉緊急逃生、急救措施等標準作業流程，確保客人與自身安全。',
    'Service Etiquette': '服務禮儀。從儀態、眼神交流到說話藝術，展現專業且親切的品牌形象。',
    'Teamwork': '團隊合作。服務現場瞬息萬變，需要團隊成員間像齒輪般緊密配合，互相補位。',
    'Store Operation': '門市營運。開店閉店流程、庫存管理、現金盤點等讓一家店正常運作的日常事務。',
    'SOP Development': 'SOP 制定。將成功的經驗標準化為作業流程，讓不同員工都能做出一緻的品質。',
    'Quality Control': '品質控管。堅持標準，不讓任何不完美的餐點或服務送到客人面前。',

    // Finance & Business
    'Financial Modeling': '財務模型。使用 Excel 建構預測模型，模擬不同情境下的財務表現，作為決策依據。',
    'CFA': '特許金融分析師。金融界含金量最高的證照之一，證明具備專業的投資分析能力。',
    'Industry Analysis': '產業分析。研究產業鏈上下游、競爭格局與發展趨勢，判斷誰是未來的贏家。',
    'Financial Planning': '理財規劃。全方位的資產配置建議，包含保險、稅務、退休與投資規劃。',
    'Trust': '信任建立。金融業是販賣「信任」的行業。誠信是業務長久經營的基石。',
    'Market Sense': '市場敏銳度。對股匯市波動有直覺反應，能從新聞頭條嗅出投資機會。',
    'Accounting Principles': '會計原則。GAAP/IFRS。遵循公認的會計準則，確保財報的公平性與一致性。',
    'Integrity': '正直誠信。在面對金錢誘惑與利益衝突時，仍能堅持職業道德，保護客戶利益。',
    'Sales': '業務銷售。不只是賣產品，而是賣解決方案。能挖掘痛點，創造需求，達成雙贏交易。',

    // Marketing & Legal Additions
    'Media Relations': '媒體關係。平時與記者建立良好交情，需要曝光時能獲得報導，危機時能獲得平衡報導。',
    'Brand Strategy': '品牌策略。定義品牌是誰？對誰說話？給人什麼感覺？是品牌經營的靈魂。',
    'Marketing Mix': '行銷組合。4P (Product, Price, Place, Promotion)，行銷人的基本戰術盤。',
    'Creative Direction': '創意指導。帶領設計與文案團隊，將抽象的策略概念轉化為具體的視覺與文字作品。',
    'Analysis': '分析能力。邏輯清晰，能從複雜的現象中抽絲剝繭，找出真正的原因與解法。',
    'Test Case Design': '測試案例設計。想像使用者可能做出的各種奇怪操作，設計嚴謹的測試步驟來抓 Bug。',
    'Selenium/Appium': '自動化測試工具。寫程式來幫你按按鈕、填表單，讓測試工作可以自動化 24 小時執行。',
    'Mistake Proofing': '防呆機制 (Poka-yoke)。設計讓使用者「想做錯都很難」的介面或流程。',
    'Detail-oriented': '注重細節。魔鬼藏在細節裡。一個錯字、一個像素的偏差，都會影響使用者對專業度的觀感。',

    // --- GAP FILLING PHASE 2: Comprehensive Check ---

    // Design: Interior & Architecture
    'AutoCAD': '電腦輔助設計軟體。建築與室內設計界的通用語言，用來繪製精確的平面圖與施工圖。',
    'SketchUp/3Ps Max': '3D 建模軟體。將平面的設計圖立體化，模擬光影與材質，讓業主能預見未來的家。',
    'Space Planning': '空間規劃。動線安排、家具尺寸、收納機能。在有限的坪數內，創造最好用的生活空間。',
    'Esthetics': '美學素養。對美的感知能力。從色彩、材質到比例，打造和諧舒適的視覺體驗。',
    'Revit/BIM': '建築資訊模型。不只是畫圖，而是蓋一棟「數位建築」。整合機電、結構等資訊，減少施工衝突。',
    'Structural Concept': '結構觀念。樑、柱、承重牆。設計要天馬行空，但必須建立在安全穩固的結構基礎上。',
    'Design Thinking': '設計思考。以人為本的解決問題方法。同理使用者需求，定義問題，發想創意，並快速測試。',

    // Design: Video Editing
    'Premiere Pro': '專業剪輯軟體。YouTuber 與電影工業的標準工具，強大的剪輯與後製功能。',
    'After Effects': '特效合成軟體。製作片頭動畫、光劍特效、動態圖表。讓影片不只是剪接，而是充滿魔法。',
    'Rhythm': '剪輯節奏。掌握畫面的呼吸。快節奏讓人緊張興奮，慢節奏讓人放鬆沈浸。',

    // Service: Pet & Hospitality
    'Pet Handling': '寵物保定。用正確且安全的方式固定寵物，保護自己也不讓寵物受傷，是美容與醫療的基礎。',
    'Grooming Skills': '美容手藝。運剪刀如運筆。依照寵物品種與毛流，修剪出可愛又清爽的造型。',
    'Patience': '耐心。面對聽不懂人話的寵物（或小孩、奧客），能保持情緒穩定，溫柔以對。',
    'Observation': '觀察力。從寵物的肢體語言發現牠在緊張，或從客人的眼神發現他在找廁所。見微知著。',
    'Language': '語言能力。英語、日語或韓語。語言是通往世界的鑰匙，能服務更多國際旅客。',
    'Crisis Handling': '危機處理。同 "Crisis Management"。在突發狀況下展現專業與冷靜。',

    // Education & Counseling
    'Career Theory': '職涯理論。Holland 興趣類型、Super 生涯發展階段。用學理基礎來解釋職涯困境，而非憑空建議。',
    'Listening': '傾聽技巧。不打斷、不急著給建議。全神貫注地聽，聽出對方話語背後的情緒與需求。',
    'Resume Editing': '履歷健診。挖掘求職者的亮點，用精準的關鍵字與量化數據，將平凡經歷包裝成專業履歷。',
    'Visual Design': '視覺設計。運用排版、配圖讓教材吸睛。好看的講義能提升學習動機。',
    'EdTech Tools': '教育科技工具。Kahoot, Padlet, Gibson。善用數位工具增加課堂互動與學習成效。',
    'Curriculum Development': '課程發展。同 "Curriculum Design"。從無到有建構一套完整的學習系統。',

    // Legal & IP
    'Patent Law': '專利法。保護發明的法律。定義什麼是新穎性、進步性，確保發明人的心血不被剽竊。',
    'Technical Background': '技術背景。理工科知識。審查晶片專利要懂電路，審查生技專利要懂細胞。是 IP 專家的核心護城河。',

    // Blockchain & DevOps & Other Tech
    'Solidity': '以太坊合約語言。區塊鏈世界的 JavaScript。用來撰寫在以太坊上運作的智能合約。',
    'Web3.js': 'Web3 對接庫。讓網頁前端能跟區塊鏈溝通的橋樑。',
    'Smart Contract': '智能合約。自動執行的程式碼。一旦部署到區塊鏈上就不可竄改，實現「程式即法律」。',
    'Go/Rust': '高效能語言。Go 適合雲端微服務；Rust 以記憶體安全著稱，是開發區塊鏈底層的新寵。',
    'Jenkins/GitLab CI': 'CI/CD 工具。自動化伺服器。設定好腳本，程式碼一上傳就自動跑測試、自動部署。',
    'Cloud': '雲端服務。AWS/GCP/Azure 的統稱。雲端是現代軟體的基礎設施。',
    'C/C++': 'C 與 C++。效能的霸主。作業系統、遊戲引擎、嵌入式系統都靠它們。',
    'English': '英文能力。科技與知識的通用語言。第一手的文件、論壇討論通常都是英文。',

    // Catch-all
    'Logic': '邏輯思維。清晰的推論能力。程式寫作、法律攻防、專案管理，這是一切問題解決的基礎。',

    // --- GAP FILLING PHASE 3: The Final Missing Pieces ---

    // Architect
    'Law & Regulation': '法規與條例。建築法的緊箍咒。熟悉建築法規、都市計畫法、採購法，確保設計不但美觀，更是合法的。',

    // Veterinarian & Psychology
    'Veterinary Medicine': '獸醫學。跨物種的醫學。從解剖生理到內外科用藥，掌握守護動物健康的專業知識。',
    'Surgery': '外科手術。精準的刀法與縫合技巧。在顯微鏡下修補神經血管，或移除病灶，讓生命重獲新生。',
    'Compassion': '憐憫之心。醫者父母心。不只看病，也看見病人(或動物)受苦的靈魂，給予溫暖的關懷。',
    'Quick Thinking': '反應力。急診室或手術台上的生死瞬間。能在高壓下迅速判斷情勢，做出正確醫療決策。',
    'Ethics': '專業倫理。心理師與醫師的底線。嚴守保密原則，不與個案發展雙重關係，維護專業邊界。',

    // Carbon Auditor
    'ISO 14064': '溫室氣體盤查標準。國際通用的碳盤查語言。定義如何量化、監測與報告溫室氣體排放與移除。',
    'GHG Protocol': '溫室氣體盤查議定書。企業碳會計的聖經。提供標準化的框架來測量與管理溫室氣體排放。',
    'Auditing': '稽核技巧。像偵探一樣查核證據。抽樣、訪談、現場勘查，確認企業報告的數據是否真實可靠。',

    // --- GAP FILLING PHASE 4: Roadmap & Skills Complete Audit ---

    // Tech & Hardware
    'API': 'API 串接。應用程式介面 (Application Programming Interface)，不同軟體之間溝通的橋樑。',
    'AWS/Azure/GCP': '公有雲平台。熟練操作其中一種主流雲端服務，是雲端時代的必備技能。',
    'C 語言指標與記憶體': 'C 語言核心。精通指標 (Pointer) 運算與記憶體手動管理，是韌體工程師的基石。',
    '微處理機原理': '計算機大腦。了解 CPU 如何運作、暫存器、中斷向量等底層原理。',
    '通訊協定 (UART/I2C)': '硬體溝通語言。搞懂時序圖 (Timing Diagram)，讓晶片之間能正確傳話。',
    'RTOS 即時作業系統': 'Real-time OS。在嚴格時限內完成任務的作業系統，攸關嵌入式系統的穩定性。',
    'Linux Kernel': 'Linux 核心。深入作業系統心臟，撰寫驅動程式，直接掌控硬體資源。',
    '數位邏輯設計': '邏輯電路基礎。利用 AND、OR、NOT 邏輯閘堆疊出複雜的運算功能。',
    'Verilog 語法': '硬體描述語言。用寫程式的方式來設計實體電路。',
    '計算機結構': '電腦解剖學。CPU、記憶體、I/O 裝置如何協同工作運算。',
    'IC 設計流程 (APR)': '自動佈局繞線 (Automatic Place and Route)。從邏輯轉化為實體電路佈局的關鍵步驟。',
    '系統晶片 (SoC) 架構': 'System on Chip。將 CPU、GPU、通訊模組全都塞進一顆晶片中的精妙設計。',
    '半導體物理': '電子物理學。理解電洞、電子移動率、能帶理論等微觀機制。',
    '單元製程 (黃光/蝕刻)': '黃光微影與蝕刻。晶片製造中最昂貴且關鍵的雕刻技術。',
    '統計分析工具': '數據辦案。利用 JMP 或 Excel 分析製程數據，揪出影響良率的兇手。',
    '實驗設計 (DOE)': 'Design of Experiments。用最少的實驗次數找出最佳製程參數搭配。',
    '良率提升工程': 'Yield Improvement。透過數據分析持續優化製程，追求 100% 完美良率。',
    'Linux 系統管理': '維運基礎。熟悉 User 管理、權限設定、Shell Script 自動化指令。',
    '版本控制 (Git)': '時光機。管理程式碼變更歷史，讓多人協作開發不打架。',
    '自動化構建工具': 'CI/CD 工具 (如 Jenkins/GitLab CI)。讓程式碼從測試到部署完全自動化。',
    '容器化生態系': 'Docker & K8s。現代化應用程式的封裝與調度標準。',
    'SRE 可靠性工程': 'Site Reliability Engineering。用軟體工程的方法解決系統維運問題。',
    '軟體測試理論': 'QA 基礎。黑箱測試、白箱測試、單元測試的觀念與實作。',
    '測試案例設計': '抓 Bug 的網子。設想各種極端與邊界使用情境 (Test Cases)。',
    '自動化測試工具': 'Selenium/Appium。寫程式讓機器人幫你重複執行繁瑣的測試工作。',
    '效能測試': '壓力測試。模擬大量使用者同時上線，測試系統極限。',
    '持续集成測試': 'CI Testing。每次程式碼提交都自動運行測試，確保沒有改壞原有功能。',
    '區塊鏈原理': '去中心化帳本。區塊鏈運作的共識機制、雜湊函數、非對稱加密。',
    '智能合約開發 (Solidity)': 'Smart Contract。在以太坊區塊鏈上運行的自動化程式碼。',
    '前端與錢包串接': 'Web3 入口。使用 Web3.js 讓網頁能連接 MetaMask 錢包進行交易。',
    '資安與審計': 'Code is Law。智能合約一旦上鏈無法修改，程式碼安全性審計至關重要。',
    'Defi/NFT 應用': '去中心化金融與非同質化代幣。探索區塊鏈技術的實際落地應用。',

    // Medical & Science
    '藥理學基礎': '藥物動力學。藥物在人體內的吸收、分佈、代謝與排泄 (ADME) 機制。',
    '國家藥師執照考取': '執業執照。通過高難度的國家考試，取得藥師專業資格。',
    '醫院實習': '臨床洗禮。在醫院藥局實際輪調，學習處方調劑與與醫療團隊合作。',
    '臨床藥學': '醫藥分業核心。參與查房，評估用藥適當性，提供藥物治療建議。',
    '藥事行政管理': '藥局管家。藥品採購、庫存管理、管制藥品登記等行政事務。',
    '生物化學/分生': '生命密碼。DNA 複製、蛋白質合成、酵素作用的分子機制。',
    '實驗室操作規範': 'GLP。實驗室安全與標準作業流程，確保數據準確且可追溯。',
    '實驗數據統計': '生物統計。運用統計方法驗證實驗結果的顯著性 (P-value)。',
    '學術論文發表': '科學貢獻。將研究發現撰寫成論文，投稿至國際期刊。',
    '轉譯醫學': 'Bench to Bedside。致力於將基礎研究成果轉化為臨床治療應用。',
    '醫藥相關背景': '本科系門檻。具備醫學、藥學、護理或生命科學相關學位。',
    'GCP 證書': '臨床試驗規範。保護受試者權益與試驗數據品質的國際標準。',
    '臨床研究助理 (CRA)': '試驗守門員。巡視醫院試驗中心，確保試驗按計畫書執行。',
    '專案管理能力': 'Project Management。掌控臨床試驗的進度、預算與風險。',
    '跨國試驗管理': '全球視野。協調不同國家的法規與試驗中心，執行大規模臨床試驗。',
    '心理系畢': '心理學基礎。從普通心理學到統計學，建立對人類行為的科學理解。',
    '臨床心理所碩士': '專業養成。深入研讀變態心理學、心理衡鑑與心理治療理論。',
    '全職實習一年': '駐地實習。在資深督導帶領下實際接案，將理論應用於臨床實務。',
    '臨床心理師高考': '專業證照。取得臨床心理師資格的國家考試。',
    '執業執照申請': '開業門票。向衛生主管機關申請執業登記，正式掛牌。',
    '獸醫系畢 (5年)': '獸醫養成。涵蓋基礎醫學、臨床診斷與內外科實習的紮實訓練。',
    '獸醫師國考': '執業資格。通過國家考試取得獸醫師證書。',
    'PGY 臨床訓練': '畢業後一般醫學訓練。在教學動物醫院各科輪轉，累積臨床經驗。',
    '專科醫師訓練 (如眼科/外科)': '專精深造。選擇特定科別深入鑽研，成為該領域專家。',
    '自行開業': '院長之路。建立自己的動物醫院，兼顧醫療品質與醫院經營。',

    // Design & Arts
    '設計圖學基礎': '視覺語言。點線面的構成、投影幾何與圖學規範。',
    '繪圖軟體精通': '數位畫筆。精通 AutoCAD、SketchUp、Revit 等設計軟體。',
    '施工工法與法規': '築夢踏實。了解各種建材特性、施工細節與相關建築法規。',
    '工地監工實務': '設計落地。在吵雜的工地中確保師傅按圖施工，解決現場問題。',
    '乙級室內裝修證照': '專業認證。室內設計從業人員的國家級技術士證照。',
    '建築系畢 (5年)': '建築設計訓練。無數個熬夜做模型與評圖的日子，培養空間美學。',
    '建築事務所實習': '師徒傳承。實際參與競圖、法規檢討與施工圖繪製。',
    '建築師高考 (超難)': '建築界桂冠。錄取率極低，是獲得建築師執照的終極關卡。',
    '開業或是合夥': '建築實踐。成立事務所，貫徹自己的建築理念。',
    '著名建築獎項': '榮耀時刻。獲得普立茲克獎或其他國際獎項，獲得業界認可。',
    '剪輯軟體操作': '後製魔法。熟練 Premiere/Final Cut 快捷鍵，剪輯快狠準。',
    '鏡頭語言與敘事': '影像說故事。運鏡角度、構圖美學與剪輯節奏的掌握。',
    '動態圖形 (Motion Graphics)': '視覺加分。利用 After Effects 製作片頭、特效與資訊圖表。',
    '風格建立': '個人特色。培養獨特的視覺風格與敘事手法，讓觀眾一眼認出。',
    '導演思維': '綜觀全局。從腳本發想、現場拍攝到後期製作的完整創作視野。',

    // Marketing & Content
    '利基市場 (Niche) 選擇': '精準定位。在紅海中找到屬於自己的藍海主題與受眾。',
    '內容產出SOP': '高效創作。建立標準化的腳本、拍攝與剪輯流程，穩定產出。',
    '粉絲增長策略': '流量密碼。利用演算法規則、話題操作與互動，滾動粉絲數。',
    '變現模式建立': '商業化。將流量轉化為收入，如業配、周邊商品、線上課程。',
    '團隊化經營': '規模擴張。組建剪輯、企劃團隊，從個人創作者轉型為媒體公司。',
    '新聞寫作技巧': '倒金字塔。標題吸睛、導言破題，快速精準傳遞核心資訊。',
    '媒體生態了解': '媒體關係。了解各家媒體屬性、記者路線與截稿時間。',
    '公關策略規劃': '形象工程。規劃長期的品牌溝通訊息，建立利害關係人信任。',
    '危機處理演練': '防火演習。模擬負面新聞發生時的應對流程與聲明稿撰寫。',
    '品牌聲譽管理': '輿情監測。長期追蹤品牌聲量，維護品牌在公眾心中的形象。',
    '行銷基礎與實務': '行銷邏輯。4P (產品/價格/通路/推廣) 與 STP 市場定位策略。',
    '消費者行為分析': '洞察人心。利用心理學與數據分析，了解消費者「為什麼買」。',
    '品牌識別系統 (CIS)': '品牌臉譜。Logo、色彩、字體等視覺規範的建立與管理。',
    '整合行銷溝通 (IMC)': '全方位出擊。整合廣告、公關、社群等管道，傳遞一致的品牌訊息。',
    '品牌總監': '品牌守護者。掌管品牌發展大方向，確保所有決策不違背品牌核心價值。',

    // Business & Finance
    '會計與財管基礎': '商業語言。讀懂資產負債表、現金流量表，評估公司財務體質。',
    'CFA 證照考取': '金融黃金證書。特許金融分析師，投資領域最具權威的國際證照。',
    '產業研究方法': 'Top-down 分析。從總體經濟、產業供應鏈到個別公司競爭力分析。',
    '財務估值模型': '估價能力。建立 DCF 現金流折現模型，計算公司的合理股價。',
    '基金經理人': '操盤手。掌管巨額資金，在金融市場進行投資決策。',
    '金融證照模組': '專業門檻。依序考取證券、信託、保險、期貨等必備從業證照。',
    '銷售與溝通技巧': '信任建立。精準提問挖掘客戶需求，並清楚說明產品優勢。',
    '理財規劃實務': '財務管家。協助客戶規劃退休、購屋、子女教育等人生財務目標。',
    '高資產客戶經營': 'VVIP 服務。為金字塔頂端客群提供客製化、私密且尊榮的服務。',
    '私人銀行家': '頂級金融顧問。服務家族辦公室，處理跨境稅務與財富傳承。',
    '中級會計學': '會計魔王。深入探討公報規範、資產評價與收入認列等複雜議題。',
    'CPA 會計師執照': '會計師金牌。錄取率低，是執行簽證業務的唯一資格。',
    '事務所審計經驗': '查帳修煉。進入四大會計師事務所，大量接觸不同產業的財報。',
    '稅務法規專研': '節稅專家。精通所得稅、營業稅、遺贈稅等稅務法規。',
    '財務長 (CFO)': '財務總管。參與企業重大營運決策，掌管資金調度與投資策略。',

    // Law & Service
    '法律系畢': '法學訓練。建立法律邏輯、法感與能夠使用精確法律文字的能力。',
    '律師高考 (及格率低)': '獨木橋。錄取率極低，通往律師執業資格的唯一路徑。',
    '實習律師 (5個月)': '拜師學藝。在指導律師帶領下學習開庭、撰狀與當事人應對。',
    '受雇律師': '實戰積累。在律師事務所處理各類訴訟案件，累積實務經驗。',
    '合夥律師': '經營者。成為事務所合夥人，共同承擔事務所盈虧與管理責任。',
    '理工背景+法律知識': '雙刀流。同時具備技術背景與法律專業，是專利領域稀缺人才。',
    '專利師證照': '專利權威。通過國家考試，取得代理專利申請的專業資格。',
    '專利事務所磨練': '文字工匠。撰寫高品質專利說明書，與各國專利局審查官攻防。',
    '企業內部智財法務': 'IP 守門員。制定企業智慧財產權策略，管理專利佈局與侵權風險。',
    '智財顧問': '策略軍師。協助企業透過專利授權獲利，或規避競爭對手的專利壁壘。',
    '寵物美容證照 (C/B/A級)': '技術認證。從基本的 C 級到教練級的 A 級，技術含金量分級。',
    '助理實務經驗': '紮馬步。從洗狗、吹毛、剪指甲做起，學習保定與安撫寵物。',
    '獨立作業美容師': '獨當一面。能根據不同犬種特性，獨立完成美容造型修剪。',
    '特殊造型進修': '加值服務。學習染色、雕花、萌系修剪，提升客單價與競爭力。',
    '開設工作室': '創業圓夢。建立自己的美容品牌，經營熟客關係。',

    // Education & Others
    '教學設計理論 (ADDIE)': '課程開發模型。分析 Analysis、設計 Design、發展 Development、實作 Implementation、評估 Evaluation。',
    '多媒體教材製作': '視覺化教學。運用 PPT、Canva、影音剪輯製作吸睛的教學素材。',
    '成人學習心理學': '成人教育。了解成人學習動機與障礙，設計實用導向的教學內容。',
    '線上課程平台操作': '數位運營。熟悉 Teachable、Hahow 等後台操作，管理學生與課程數據。',
    '學習數據分析': '成效優化。分析完課率、測驗成績，找出學生痛點並迭代課程。',
    '學科專業知識': '教學根本。對所教科目有深刻且廣泛的理解，能深入淺出地講解。',
    '數位教學工具 (Zoom/Meet)': '遠距教學。精通視訊軟體操作、白板工具與線上分組討論技巧。',
    '溝通表達能力': '口條訓練。說話清晰、邏輯分明，能將複雜觀念轉化為簡單語言。',
    '建立個人品牌': '名師之路。透過社群經營與口碑行銷，打造個人教學品牌。',
    '教學成效口碑': '信譽積累。學生的進步分數與推薦，是最好的招生廣告。',
    '公眾演說技巧': '舞台魅力。克服緊張，運用肢體語言與聲音表情吸引學員注意力。',
    '引導技術 (Facilitation)': '促進參與。不僅是講授，更能引導學員討論、反思與共創。',
    '人力資源發展 (HRD)': '人才策略。將培訓與企業營運目標結合，規劃員工職涯發展路徑。',
    '顧問諮詢能力': '問題解決。診斷企業績效落差原因，提出客製化的培訓解決方案。',
    '專業領域深耕': '持續精進。保持在特定專業領域的知識領先，成為意見領袖。',
    '前台/房務實務': '飯店現場。熟悉入住退房流程、客房清潔標準與備品管理。',
    '顧客服務技巧': '服務意識。察言觀色，主動滿足客人潛在需求，創造感動服務。',
    '營運管理知識': '飯店生意經。了解定價策略、住房率控管 (Yield Management) 與成本分析。',
    '外語能力': '國際溝通。具備英日語等外語能力，服務來自世界各地的旅客。',
    '領導統御': '團隊帶領。激勵前線員工士氣，處理部門間的衝突與協調。',
    '外語檢定': '語言證書。多益 (TOEIC) 或其他語言檢定成績，是航空業的面試門檻。',
    '航空面試準備': '形象塑造。練習廣播詞、美姿美儀與團體討論面試技巧。',
    '職前安全訓練': '魔鬼訓練。熟記緊急程序、逃生設備操作，確保飛航安全。',
    '客艙服務實務': '空中服務。在有限空間內提供優雅餐飲服務，並處理乘客突發狀況。',
    '座艙長晉升': '管理責任。成為客艙經理，統籌該航班的所有服務與安全應變。',
    '基層服務經驗': '現場歷練。從外場服務生做起，了解顧客抱怨點與作業流程瓶頸。',
    '店長管理職': '門市當家。負責單店的業績達成、人員排班與物料訂貨。',
    '多店管理技巧': '區域督導。同時管理多家分店，確保標準作業流程 (SOP) 落實。',
    '財務報表分析': '數據決策。解讀各店損益表，找出節省成本與提升毛利的機會。',
    '連鎖加盟策略': '商業複製。建立標準化複製模式，協助加盟主成功展店。',

    // New Skills (Catch-all)
    'AutoCAD': '工程製圖。建築與室內設計必備的精確繪圖軟體。',
    'SketchUp/3Ps Max': '3D 建模。快速建立空間模型與擬真渲染。',
    'Space Planning': '空間規劃。妥善安排動線與機能，讓空間好用又舒適。',
    'Esthetics': '美學素養。對色彩、光影、材質比例的敏銳度。',
    'Revit/BIM': '建築資訊模型。現代化建築設計標準，整合設計與施工資訊。',
    '結構概念': '結構概念。了解樑柱牆版對建築支撐的原理。',
    '設計思考': '設計思考。以人為本，發掘問題並尋求創新解決方案。',
    'Premiere Pro': '專業剪輯。Adobe 出品的業界標準非線性剪輯軟體。',
    'Rhythm': '剪輯節奏。掌握畫面切換的時機，引導觀眾情緒。',
    '民刑法': '民刑法。法律人的基石，規範私人關係與國家刑罰。',
    'Debate': '辯論與攻防。邏輯清晰的言詞交鋒，捍衛立場。',
    'Writing': '法律寫作。撰寫嚴謹、精確的法律書狀與合約。',
    'Negotiation': '談判協商。在衝突中尋求雙贏或最佳利益的溝通藝術。',
    'Patent Law': '專利法。保護發明創意的法律規範。',
    'Technical Background': '技術背景。本身具備理工科系的專業知識。',
    'Pet Handling': '寵物保定。安全地控制寵物，避免受傷或咬傷。',
    'Grooming Skills': '美容技術。洗剪吹整染，讓毛小孩容光煥發。',
    '耐心': '無比耐心。面對不受控的動物或奧客，仍保持專業。',
    '觀察力': '敏銳觀察。發現寵物皮膚病變或客戶未說出口的需求。',
    'Career Theory': '職涯理論。Holland 類型論、生涯建構理論等學理依據。',
    '積極傾聽': '全神貫注地聽，聽出話語背後的情緒、需求以及對方未說出口的故事。',
    'Resume Editing': '履歷健檢。協助修改履歷，Highlight 個人優勢。',
    'EdTech Tools': '教育科技。運用 Kahoot, Padlet 等數位工具活化教學。',
    '課程開發': '教材開發。從無到有產出有系統的教學內容。',
    '公眾演說': '公眾演說。自信地在眾人面前表達想法。',
    '人力資源發展': '人力資源發展。專注於員工培訓與組織學習。',
    '餐旅管理': '餐旅管理。涵蓋餐飲與旅館的營運知識。',
    '服務熱忱': '服務熱忱。樂於助人，從服務中獲得成就感。',
    '安全程序': '安全程序。嚴格遵守的標準作業規範，攸關性命。',
    '門市營運': '門市營運。開店關店、收銀結帳、庫存盤點等日常庶務。',
    'SOP 制定': 'SOP 制定。撰寫標準作業程序，確保品質一致。',
    '財務建模': '財務建模。製作 Excel 模型預測未來現金流與獲利。',
    'CFA 證照': 'CFA 特許金融分析師。金融業含金量極高的國際證照。',
    '產業分析': '產業分析。剖析產業結構與競爭五力。',
    '理財規劃': '理財規劃。全方位的資產配置建議。',
    '信任感': '信任感。金融服務的基礎，讓客戶放心將資產交給你。',
    '市場嗅覺': '市場嗅覺。對金融市場波動的敏銳度。',
    '會計原則': '會計原則。借貸法則、權責發生制等會計基礎。',
    '稅務法規': '稅務法規。所得稅、營業稅等相關法律規定。',
    '誠信正直': '誠信正直。會計師與法律人的職業道德底線。',
    '媒體關係': '媒體關係。與記者建立良好互動，爭取曝光機會。',
    '行銷組合': '行銷組合。產品、價格、通路、推廣的策略搭配。',
    '創意指導': '創意指導。引導設計與文案方向，確保品質。',
    '腳本語言': '腳本撰寫。Shell Script 或 Python，自動化重複性工作。',
    '測資設計': '測資設計。設計能找出 Bug 的有效輸入資料。',
    'Selenium/Appium': '自動化測試框架。網頁與 App 測試神器。',
    '防呆機制': '防呆機制。設計讓使用者不易犯錯的系統。',
    '細節導向': '細節控。對 1px 的位移或一個錯字都無法容忍。',
    'Web3.js': 'Web3 開發庫。與以太坊節點溝通的 JavaScript 函式庫。',
    '智能合約': '智能合約。區塊鏈上的自動執行程式。',
    'Go/Rust': '以及效能著稱的程式語言。區塊鏈底層開發常用語言。',
    '諮商技巧': '建立安全的治療關係，運用同理心與專業技術，陪伴個案探索自我與解決問題。',
    '變態心理學': '深入了解焦慮、憂鬱等各類心理疾病的症狀、成因與治療準則。',
    '同理心': '不只是同情，而是能感同身受地理解他人的情緒與處境，卻不陷入其中。',
    '專業倫理': '嚴格遵守保密原則與界線，以個案的最大福祉為優先，不做傷害個案的事。',
    '獸醫學': '獸醫學。跨物種的醫療專業。',
    'Instructional Design': '教學設計。系統化的課程規劃流程。',

    // Final Polish
    '危機處理': '危機管理。化危機為轉機的處理藝術。',
    '活動企劃': '活動企劃。舉辦記者會、發布會的統籌能力。',

    // --- GAP FILLING PHASE 5: The Last Mile ---
    '內容行銷': '內容行銷。不只是打廣告，而是提供有價值的內容讓顧客主動找上門。',
    '創造力': '創造力。跳脫框架思考，為舊問題找到新解方。',
    '影片剪輯': '影音後製。熟練使用 PS, LR, PR 等軟體修圖與剪片。',
    'Personal Branding': '個人品牌。在社群媒體上經營自己的專業形象與影響力。',
    '社群經營': '社群經營。懂演算法、懂梗，知道如何在 FB/IG/Threads 上引發話題。',
    'Python/Java': '後端雙刀流。Python 擅長數據與 AI，Java 擅長大型企業系統，兩者皆為後端主流。',
    'ISO 查證員課程': '碳查證員訓練。學習如何根據 ISO 14064 標準進行溫室氣體查證。',
    '環境工程基礎': '環工概論。了解水、空氣、廢棄物處理的基本原理與法規。',
    '能源管理系統': 'ISO 50001。協助企業建立能源基線，找出節能減碳的潛力點。',
    '碳權交易機制': '碳市場。了解碳稅、碳費與碳權交易的運作邏輯。',
    '企業永續策略': 'ESG 藍圖。將永續發展目標 (SDGs) 融入企業核心商業策略。',
    '企業培訓講師': '內部講師。將自己的專業經驗轉化為課程，傳承給公司同仁。',
    '職涯諮詢師證照 (CDA/GCDF)': '專業認證。國際認可的職涯發展諮詢師證照，執業的品質保證。',
    '心理/人資背景': '助人專業。具備心理學或人力資源管理的學術背景。',
    '諮詢實務累積': '個案經驗。透過實際的一對一諮詢，累積對不同職涯問題的處理手感。',
    '邏輯思維': '邏輯思考。條理分明地分析問題，找出因果關係。',

    // --- GAP FILLING PHASE 6: Teacher Skills Expansion ---
    '班級經營': '班級經營。建立班級規矩與獎懲制度，營造良好的學習氛圍。',
    '學科教學': '學科教學。將國語、數學或社會等知識點，用孩子能聽懂的話教給他們。',
    '兒童發展': '兒童發展。了解從幼兒到青少年的身心發展階段與需求。',
    '學科專業': '學科專業。在國文、英文、數學或理化等特定專科領域有深厚的知識底蘊。',
    '青少年心理': '青少年心理學。理解青春期孩子的叛逆、迷惘與同儕關係焦慮。',
    '升學輔導': '升學輔導。協助學生準備會考、學測，分析落點與志願選填。',
    '幼兒教育': '幼兒教育。專注於 0-6 歲學齡前兒童的啟蒙教育與保育。',
    '活動設計': '活動設計。設計適合幼兒大肌肉、小肌肉發展的遊戲與教案。',
    '安全照護': '安全保育。時刻注意幼兒的身體狀況與環境安全，預防意外發生。',

    // --- GAP FILLING PHASE 7: Teacher Roadmap Content ---
    '修習教育學分': '教育學程。在大學期間修習教育心理學、教學原理等師培課程。',
    '教師檢定考': '教檢。考取教師證的筆試關卡，通過後才能進行教育實習。',
    '半年教育實習': '實習老師。回到學校現場，跟著輔導老師實際演練教學與班級經營。',
    '教師甄試 (教甄)': '正式教師考試。競爭激烈的筆試與試教面試，錄取後成為有保障的正式教師。',
    '代理代課歷練（累積經驗）': '流浪教師。在考上正式教師前，至各校擔任代理或代課教師累積實戰經驗。',
    '學科系所畢業': '本科專業。國文系、數學系或物理系等學士學位，是成為該科老師的基礎。',
    '中等教育學程': '中學師資培育。專注於青少年發展與學科教學法的師資訓練課程。',
    '教師檢定與實習': '資格取得。完成半年全職實習並通過檢定，取得合格教師證。',
    '學科展覽或競賽指導': '科展指導。帶領學生進行專題研究，參加科學展覽或學科能力競賽。',
    '幼保/幼教系畢': '幼教專業。學習幼兒保育、發展與教學的科班出身。',
    '幼兒園教師證': '幼師證。具備在幼兒園擔任合格教師的法定資格。',
    '保母證照': '技術士證。具備照顧嬰幼兒生活起居的專業技術認證。',
    '教具製作能力': '手作教具。利用各種素材製作適合幼兒操作的學習輔具。',
    '蒙特梭利/華德福培訓': '特色教學法。進修特定的幼教派別理論與實務，提升教學廣度。',

    // --- PHASE 2 EXPANSION GLOSSARY ---

    // Engineering
    '結構分析': '結構分析。計算建築物在地震、強風下的受力狀況，確保不會倒塌。',
    '建築法規': '營建法規。建築法、採購法等工程相關法律。',
    '工地監造': '監造。在工地現場監督施工品質與進度。',
    '力學基礎 (靜力/動力)': '工程力學。土木工程的物理基礎，計算力的平衡與運動。',
    '土木技師執照': '專業證照。簽證公共工程必備的國家級證照。',
    'SolidWorks': '3D 機構設計軟體。機械工程師繪製零件圖與組裝圖的吃飯工具。',
    '熱力學': '熱力學。研究能量轉換與熱傳遞的科學。',
    '材料科學': '材料科學。了解金屬、塑膠等材料特性，選擇最適合的材質。',
    '機電整合': '機電整合。結合機械與電子控制，讓機器智能化。',
    'ISO 14001/45001': '環安衛管理系統。國際通用的環境管理與職業安全衛生標準。',
    '風險評估': '風險評估。辨識工作場所的潛在危害，評估發生機率與嚴重度。',
    '化學品安全': '化學品安全。毒性化學物質的標示、儲存與洩漏處理。',

    // Public Sector & Law
    '行政法': '行政法。規範政府機關運作與人民權利義務關係的法律。',
    '公共服務': '公共服務精神。以國家與人民利益為優先的服務態度。',
    'Criminal Law': '刑法。定義犯罪行為與刑罰的法律。',
    'Legal Reasoning': '法律邏輯。運用三段論法，將法律適用於具體個案的推論過程。',
    '犯罪偵查': '調查技巧。蒐集證據、還原真相的專業能力。',
    '執法能力': '執法能力。依法執行公權力，排除違法行為。',
    '體能': '體能。良好的心肺耐力與肌力，應付高強度的勤務需求。',
    '司法官學院受訓': '職前訓練。通過司法官考試後，需接受為期兩年的實務與理論訓練。',
    '調查局特考': '國安守門員。錄取率極低，需通過體能測驗與口試的國家考試。',

    // Art & Media
    '說故事能力': '說故事。用影像、圖像或文字，建構引人入勝的情節與角色。',
    '運鏡攝影': '攝影美學。光影、構圖、運鏡的藝術。',
    '手繪技巧': '繪畫能力。主要指手繪或電繪的造型能力。',
    '色彩學': '色彩學。色相、明度、彩度的搭配與心理效應。',
    '打版': '打版。將服裝設計圖轉化為立體布料裁片的技術。',
    '紡織學': '織品學。認識棉、麻、絲、人造纖維等布料特性。',
    '縫紉': '縫紉工藝。車縫、刺繡等製作服裝的技術。',

    // Sports & Health
    'Anatomy': '解剖學。了解人體骨骼、肌肉結構與功能。',
    'Exercise Physiology': '運動生理學。運動對人體心肺、代謝系統的影響。',
    '復健醫學': '復健醫學。協助病人恢復身體功能的醫療專業。',
    '徒手治療': '徒手治療。運用雙手進行關節鬆動、按摩等治療手法。',
    '營養學': '營養學。碳水、蛋白質、脂肪等營養素對健康的影響。',
    '飲食規劃': '菜單設計。根據熱量與營養需求，規劃合適的飲食內容。',
    'HACCP 證照': '食品安全管制系統。確保食品加工過程衛生安全的認證。',

    // Uniformed Services
    '防身術': '防身術。柔道、跆拳道或擒拿術，保護自己與壓制歹徒。',
    '消防技能': '滅火戰術。瞄子操作、水線佈署、通風排煙等火場作戰技能。',
    'EMT 緊急救護': '緊急救護技術。CPR、AED、止血包紮等到院前急救處置。',
    '紀律': '紀律。服從命令、遵守規範的軍人本色。',
    '戰略規劃': '戰略規劃。在大格局下思考敵我形勢，制定致勝計畫。',
    '武器操作': '武器操作。步槍、手槍、火砲等各式武器的熟練使用。',

    // --- PHASE 2 ROADMAP GAP FILLING ---

    // Engineering Roadmap
    '結構分析': '結構計算。利用軟體分析建築結構在地震或強風下的安全性。',
    '工程法規': '營建法規。熟悉建築法、政府採購法等相關法律規範。',
    '測量學實習': '工地測量。使用全站儀、水準儀進行精確的距離與高程測量。',
    '工程圖學': '製圖基礎。學習投影幾何，看懂三視圖與畫出標準的工程圖。',
    '機械加工實習': '實作訓練。親手操作車床、銑床等工具機，了解加工原理。',
    '自動控制原理': '控制系統。學習如何讓機器依照指令精確動作。',
    '有限元素分析 (FEA)': '電腦模擬。用電腦模擬產品受力狀況，優化設計。',
    '專案開發經驗': '實戰經驗。從無到有完成一個機構設計專案的完整流程。',
    '工安法規詳讀': '法規研讀。熟讀職業安全衛生設施規則等重要條文。',
    '甲級/乙級職業安全衛生業務主管': '必備證照。擔任職安衛管理人員的法定資格。',
    '環工技師': '專業技師。處理空污、水污、廢棄物等環保工程的高級證照。',
    '緊急應變演練': '救災演習。規劃火災、洩漏等意外事故的疏散與處理流程。',
    '企業永續推動': 'ESG 實踐。協助企業落實節能減碳與社會責任計畫。',

    // Public Sector Roadmap
    '法學緒論': '法律入門。認識法律的基本概念、體系與原理原則。',
    '行政學': '政府管理。研究政府組織運作、政策制定與執行的學問。',
    '高普考/特考準備': '國考衝刺。準備國家考試，爭取成為正式公務人員。',
    '實務訓練': '在職訓練。考上後需分發至單位進行實做學習，考核通過才算正式任用。',
    '公共管理進修': '在職進修。學習新的公共治理觀念，提升行政效率。',
    '法律系畢': '科班出身。具備完整的法學教育背景，是司法官考試的基礎。',
    '律師/司法官國考 (極難)': '頂尖對決。錄取率極低的國家考試，通過者皆為法學菁英。',
    '候補法官/檢察官': '實習階段。在資深法官或檢察官指導下，實際參與辦案。',
    '實任司法官': '獨當一面。正式成為擁有獨立審判權或偵查權的司法官。',
    '幹部訓練所受訓': '展抱山莊。調查局學員的秘密訓練基地，接受嚴格的體能與專業訓練。',
    '外勤據點歷練': '基層歷練。分派至各地調查站，在第一線執行蒐證與調查任務。',
    '專案小組辦案': '重大案件。加入黑金、毒品或國安等專案小組，偵辦指標性案件。',
    '情報分析專業': '情報研判。將蒐集到的零碎情報拼湊成完整樣貌，提供決策參考。',

    // Art & Media Roadmap
    '短片創作': '影像實驗。用有限的資源嘗試拍出自己的創意短片。',
    '劇組實習 (場記/助導)': '跟班學習。進入劇組，從最基層的工作開始了解拍片沒幕。',
    '廣告/MV 導演': '商業洗禮。在極短的秒數內講完故事，並滿足客戶需求。',
    '長片劇本開發': '說長故事。挑戰 90 分鐘以上的完整電影劇本創作。',
    '影展參展': '國際視野。將作品投遞至國內外影展，尋求曝光與資金。',
    '素描基礎': '造型能力。訓練觀察光影、比例與結構的基本功。',
    '軟體電繪技巧': '數位創作。熟練 Procreate, PS 等軟體與繪圖板的操作。',
    '作品集累積': '實力證明。整理自己最好的作品，展現風格與能力。',
    '社群經營': '粉絲互動。在 IG/Twitter 上發布作品，累積粉絲群。',
    '周邊商品開發': 'IP 變現。將插畫印成貼紙、明信片或 T-shirt 販售。',
    '服裝構成學': '人體與布料。了解人體線條與布料如何包覆身體。',
    '打版與縫紉': '製作能力。親手畫版型並車縫出成衣。',
    '設計師助理': '學徒生涯。跟在資深設計師身邊學習實務流程與細節。',
    '個人系列發表': '畢業展演。設計並製作一系列服裝，登上伸展台發表。',
    '創立品牌': '商業模式。成立自己的品牌，面對市場的考驗。',

    // Sports & Health Roadmap
    '解剖學基礎': '人體地圖。熟記骨骼、肌肉名稱與起止點。',
    '國際證照 (ACSM/NSCA)': '黃金證照。考取國際公認的四大體適能證照之一。',
    '實習教練': '跟課學習。觀察資深教練如何教學與修正學生動作。',
    '專項進修 (壺鈴/TRX)': '武器擴充。學習使用各種訓練器材，增加教學豐富度。',
    '自由教練': '個人接案。不隸屬於健身房，自行開發客戶與租借場地。',
    '物理治療系畢': '國考門檻。必須在大學物理治療系畢業並實習合格。',
    '國考證照': '執業資格。通過國家考試取得物理治療師證書。',
    '皮拉提斯/紅繩證照': '自費市場。進修目前市場熱門的運動治療技術。',
    '骨科/神經專科': '專科深造。專注於特定領域的治療技術，如運動傷害或中風復健。',
    '成立治療所': '自行開業。開設物理治療所，服務社區民眾。',
    '食品營養系畢': '學術基礎。學習生物化學、膳食療養學等專業課程。',
    '營養師國考': '專業門檻。錄取率約 15% 的國家考試。',
    '糖尿病衛教資格': '衛教專長。取得 CDE 證照，專門照顧糖尿病患的飲食。',
    '運動營養專長': '跨界整合。結合營養與運動知識，協助運動員提升表現。',

    // Uniformed Services Roadmap
    '警察特考/警專': '入行門檻。通過國家考試或報考警察專科學校。',
    '入校受訓': '養成教育。在警校接受 1-2 年的法律、體能與射擊訓練。',
    '派出所實務': '基層磨練。處理民眾糾紛、巡邏開單等第一線勤務。',
    '專業單位 (刑警/交警)': '專責分工。依志願選填刑事、交通或外事等專業單位。',
    '警官晉升': '管理階層。通過警大考試或升官等考試，晉升為巡官以上幹部。',
    '消防特考/警專': '入行途徑。考取消防警察特考或就讀警專消防科。',
    '消防訓練中心受訓': '魔鬼訓練。在竹山訓練中心接受高強度的體能與救災技能訓練。',
    '分隊實務': '打火兄弟。分發至各地消防分隊，執行救災救護勤務。',
    'EMT-P 高級救護員': '神之手。接受 1280 小時訓練，可執行插管、給藥等高級救命術。',
    '特搜隊受訓': '精英部隊。接受搜救犬、搜救器材操作等特殊訓練，執行重大災害救援。',
    '軍校/ROTC/志願役': '從軍之路。選擇就讀官校或報考志願役士兵/軍官。',
    '入伍新訓': '震撼教育。接受基本教練、體能與戰技訓練，由民轉軍的過渡。',
    '專長訓': '職務專精。學習砲兵、通信、裝甲等兵科專業技能。',
    '部隊歷練': '基層排長。帶領阿兵哥執行任務，學習領導統御。',
    '指參學院進修': '將官搖籃。進修戰略與指揮參謀課程，為晉升更高級職務做準備。',

    // --- GAP FILLING PHASE 8: THE FINAL 135 ---

    // Frontend & Web
    'React/Vue 框架': '同 "React/Vue"。現代前端開發的主流框架(Libraries)，用於構建使用者介面。',
    'RWD 響應式設計': '同 "RWD"。讓網頁能在不同尺寸的裝置上完美呈現的設計方法。',
    'Git 版本控制': '同 "Git"。軟體開發必備的時光機，記錄程式碼的每一次修改。',
    'UI 介面設計': '同 "UI Design"。不僅好用，更要好看。專注於軟體的視覺呈現。',
    'HTML 基礎': '同 "HTML/CSS"。網頁開發的最基本功，建構網頁的骨架。',

    // Backend & Cloud
    '資料庫管理': '同 "Database"。負責資料的儲存、查詢與管理，確保資料安全且高效。',
    'API 設計': '同 "API Design"。定義系統間溝通的介面與規範。',
    'Linux 系統': '同 "Linux"。伺服器端的霸主，工程師必備的作業系統知識。',
    'AWS/GCP 雲端': '同 "AWS/GCP"。使用雲端運算資源來部署與擴展應用程式。',
    'AWS / GCP / Azure': '三大公有雲平台。掌握其中之一即可，概念是大同小異的。',
    'Docker / Kubernetes': '容器化雙雄。Docker 負責打包，Kubernetes 負責管理大規模容器。',
    '網路架構': '了解 Client-Server、CDN、Load Balancer 等網路系統的運作方式。',
    'IaC (Terraform)': 'Infrastructure as Code。用程式碼來管理與部署雲端基礎設施，是現代維運顯學。',
    '網路基礎': '同 "網路基礎知識"。IP, DNS, HTTP 等網際網路運作基石。',
    '雲端平台證照': 'AWS/GCP/Azure 的官方認證，證明你對雲端服務的熟練度。',
    '容器化技術': 'Containerization。將應用程式打包，實現「寫一次，到處跑」的理想。',
    '架構設計模式': 'Design Patterns。解決常見軟體架構問題的最佳實踐經驗總結。',
    '雲端技術': 'Cloud Computing。按需使用運算資源，彈性、靈活且節省成本。',
    'Python/Node.js': '後端開發的熱門語言選擇。',

    // Data & AI
    '資料探勘': 'Data Mining。從大量數據中發現隱藏的模式與關聯。',
    '數學/統計基礎': '微積分、線性代數與機率統計，是 AI 與演算法的基石。',
    '機器學習演算法': '讓電腦從數據中學習規律，而非條列式規則。如決策樹、SVM 等。',
    'NLP/CV 應用': '自然語言處理與電腦視覺。讓電腦聽懂人話、看懂圖片。',
    'MLOps': 'Machine Learning Operations。將機器學習模型從實驗室自動化部署到生產環境。',
    '數據分析': 'Data Analysis。用數據說話，支援商業決策。',
    '統計學': 'Statistics。蒐集、分析、解釋與呈現數據的科學。',
    '數據敏感度': '對數字的直覺。能一眼看出數據異常或趨勢的能力。',
    'Google Analytics 分析': '分析網站流量的來源與使用者行為。',
    '人才數據分析': 'People Analytics。將數據分析應用於人力資源管理，提升組織效能。',

    // Game & Graphics
    'Unity / Unreal Engine': '兩大主流遊戲引擎，從手遊到 3A 大作都能開發。',
    '3D 數學': '向量、矩陣運算。在 3D 空間中移動與旋轉物體的數學基礎。',
    '圖學原理': 'Computer Graphics。渲染管線、光柵化、光線追蹤等底層圖學知識。',
    '程式語言 (C#/C++)': '遊戲開發的核心語言。C# 用於 Unity，C++ 用於 Unreal。',
    '遊戲引擎 (Unity/Unreal)': '掌握遊戲引擎的操作，是成為遊戲開發者的第一步。',
    '3D 數學與物理': '模擬真實世界的物理現象(重力、碰撞)所需的數學知識。',
    '遊戲設計模式': 'Game Design Patterns。針對遊戲開發特有的程式設計模式，如 Component Pattern。',
    '多人連線開發': '處理網路延遲與狀態同步，讓不同玩家能在同個世界互動。',
    'Procreate/PS': '專業繪圖軟體。數位藝術創作的標準工具。',
    '構圖能力': '畫面安排的藝術。決定視覺焦點與動線。',
    '素描': '繪畫基礎。訓練對光影、造型與空間的觀察力。',
    'SketchUp/3ds Max': '3D 建模工具。用於建築與室內設計的立體呈現。',

    // Security & Blockchain
    '網路協定': 'TCP/IP, HTTP/HTTPS。資料在網路上傳輸的規則。',
    '逆向工程': 'Reverse Engineering。拆解程式運作邏輯，常用於惡意程式分析。',
    'Scripting (Python/Bash)': '撰寫腳本自動化執行繁瑣的資安掃描與測試任務。',
    '常見漏洞原理': 'SQL Injection, XSS, CSRF。知己知彼，才能防禦駭客攻擊。',
    '資安證照 (CEH/OSCP)': '白帽駭客的火力證明。CEH 重觀念，OSCP 重實戰。',
    '攻防演練實戰': 'Red Teaming。模擬真實駭客攻擊，檢驗企業的資安防禦能力。',
    '密碼學': 'Cryptography。保護資訊安全的數學技術，如加密、雜湊。',
    '資訊安全': 'Information Security。保護數位資產免受未經授權的存取或破壞。',

    // Design & UX
    'UI 介面設計': 'User Interface Design。創造美觀且直覺的軟體介面。',
    '字體排印': 'Typography。文字的編排藝術，影響閱讀體驗與視覺風格。',
    '排版佈局': 'Layout。有條理地安排畫面元素，引導使用者的視線。',
    '微互動': 'Micro-interactions。按鈕的震動、選單的滑出，提升操作手感的細節。',
    '使用者研究': 'User Research。透過訪談與測試，深入了解使用者真正想要什麼。',
    '線框圖繪製': 'Wireframing。低保真原型。在投入設計前，先確認功能與流程。',
    '邏輯流程': 'Flowchart。規劃使用者在 App 中的操作路徑。',
    '心理學': 'Psychology。理解人類認知與行為模式，設計出符合人性的產品。',
    'Content Marketing': '內容行銷。用有價值的內容吸引潛在客戶。',
    'Video/Photo Editing': '影音剪輯與修圖。',
    'Social Media': '社群媒體經營。',
    'Creativity': '創造力。',

    // Business & Marketing
    '溝通能力': 'Communication。職場最重要的軟實力，準確傳達訊息並理解他人。',
    '風險管理': 'Risk Management。辨識、評估並控制風險，將損害降到最低。',
    '領導力': 'Leadership。激勵團隊達成共同目標的能力。',
    'Google Ads 廣告': '關鍵字廣告投放技巧。',
    'Facebook Ads 廣告': '社群媒體廣告投放技巧。',
    '文案撰寫': 'Copywriting。用文字說服人採取行動。',
    '創意發想': 'Brainstorming。跳脫框架，想出令人耳目一新的點子。',
    '攝影技巧': 'Photography。用鏡頭捕捉動人瞬間。',
    '趨勢敏感度': '掌握當下流行話題與市場脈動。',
    '趨勢分析': 'Trend Analysis。觀察市場數據與社會現象，預測未來流行走向的能力。',
    '關鍵字研究': 'SEO 的起手式。找出高搜尋量且低競爭的關鍵字。',
    '技術 SEO': '優化網站結構與效能，讓搜尋引擎便於爬取。',
    '內容策略': '規劃長期且一緻的內容發布計畫。',
    '連結建設': 'Link Building。增加外部連結，提升網站權威度。',
    '談判技巧': '在利益衝突中尋求共識，達成雙贏局面。',
    '簡報技巧': '清楚、有邏輯且具吸引力地呈現想法。',
    '市場調查': '了解市場需求、競爭者與趨勢。',
    'CRM系統': '客戶關係管理系統。系統化管理客戶資料與互動記錄。',
    '解決問題': 'Problem Solving。分析問題根源並提出有效解決方案。',
    '產品知識': '對自家產品的深入了解，是銷售與服務的基礎。',
    '面試技巧': '在面試中精準判斷候選人的能力與特質。',
    '勞動法令': '勞基法等相關法規。人事管理必須堅守的法律底線。',
    '永續發展': 'ESG。企業追求長期價值，兼顧環境與社會責任。',
    '報告撰寫': '將複雜的資訊轉化為結構清晰的報告。',
    '碳盤查': '計算組織或產品的溫室氣體排放量。',
    '法規研究': '解讀並應用相關法律規範。',
    '寫作能力': '清晰流暢的文字表達。',
    '稽核技巧': '檢查與驗證流程是否符合規範。',
    '業務銷售': 'Sales。開發客戶並促成交易。',
    '品牌策略': 'Brand Strategy。建立品牌獨特價值與定位。',
    '分析能力': 'Analytical Skills。邏輯思考與數據解讀能力。',
    '策略規劃': 'Strategic Planning。制定長遠目標與執行方針。',
    '教育訓練': 'Training。設計並執行培訓計畫，提升員工能力。',

    // Hardware & Science
    '數位電路': 'Digital Circuit。處理 0 與 1 訊號的電子電路。',
    'C 語言': 'C Language。高效能且貼近硬體的程式語言。',
    '組合語言': 'Assembly。直接控制 CPU 的低階語言。',
    'MCU 微控制器': '單晶片。家電、玩具中的微型電腦。',
    '作業系統原理': 'Operating System。管理電腦硬體與軟體資源的核心程式。',
    '電路圖閱讀': '看懂電子電路符號與連接方式。',
    '物理/化學': '基礎科學知識，半導體製程的根基。',
    'SPC 統計製程管制': '利用統計方法監控與改善生產製程。',
    'JMP/Excel 分析': '工程師常用的數據分析工具。',
    '藥理學': '研究藥物與生物體交互作用的科學。',
    '病人照護品質': '以病人為尊，提供安全有效的醫療照護。',
    '細心謹慎': 'Attention to Detail。在醫療與工程領域，魔鬼藏在細節裡。',
    '專業執照': '執業必備的國家證書，如醫師、律師、會計師執照。',
    '分子生物學': '從分子層次研究生命現象。',
    '實驗技術': '操作實驗儀器與執行實驗步驟的能力。',
    '英文閱讀': '閱讀英文文獻與技術手冊的能力。',
    '論文寫作': '撰寫學術論文的能力。',
    'GCP 臨床試驗規範': 'Good Clinical Practice。臨床試驗的倫理與科學標準。',
    '醫學知識': '基礎醫學與臨床醫學知識。',
    '英文能力': '聽說讀寫流利的英語溝通能力。',
    '手術技能': '精準的刀法與外科處置能力。',
    '肌動學': '研究人體動作的力學原理。',
    '生物學': '研究生命的科學。',

    // Education & Service & Others
    '線上教學': '利用視訊軟體進行遠距教學。',
    '科技素養': '熟悉數位工具操作的能力。',
    '工作坊引導': 'Facilitation。引導團體討論與共創。',
    '教練引導': 'Coaching。透過提問啟發他人思考。',
    '危機應變': '面對突發狀況的即時處理能力。',
    '團隊合作': 'Teamwork。與他人協作達成共同目標。',
    '財務分析': '解讀財報，評估企業財務狀況。',
    '品質控管': 'Quality Control。確保產品或服務符合標準。',
    '會計學': '商業世界的語言。',
    'Excel 試算表': '最強大的數據處理軟體。',
    '緊急應變': '火災、地震等災害發生時的處置流程。',
    '文書處理': 'Word, PowerPoint 等報告製作能力。',
    '法律邏輯': 'Legal Reasoning。法律人的思考方式。',
    '批判性思考': 'Critical Thinking。獨立判斷與反思的能力。',
    '資訊安全': 'Information Security。',
    '食品安全': 'Food Safety。確保食品衛生與安全。',
    '情緒穩定': '在壓力下保持冷靜與理智。',
    '體力': 'Physical Stamina。應付長時間或高強度工作的體能。',
    '勇氣': '面對危險毫不退縮的精神。',
    '諮商心理所碩士': '成為心理師的學歷門檻。',
    '諮商心理師高考': '取得心理師執照的國家考試。',
    '愛心耐心': '照顧人或動物必備的特質。',
    '反應能力': '迅速做出正確判斷的能力。',
    '空間規劃': 'Space Planning。合理配置空間機能與動線。',
    '美學素養': 'Esthetics。對美的感知與鑑賞力。',
    '法規條例': '相關法律規範。',
    'Civil/Criminal Law': '民法與刑法。',
    'Logical Thinking': '邏輯思考。'
};

// 3. MBTI Descriptions
const mbtiDescriptions = {
    "INTJ": {
        title: "INTJ 建築師 (Architect)",
        description: "具備戰略眼光的完美主義者。擁有宏觀且長遠的視野，不僅能制定複雜的戰略計畫，更具備將其付諸實行的鋼鐵意志。他們擅長在混亂的局勢中建立秩序，是天生的組織架構師。",
        traits: ["獨立自主", "邏輯縝密", "追求完美"],
        details: {
            traits: "INTJ 是天生的戰略家，擁有極其開闊且深刻的洞見。他們不滿足於表象，總是在尋求事物背後的運作規律。他們是典型的獨立思考者，不輕易接受未經邏輯驗證的論點。在內心深處，INTJ 擁有一個極其複雜且精確的知識地圖，他們會不斷地吸收新知識來修補與完善這個系統。對於他們而言，效率與秩序是至高無上的準則，因此他們對於無效的社交、過度的情緒化或繁瑣的行政流程往往缺乏耐心。他們渴望在專業領域達到頂尖，並喜歡挑戰那些被認為是不可能完成的複雜專案。",
            sw: "優勢：極佳的戰略規劃能力、高度的自信與決斷力、善於解決複雜問題。\n劣勢：容易傲慢與固執、過度理性忽視他人感受、對細節如果不感興趣則會忽略。",
            challenge: "學習「妥協」與「同理」。並非所有事情都需要達到完美的標準，理解並接納他人的情緒，會讓你的領導更具影響力。",
            summary: "INTJ 是冷靜的視覺化思考者，憑藉著鋼鐵般的意志與深邃的邏輯，在混亂中建立秩序，是推動科技與文明演進的核心架構力量。"
        }
    },
    "INTP": {
        title: "INTP 邏輯學家 (Logician)",
        description: "沉浸於理論世界的邏輯學家。對萬物運作背後的原理充滿無盡好奇，熱愛分析複雜系統並找出邏輯漏洞。他們不隨波逐流，總能跳脫既有框架，提出令人驚豔的創新觀點。",
        traits: ["客觀分析", "充滿好奇", "跳脫框架"],
        details: {
            traits: "INTP 是永不停歇的思考機器，他們的大腦就像一個精密運行的真空實驗室，隨時都在進行各種奇特的思想實驗。對於 INTP 來說，發現真理的過程比真理本身更有趣。他們對於「為什麼」的追求近乎偏執，熱衷於解構所有已知的系統，找出其中的邏輯結構與潛在的矛盾。他們是非常客觀的觀察者，傾向於排除個人情感因素來思考問題。雖然在外界看來他們可能有些心不在焉，但那是因為他們的精神正全心全意投入在某個複雜的理論謎題中。他們討厭陳規陋習，是打破傳統、推動範式轉移的天才。",
            sw: "優勢：極具創意的解決問題能力、客觀且開放的思維、擅長抽象思考。\n劣勢：容易陷入分析癱瘓 (Analysis Paralysis)、社交上較為退縮、執行力有時不如思考力。",
            challenge: "將想法「落地」。偉大的理論如果無法實踐，就只是空想。試著設定具體的行動計畫，並練習與他人分享你的洞見。",
            summary: "INTP 是求知若渴的真理追尋者，擁有驚人的抽象分析能力與原創見解，是解決複雜謎題與開拓科學新領域的先行者。"
        }
    },
    "ENTJ": {
        title: "ENTJ 指揮官 (Commander)",
        description: "天生的指揮官與領導者。充滿自信與個人魅力，善於看見長遠的願景與潛在商機。他們能果斷地整合資源、指揮團隊，為了達成目標會不惜一切代價排除萬難。",
        traits: ["果斷", "效率導向", "天生領袖"],
        details: {
            traits: "ENTJ 具有與生俱來的霸氣與掌控欲，他們在群體中總能迅速脫穎而出。他們是卓越的資源整合者，能夠一眼看出團隊中的強項與弱點，並進行最優化的配置。ENTJ 追求卓越與高效，對他們而言，停滯不前就是退步。他們具有強大的戰略眼光，能夠捕捉到未來的趨勢並迅速轉化為可執行的計畫。他們不畏衝突，甚至認為適度的競爭能激發更好的表現。雖然有時給人嚴厲的印象，但他們只是在追求最高標準的成功，並希望身邊的人也能一起進步。",
            sw: "優勢：高效的執行力、長遠的戰略眼光、充滿自信與魅力。\n劣勢：可能顯得冷酷無情、不耐煩、強勢壓迫他人。",
            challenge: "學習「傾聽」。有時候放慢腳步聽聽團隊的聲音，不僅能避免決策盲點，更能贏得人心，讓團隊更願意為你效命。",
            summary: "ENTJ 是天生的戰場指揮官，具備無與倫比的遠見與領導魅力，他們帶領團隊攻城掠地，是商業世界與大型組織中最強大的驅動力。"
        }
    },
    "ENTP": {
        title: "ENTP 辯論家 (Debater)",
        description: "機智敏捷的辯論家。思維跳躍且反應極快，喜歡與人進行智力上的交鋒與激盪。他們不害怕挑戰權威與現狀，勞擅長從多個角度分析問題，常能激發出意想不到的創新點子。",
        traits: ["機智", "創新", "善於應變"],
        details: {
            traits: "ENTP 是大腦中最不安分的自由靈魂，他們以挑戰既有秩序與探索未知邊界為樂。對他們而言，所有的規矩都是拿來打破的，所有的現況都有更好的替代方案。他們反應極其敏銳，能在對談中迅速抓到對方的破綻並予以回擊，這並非惡意，而是他們享受智力較量的過程。ENTP 喜歡廣泛地接觸各種領域，從而產生跨界的奇思妙想。他們是天生的發明家與改革者，對於枯燥重複的工作極度反感。他們需要源源不斷的新奇刺激來餵養其旺盛的創造欲。",
            sw: "優勢：反應極快、適應力強、擅長腦力激盪與創新。\n劣勢：容易喜新厭舊、專注力難以持久、有時會為了辯論而冒犯他人。",
            challenge: "練習「貫徹始終」。創意需要執行才能產生價值。試著專注完成手邊的專案，再開始下一個精彩的冒險。",
            summary: "ENTP 是思維敏捷的腦力激盪大師，熱愛挑戰權威與現狀，他們不竭的創意與應變力，是推動社會創新與技術突破的火種。"
        }
    },
    "INFJ": {
        title: "INFJ 提倡者 (Advocate)",
        description: "神秘且深邃的理想主義者。雖然外表安靜，內心卻擁有堅定的信念與強大的影響力。他們對他人的情感有極深的洞察力，致力於透過溫柔而堅定的方式，為世界帶來正向的改變。",
        traits: ["洞察力強", "具同理心", "堅定信念"],
        details: {
            traits: "INFJ 是靈魂的洞導者，具備極其罕見的直覺能力。他們不滿足於瑣碎的表象，而是致力於挖掘事物背後的終極意義。INFJ 擁有強大的同理心，能夠輕易感受到他人的情緒起伏，這使他們成為溫暖的傾聽者。然而，他們內心其實有一套極其嚴謹且神聖的價值體系，無論外界如何變化，他們都會堅守那份信念。他們渴望透過自己的智慧與影響力，系統性地改善社會問題。對 INFJ 而言，工作必須與生命意義掛鉤，他們追求的是那種能對人類靈魂產生深遠影響的事業。他們外表溫和，但內心擁抱著足以燃燒全世界的變革火種。",
            sw: "優勢：極強的同理心與直覺、堅定的信念、能夠鼓舞人心。\n劣勢：過度敏感、容易燃燒殆盡 (Burnout)、對自我要求過高。",
            challenge: "學會「設限」。你的能量是有限的，無法拯救全世界。適時地設立界線，照顧好自己的內心，才能走得更長遠。",
            summary: "INFJ 是擁有深邃直覺的靈魂守護者，憑藉著溫柔而堅定的信念，在靜默中傳遞出巨大的正能量，是引領人類邁向美好未來的精神燈塔。"
        }
    },
    "INFP": {
        title: "INFP 調停者 (Mediator)",
        description: "充滿詩意與想像力的調停者。內心柔軟且富有同情心，總是能在最黑暗的角落看見希望。他們依循內心的核心價值行事，渴望在工作中找到深層的意義與連結。",
        traits: ["溫柔", "創意豐富", "重視價值"],
        details: {
            traits: "INFP 是漂浮在現實世界中的浪漫詩人，他們擁有極其豐富且斑斕的內心宇宙。對他們來說，感官所見只是表象，真正的真實存在於情感與良知的流動中。INFP 具有極高的道德標準與同理心，他們總能從最微小的生命中看見美麗與希望。他們是非常自由的靈魂，不願意被世俗的標籤或刻板的規則所束縛。雖然平時安靜話不多，但一旦觸及他們的核心價值，便會展現出驚人的執著。他們渴望在藝術、文學或任何能表達真我的媒介中找到歸屬感。他們在尋求的是一種靈魂與世界的終極和諧，是無可救藥的純真守護者。",
            sw: "優勢：豐富的想像力與創造力、對他人真誠關懷、適應力強。\n劣勢：過於理想化、對批評敏感、容易忽視現實面的細節。",
            challenge: "練習「面對現實」。在追求理想的同時，也要兼顧現實的麵包。學習處理衝突與批評，這不是對你的否定，而是成長的養分。",
            summary: "INFP 是善良純粹的理想主義者，擁有天馬行空的想像力與對生命的深沉同理，是守望人間美好價值與藝術靈感的溫柔創作者。"
        }
    },
    "ENFJ": {
        title: "ENFJ 主人公 (Protagonist)",
        description: "魅力十足且激勵人心的主人公。能夠敏銳地察覺他人的潛能與需求，並真誠地渴望幫助他人成長。他們擅長營造團結溫暖的氛圍，是團隊中凝聚人心的核心。",
        traits: ["熱情", "善解人意", "天生領袖"],
        details: {
            traits: "ENFJ 是天生的光源，具有無窮的魅力與感染力。他們最大的快樂來源於看到身邊的人獲得進步。ENFJ 具備極強的社交智慧，能精準洞察他人的需求，並用最鼓舞人心的方式給予協助。他們不仅是優秀的導師，更是強大的組織者。ENFJ 重視人際關係的和諧與集體的福祉，他們擅長在衝突中尋找共識，並帶領團隊朝著更有溫度的目標邁進。他們對社會議題有著極高的關注熱情，總想為群體建立更好的秩序與文化。對他們而言，領導不僅是管理，更是一種神聖的使命感，要帶領眾人走向集體的榮耀。",
            sw: "優勢：極佳的溝通與社交能力、富有同理心、天生的領導魅力。\n劣勢：過度在意他人評價、容易過度承擔他人的問題、難以做出強硬的決策。",
            challenge: "學習「被討厭的勇氣」。為了團隊的長遠發展，有時必須做出不受歡迎的決定。相信你的判斷，不要為了和諧而犧牲原則。",
            summary: "ENFJ 是熱情洋溢的導師型領袖，具備驚人的洞察力與群眾感染力，他們致力於點亮他人的潛能，是團結眾人、共創理想社會的溫暖核心。"
        }
    },
    "ENFP": {
        title: "ENFP 競選者 (Campaigner)",
        description: "熱情洋溢的自由靈魂。將生活視為一場充滿可能性的冒險，擁有極佳的社交能力與感染力。他們總能用樂觀的態度點燃身邊人的熱情，在任何群體中都是大家的開心果。",
        traits: ["充滿活力", "觀察敏銳", "人緣極佳"],
        details: {
            traits: "ENFP 是生命中最耀眼的火花，對世間萬物充滿了近乎孩子般的驚嘆與好奇。他們不喜歡枯燥的重複，而是不斷在生活中尋找新鮮的刺激與未曾開發的可能性。對於 ENFP 而言，世界就像一幅巨大的、未完成的畫布，他們隨時準備畫上新的一筆。他們具有極佳的洞察力，能發現隱藏在平凡生活中的奇蹟。他們是非常真誠的社交者，對於人的本質有強烈的好奇，總能迅速與人建立深厚的情感連結。他們是創意與希望的傳播者，在任何沈悶的環境中都能散發出快樂的光芒。雖然行事有些隨興，但那正是他們追求自由與真實的表現。",
            sw: "優勢：熱情洋溢、極佳的溝通能力、充滿創意與彈性。\n劣勢：專注力不足、容易感到無聊、情緒起伏較大。",
            challenge: "練習「專注力」。世界充滿了誘惑，但成功往往來自於對單一目標的堅持。試著建立規律的生活習慣，幫助你穩定下來。",
            summary: "ENFP 是充滿能量的創意探險家，擁有極致的樂觀與社交魅力，他們不斷打破舊有的疆界，是點燃生活熱情與無限可能性的快樂火種。"
        }
    },
    "ISTJ": {
        title: "ISTJ 物流師 (Logistician)",
        description: "腳踏實地的傳統捍衛者。行事作風條理分明、實事求是，對於承諾絕對信守。他們重視秩序與規則，是組織中維持運作穩定、不可或缺的中流砥柱。",
        traits: ["負責", "注重細節", "腳踏實地"],
        details: {
            traits: "ISTJ 是社會結構中最強大的定海神針。他們對於責任有著近乎神聖的堅持，認為承諾是不可撼動的契約。在行事作風上，ISTJ 崇尚實事求是，他們不相信空洞的口號，只相信經過驗證的數據與經驗。他們的大腦就像一台運作精密的紀錄儀，能捕捉並儲存大量的細節、規則與流程。ISTJ 重視傳統與秩序，他們在建立與維護系統方面具有天賦，確保每一個齒輪都能精確地咬合運轉。雖然外表顯得嚴肅且不苟言笑，但那正是他們全神貫注於任務的表現。他們追求的是一種穩定、可預測且高度誠信的生活與工作環境，是組織內最值得信賴的基石。",
            sw: "優勢：誠實正直、責任感強、做事精確且有效率。\n劣勢：不知變通、對新事物較排斥、容易責怪不守規則的人。",
            challenge: "擁抱「變化」。世界唯一不變的就是變，有時候規則也需要與時俱進。試著對新方法保持開放態度，或許會有意想不到的收穫。",
            summary: "ISTJ 是誠實卓越的秩序捍衛者，擁有一絲不苟的執行力與鋼鐵般的責任感，他們默默守護著社會的運作規則，是百業結構中最穩重的中流砥柱。"
        }
    },
    "ISFJ": {
        title: "ISFJ 守衛者 (Defender)",
        description: "溫暖而專注的守護者。擁有極強的責任感與奉獻精神，雖然個性內向，但對於周遭人的需求觀察入微。他們總是默默地付出，確保每個細節都被照顧得很好。",
        traits: ["體貼", "耐心", "忠誠可靠"],
        details: {
            traits: "ISFJ 是人間最溫暖的守護天使。他們擁有極其敏銳且細膩的觀察力，總能在他人開口之前，就察覺到對方的情緒與需求。ISFJ 不追求鎂光燈，而是享受那種「隱形的服務人」的角色，在幕後默默地打理好一切。他們非常重視和諧與穩定，會為了維護親友或團隊的平靜而做出巨大的自我犧牲。ISFJ 具備驚人的記憶力，能記住每個人微小的偏好與過往的細節，這讓他們的付出顯得格外貼切。他們行事穩健、耐心十足，且對所愛的人、事、物懷有無比的忠誠，是那種在風雨中依然會堅定守在原地、給予溫暖支撐的強大力量。",
            sw: "優勢：支持力強、可靠且有耐心、觀察入微。\n劣勢：過度謙虛、不懂拒絕、容易壓抑自己的情感。",
            challenge: "學習「愛自己」。你的付出值得被看見，也值得被回報。適時地表達自己的需求，學會拒絕不合理的要求，才能走得更長遠。",
            summary: "ISFJ 是謙遜溫柔的平民英雄，擁有極致的責任感與體貼之心，他們在平凡中默默奉獻，是以愛與關懷凝聚人心、維護社會溫度的核心守衛者。"
        }
    },
    "ESTJ": {
        title: "ESTJ 總經理 (Executive)",
        description: "講求效率與秩序的管理者。擅長組織規劃與事務安排，重視規則與傳統價值。他們能夠在混亂的環境中迅速建立秩序，明確分配任務，確保團隊能以最高的效率準確達成目標。",
        traits: ["條理分明", "講求效率", "實事求是"],
        details: {
            traits: "ESTJ 是強大的秩序執行官，他們的核心信仰是：所有的事都應該有明確的規則與高效的處理流程。在他們看來，混亂是最大的資源浪費。ESTJ 具有極佳的組織能力，能迅速將複雜的專案拆解為具體的任務，並明確分配給合適的人選。他們看重事實、實務經驗與社會認可的標準，對於任何天馬行空但缺乏落地可能性的點子往往持保留態度。ESTJ 是意志力極其強大的人，當他們決定推進某項任務時，會用最高標準來要求自己與他人，確保結果如期精確達成。他們不僅是領導者，更是社會規範的忠貞維護者，致力於建立一個高效、透明且公平競爭的穩定系統。",
            sw: "優勢：卓越的組織能力、意志堅定、忠誠且負責。\n劣勢：固執己見、判斷過於武斷、難以放鬆。",
            challenge: "練習「柔軟」。由於你的標準很高，容易給人壓迫感。試著理解每個人的工作方式不同，多一點彈性與包容，會讓團隊氣氛更融洽。",
            summary: "ESTJ 是剛強果敢的領導與管理專家，憑藉著卓越的組織力與明確的規章，在現實世界中建立起高效的堡壘，是確保組織穩步前進的最強悍動力。"
        }
    },
    "ESFJ": {
        title: "ESFJ 執政官 (Consul)",
        description: "極受歡迎的執政官。天生的團隊合作者，非常在意他人的感受與群體和諧。他們擅長透過具體的行動來照顧他人，致力於創造充滿支持與友善的環境。",
        traits: ["熱心助人", "重視和諧", "善於合作"],
        details: {
            traits: "ESFJ 是充滿社交魅力的熱情主人，他們天生就有一種能讓環境變得溫暖和煦的魔力。對於 ESFJ 而言，所有的群體不應該只是工作單位，更應該是充滿情感連結的大家庭。他們非常在意社會規範與群體價值，致力於在社區或團隊中扮演「服務者」的角色。他們非常敏感，能第一時間偵測到團隊氛圍的微妙改變，並迅速伸出援手。ESFJ 具有極高的合作精神與責任感，他們會確保每一個成員都感到被重視、被接納。他們熱衷於參與社區活動，享受那種與人互動、互助所帶來的成就感。對 ESFJ 來說，最美好的世界就是每個人都各盡其職、互相關懷，共同編織出一張充滿安全感與歸屬感的社會網絡。",
            sw: "優勢：責任感強、溫暖且善於社交、重視義務與承諾。\n劣勢：過度尋求認同、對批評非常敏感、容易為了和諧而犧牲真實。",
            challenge: "尋找「自我價值」。你的價值不取決於他人的讚美。試著多花點時間獨處，傾聽自己內心的聲音，找到不依賴他人評價的快樂。",
            summary: "ESFJ 是熱情洋溢的群體連結者，擁抱傳統美德與服務熱忱，他們透過實際行動傳播關愛，是社會共好與社群凝聚力中最穩定、最溫暖的橋樑。"
        }
    },
    "ISTP": {
        title: "ISTP 鑑賞家 (Virtuoso)",
        description: "冷靜理性的鑑賞家。喜歡親自動手操作工具與機械，探索事物的運作原理。擁有靈活的實用主義思維，擅長在緊急狀況下保持冷靜，快速分析問題並提出務實的解決方案。",
        traits: ["冷靜", "動手能力強", "適應力高"],
        details: {
            traits: "ISTP 是極致的實用主義冒險家。他們對世界的好奇心不僅止於理論，更多是來自於「這東西怎麼動」的手感。ISTP 的大腦就像一個隨時準備運作的車間，對於各種工具、系統與機械原理有著驚人的直覺。他們是所有類型中最冷靜的一群，特別是在突如其來的危機面前，當他人還在驚慌時，ISTP 已經在分析數據並尋找最務實的脫困路徑。他們並不排斥風險，反而享受解決具體困難帶來的快感。雖然在社交上顯得內斂且神祕，但那是因為他們將大部分精力都集中在觀察環境與實際操作上。他們崇尚行動，認為與其花兩小時開會，不如花十分鐘把東西修好，是天生的問題解決能手。",
            sw: "優勢：樂觀且充滿活力、擅長應對危機、實作能力強。\n劣勢：難以預測、性格較為孤僻、容易對長期計畫感到厭煩。",
            challenge: "學習「溝通」。你的思維跳躍且行動快速，常讓身邊的人跟不上。試著多解釋你的想法與計畫，讓夥伴能理解並配合你的步調。",
            summary: "ISTP 是冷靜的技術冒險家與實作大師，憑藉著卓越的邏輯與危機處理能力，在關鍵時刻總能化腐朽為神奇，是現代文明中解決複雜技術問題的實戰核心。"
        }
    },
    "ISFP": {
        title: "ISFP 探險家 (Adventurer)",
        description: "靈活多變的藝術家。隨時準備探索新事物，享受當下的每一刻。他們不喜歡被框架束縛，擅長用獨特的美學眼光與實際行動，打破常規並展現自我風格。",
        traits: ["隨和", "審美極佳", "活在當下"],
        details: {
            traits: "ISFP 是世間萬物美感的捕捉者。他們擁有一雙能發現平凡中不凡之美的眼睛，並渴望將這種美透過具體的形式表現出來。對 ISFP 而言，生活本身就是一場無止盡的審美實驗。他們極度重視當下的感受與內心的真誠，不願意為了迎合傳統而扭曲自我。ISFP 非常隨和且謙遜，他們不喜歡競爭，更傾向於建立溫暖和諧的小圈子。他們對於感官體驗（如視覺、聽覺、觸覺）有著超乎常人的敏銳度。雖然平日沈默寡言，但他們的內心充滿了對色彩、線條與情感的熱烈追求。他們是非常溫柔的自由靈魂，總能用謙卑而細膩的方式，為世界增添一抹獨特的藝術色彩。",
            sw: "優勢：極具藝術天份、迷人且隨和、富有想像力。\n劣勢：競爭力較弱、難以制定長期計畫、容易感到壓力。",
            challenge: "建立「自信」。你擁有獨特的天賦與視角，不要害怕展現。試著為自己設定一些小目標並達成它，逐步累積對未來的掌控感。",
            summary: "ISFP 是溫和靈動的感官藝術家，擁有卓越的審美直覺與對真誠的堅持，他們在平凡的生活中編織美好，是為世界妝點詩意與豐富底蘊的溫柔探險家。"
        }
    },
    "ESTP": {
        title: "ESTP 企業家 (Entrepreneur)",
        description: "充滿活力的企業家。活在當下的冒險家，享受解決問題的快感與挑戰。思維敏捷、觀察力強，擅長在變化多端的環境中敏銳地發現機會，並大膽地採取行動。",
        traits: ["大膽", "理性", "社交手腕強"],
        details: {
            traits: "ESTP 是現實世界中最卓越的衝浪手，他們總能在劇烈波動的趨勢中抓到最好的浪頭。他們擁有極其敏銳的感官監測能力，能瞬間捕捉到環境中微細的變化並做出最有利的反應。對於 ESTP 而言，理論是多餘的，唯有行動與結果才是真實的。他們是非常強大的社交者，具備極佳的幽默感與感染力，能在最短時間內贏得團隊的信任與目光。他們熱愛競爭，喜歡解決眼前的挑戰，越是高壓且不確定的環境，越能激發他們的潛能。雖然外表看來很大膽，但其背後通常有著精確的、基於當下事實的判斷力。他們是生命力的極致體現者，是那種敢於打破沈悶、在混亂中開拓新局面的實戰派英雄。",
            sw: "優勢：大膽且直接、觀察力敏銳、極佳的社交手腕。\n劣勢：沒耐心、不喜歡抽象理論、容易忽略潛在風險。",
            challenge: "學習「三思後行」。你的行動力是雙面刃，有時候停下來想一想長遠的後果，可以幫你避開許多不必要的麻煩。",
            summary: "ESTP 是充滿爆發力的行動派與機會捕捉者，具備驚人的適應力與社交智慧，他們大膽開疆闢土，是推動市場變革與解決即時危機的靈魂領航員。"
        }
    },
    "ESFP": {
        title: "ESFP 表演者 (Entertainer)",
        description: "天生的表演者。熱愛聚光燈與掌聲，擁有無與倫比的熱情與美感。他們喜歡與人互動，總是能讓枯燥的工作或生活變得充滿樂趣，是團隊中的開心果。",
        traits: ["熱情", "喜愛社交", "美感極佳"],
        details: {
            traits: "ESFP 是人間最溫暖的陽光，他們生存的意義就是將歡樂與色彩散播給周遭的人。對 ESFP 而言，世界就像一場永不落幕的盛大派對，每個人都應該參與其中並感到快樂。他們具有具備極佳的表演慾與審美眼光，能輕易讓原本死氣沉沉的場合變得生氣盎然。ESFP 是最活在當下的人，他們不喜歡憂慮未知的未來，而是全心全意投入此時此刻的感官饗宴中。他們是非常熱心且直接的社交者，擁有超強的可親性，總能用最自然的方式與人建立連結。雖然有時給人隨興的印象，但他們對夥伴的需求其實非常敏感，總能用各種創意的方式帶給人惊喜。他們是快樂的播種者，致力於讓生活變換成一場充滿美、動感與笑聲的美好旅程。",
            sw: "優勢：大膽且原創、極佳的人際技巧、觀察力強。\n劣勢：容易感到無聊、難以專注、不善於長期規劃。",
            challenge: "培養「紀律」。快樂很重要，但責任感也是。試著在追求樂趣與完成責任之間取得平衡，你會發現生活其實更加充實。",
            summary: "ESFP 是熱情四射的歡樂守護者，兼具獨特的時尚美感與社交魔法，他們不斷點燃生活中的驚喜與笑聲，是維護群體熱度與生命色彩的快樂核心。"
        }
    }
};
