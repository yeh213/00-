// Quiz Data and Logic
// Quiz Data and Logic
// Quiz Data and Logic (Expanded for 20 Types)
// Quiz Questions loaded from data.js

let currentQuestion = 0;
// 20 Roles
let userScores = {
    // Tech
    frontend: 0, backend: 0, mobile: 0, ai: 0, game: 0, cloud: 0, security: 0, devops: 0, qa: 0, blockchain: 0,
    // Hardware
    ic_design: 0, firmware: 0, process: 0,
    // Design
    ui: 0, ux: 0, interior_design: 0, architect: 0, video_editor: 0,
    // Data & PM
    dataanalysis: 0, pm: 0, projectmanager: 0, data_scientist: 0, data_engineer: 0,
    // Marketing
    digitalmarketing: 0, content: 0, seo: 0, pr: 0, brand: 0, creator: 0,
    // Business
    sales: 0, csm: 0, hr: 0, lawyer: 0, ip_specialist: 0,
    // Finance
    investment: 0, financial_advisor: 0, accountant: 0,
    // Medical
    pharmacist: 0, biotech: 0, cra: 0, clinical_psychologist: 0, veterinarian: 0,
    // Education
    elementary_teacher: 0, high_school_teacher: 0, preschool_teacher: 0, tutor: 0, trainer: 0, career_counselor: 0,
    // Service
    hotel_manager: 0, flight_attendant: 0, fnb_manager: 0, pet_groomer: 0,
    // Engineering
    civil_engineer: 0, mechanical_engineer: 0, ehs_engineer: 0,
    // Public & Law
    civil_servant: 0, judge_prosecutor: 0, investigative_officer: 0,
    // Art & Media
    director: 0, illustrator: 0, fashion_designer: 0,
    // Sports & Health
    fitness_coach: 0, physical_therapist: 0, nutritionist: 0,
    // Uniformed
    police_officer: 0, firefighter: 0, military_officer: 0,
    // Impact
    esg: 0, csr: 0, carbon_auditor: 0
};

// Global User History
let userHistory = [];

function startQuiz() {
    currentQuestion = 0;
    userHistory = []; // Reset history
    // Reset all scores
    for (let key in userScores) userScores[key] = 0;
    document.getElementById('result-section').style.display = 'none';
    document.getElementById('quiz-box').style.display = 'block';
    showQuestion();
}

function showQuestion() {
    if (currentQuestion >= quizQuestions.length) {
        showResults();
        return;
    }

    const q = quizQuestions[currentQuestion];
    document.getElementById('question-text').textContent = q.question;

    // Update Stage Title & Progress
    const stageTitle = document.getElementById('stage-title');
    if (stageTitle && q.category) {
        stageTitle.textContent = q.category;
    }

    const progressFill = document.getElementById('progress-fill');
    if (progressFill) {
        const progress = ((currentQuestion + 1) / quizQuestions.length) * 100;
        progressFill.style.width = `${progress}%`;
    }

    const optionsDiv = document.getElementById('options-area');
    optionsDiv.innerHTML = '';

    q.options.forEach((opt, index) => {
        const btn = document.createElement('div');
        btn.className = 'option-btn';
        btn.textContent = opt.text;
        btn.onclick = () => {
            // Track History
            userHistory.push({
                questionIndex: currentQuestion,
                optionIndex: index,
                option: opt
            });

            // Add scores
            for (let key in opt.score) {
                if (userScores.hasOwnProperty(key)) {
                    userScores[key] += opt.score[key];
                }
            }
            currentQuestion++;
            showQuestion();
        };
        optionsDiv.appendChild(btn);
    });
}

// Career Data (20 Types)
// Career Details loaded from data.js


function showResults() {
    document.getElementById('quiz-box').style.display = 'none';
    const resultSection = document.getElementById('result-section');
    const resultContent = document.getElementById('result-content');
    resultSection.style.display = 'block';

    // 1. Sort scores descending
    const sortedScores = Object.entries(userScores)
        .sort(([, a], [, b]) => b - a);

    // 2. Pick top 3 non-zero scores
    const top3 = sortedScores.slice(0, 3).filter(item => item[1] > 0);

    // Fallback if no scores (rare, but possible if user skips everything)
    if (top3.length === 0) {
        // Default fallback
        top3.push(['pm', 1]);
    }

    // Key Mapping (Legacy to Current)
    const keyMapping = {
        'cyber': 'security', 'data': 'dataanalysis', 'pm_prod': 'pm', 'pm_proj': 'projectmanager',
        'mkt_digi': 'digitalmarketing', 'teacher': 'elementary_teacher', 'legal': 'lawyer', 'hardware': 'ic_design'
    };

    console.log("Top 3 Scores:", top3);

    // 3. Get Top 1 Career for Analysis
    const topItem = top3[0];
    const topKeyRaw = topItem[0];
    const topKeyFinal = keyMapping[topKeyRaw] || topKeyRaw;
    const topCareer = careerDetails[topKeyFinal];
    const quizAnalysis = (topCareer && topCareer.quiz_analysis) ? topCareer.quiz_analysis : "根據您的回答，我們為您推薦以下的職涯方向。";

    // 4. Generate HTML
    let html = `
        <h3 style="font-size: 2rem; color: var(--primary-color); margin-bottom: 0.5rem; text-align: center;">🎉 你的職涯探索結果</h3>
        
        <!-- Quiz Analysis Section & History -->
        <div style="background: linear-gradient(135deg, #f0f7ff 0%, #ffffff 100%); padding: 1.5rem; border-radius: 12px; margin: 1.5rem 0 2rem 0; border-left: 5px solid var(--secondary-color); box-shadow: 0 4px 15px rgba(0,0,0,0.05); text-align: left;">
            <h4 style="color: var(--secondary-color); font-size: 1.3rem; margin-bottom: 1rem; display: flex; align-items: center;">
                <span style="font-size: 1.5rem; margin-right: 0.5rem;">💡</span> 測驗分析
            </h4>
            <p style="font-size: 1.1rem; line-height: 1.7; color: #495057; font-weight: 500; margin-bottom: 1.5rem;">
                ${quizAnalysis}
            </p>

            <!-- Answer History Dropdown (Merged) -->
            <details style="margin-top: 1.5rem; border-top: 1px solid rgba(0,0,0,0.1); padding-top: 1rem;">
                <summary style="cursor: pointer; font-weight: bold; color: #666; padding: 0.5rem 0;">📝 回顧你的選擇與分析 (點擊展開)</summary>
                <div style="padding-top: 1rem;">
                    ${userHistory.map((h, i) => {
        const qRaw = quizQuestions[h.questionIndex];
        return `
                            <div style="margin-bottom: 1.5rem; border-bottom: 1px dashed #eee; padding-bottom: 1rem;">
                                <p style="font-weight: bold; color: #333; margin-bottom: 0.5rem;">${qRaw.question}</p>
                                <p style="color: var(--primary-color); margin-bottom: 0.5rem;">✅ ${h.option.text}</p>
                                <p style="font-size: 0.9rem; color: #666; font-style: italic; background: rgba(255,255,255,0.6); padding: 6px 10px; border-radius: 4px; display: inline-block; border: 1px solid #eee;">
                                    💬 ${h.option.analysis || "很好的選擇！"}
                                </p>
                            </div>
                        `;
    }).join('')}

                    <!-- Total Score Table -->
                    <div style="margin-top: 2rem; border-top: 2px dashed #ddd; padding-top: 1.5rem;">
                        <h5 style="color: #333; margin-bottom: 1rem;">📊 完整得分表</h5>
                        <div style="overflow-x: auto;">
                            <table style="width: 100%; border-collapse: collapse; font-size: 0.9rem;">
                                <thead>
                                    <tr style="background: #f8f9fa;">
                                        <th style="padding: 8px; text-align: left; border-bottom: 2px solid #ddd;">排名</th>
                                        <th style="padding: 8px; text-align: left; border-bottom: 2px solid #ddd;">職位名稱</th>
                                        <th style="padding: 8px; text-align: center; border-bottom: 2px solid #ddd;">總分</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${sortedScores.map((item, index) => {
        const key = item[0];
        const score = item[1];
        const career = careerDetails[keyMapping[key] || key];
        const title = career ? career.title : key;
        const rank = index + 1;
        const rowStyle = index < 3 ? "background: #fff8e1; font-weight: bold;" : "";
        return `
                                            <tr style="border-bottom: 1px solid #eee; ${rowStyle}">
                                                <td style="padding: 8px;">#${rank}</td>
                                                <td style="padding: 8px;">${title}</td>
                                                <td style="padding: 8px; text-align: center;">${score}</td>
                                            </tr>
                                        `;
    }).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </details>
        </div>

        <p style="text-align: center; color: #666; margin-bottom: 2rem;">根據你的選擇，我們為你推薦以下最適合的 3 個職位：</p>
        <div style="display: flex; flex-direction: column; gap: 2rem;">
    `;

    // Helper: Determine Category Key for Filter
    function getCategoryKey(key) {
        if (['frontend', 'backend', 'mobile', 'ai', 'game', 'cloud', 'security', 'devops', 'qa', 'blockchain'].includes(key)) return 'tech';
        if (['ic_design', 'firmware', 'process', 'hardware_rd', 'equipment'].includes(key)) return 'hardware';
        if (['ui', 'ux', 'product_design', 'graphic', 'motion', 'interior_design', 'fashion_designer'].includes(key)) return 'design';
        if (['dataanalysis', 'pm', 'projectmanager', 'data_scientist', 'data_engineer'].includes(key)) return 'data';
        if (['digitalmarketing', 'content', 'seo', 'pr', 'brand', 'growth', 'community', 'creator'].includes(key)) return 'marketing';
        if (['sales', 'csm', 'hr', 'bd', 'legal', 'admin', 'recruiter', 'lawyer', 'ip_specialist'].includes(key)) return 'business';
        if (['investment', 'financial_advisor', 'accountant', 'procurement'].includes(key)) return 'finance';
        if (['pharmacist', 'biotech', 'cra', 'nurse', 'doctor', 'clinical_psychologist', 'veterinarian'].includes(key)) return 'medical';
        if (['tutor', 'trainer', 'career_counselor', 'elementary_teacher', 'high_school_teacher', 'preschool_teacher'].includes(key)) return 'education';
        if (['hotel_manager', 'flight_attendant', 'fnb_manager', 'tour_guide', 'pet_groomer'].includes(key)) return 'service';
        if (['esg', 'csr', 'carbon_auditor'].includes(key)) return 'impact';
        if (['civil_engineer', 'mechanical_engineer', 'ehs_engineer', 'architect'].includes(key)) return 'engineering';
        if (['civil_servant', 'judge_prosecutor', 'investigative_officer'].includes(key)) return 'public';
        if (['director', 'illustrator', 'video_editor'].includes(key)) return 'art';
        if (['fitness_coach', 'physical_therapist', 'nutritionist'].includes(key)) return 'health';
        if (['police_officer', 'firefighter', 'military_officer'].includes(key)) return 'uniformed';
        return 'all'; // Default
    }

    top3.forEach((item, index) => {
        const rawKey = item[0];
        const score = item[1];
        const finalKey = keyMapping[rawKey] || rawKey;
        const result = careerDetails[finalKey];
        const categoryKey = getCategoryKey(finalKey);

        if (!result) return;

        // Rank Badge
        let rankBadge = '';
        if (index === 0) rankBadge = '🥇 第一推薦';
        if (index === 1) rankBadge = '🥈 第二推薦';
        if (index === 2) rankBadge = '🥉 第三推薦';

        // Card HTML (Super Simplified)
        html += `
            <div class="result-card glass" style="padding: 1.5rem; border-left: 5px solid var(--secondary-color); position: relative; margin-bottom: 1.5rem; text-align: center;">
                <div style="background: var(--secondary-color); color: white; padding: 0.2rem 0.8rem; border-radius: 20px; font-size: 0.8rem; display: inline-block; margin-bottom: 0.5rem;">${rankBadge}</div>
                
                <h3 style="font-size: 1.5rem; color: var(--primary-color); margin-bottom: 0.5rem;">${result.title}</h3>
                <p style="font-size: 1rem; line-height: 1.5; margin-bottom: 0.8rem; color: #555;">${result.description}</p>
                <p style="font-size: 0.9rem; color: #6c757d; margin-bottom: 1.2rem; background: #f8f9fa; display: inline-block; padding: 4px 10px; border-radius: 6px; border: 1px solid #e9ecef;">🧠 適合特質 (MBTI)：${result.mbti || 'N/A'}</p>
                
                <div style="text-align: center;">
                    <a href="careers.html" onclick="sessionStorage.setItem('filter', '${categoryKey}')" class="btn-primary" style="padding: 0.5rem 1.2rem; font-size: 0.9rem;">
                        查看完整職缺介紹 ➝
                    </a>
                </div>
            </div>
        `;
    });

    html += `</div>`; // Close container

    html += `
        <div style="text-align: center; margin-top: 3rem;">
            <button onclick="startQuiz()" class="btn-secondary" style="margin-right: 1rem;">↩️ 再測一次</button>
            <a href="careers.html" class="btn-primary">🔍 查看所有職缺</a>
        </div>
    `;

    resultContent.innerHTML = html;
}



// Companies Modal Logic & Rendering
// Company Data loaded from data.js

function initCompanies() {
    const container = document.getElementById('company-container');
    if (!container) return; // Not on companies page

    container.innerHTML = ''; // Clear container

    // Icon Mapping (Simple mapping for emoji logos)
    const iconMap = {
        'tsmc': '🏭',
        'starbucks': '☕',
        'patagonia': '🏔️',
        'google': '🔍',
        'ikea': '🪑',
        'you': '🚀'
    };

    for (const [key, data] of Object.entries(companyData)) {
        const card = document.createElement('div');
        card.className = 'company-card';
        card.onclick = () => openModal(key);

        // Render Tags
        card.innerHTML = `
    <div class="company-logo">${iconMap[key] || '🏢'}</div>
        <h3 class="company-title">${data.title}</h3>
`;
        container.appendChild(card);
    }
}

function openModal(id) {
    const data = companyData[id];
    if (!data) return;

    const modal = document.getElementById('modal');
    /* modal.classList.remove('stats-modal'); removed */
    const modalTitle = document.getElementById('modal-title');

    // Dynamic Positioning
    const scrollY = window.scrollY || document.documentElement.scrollTop;
    const viewHeight = window.innerHeight;
    // Aim for center: ScrollTop + (ViewHeight / 2) - ApproxHalfModalHeight (e.g. 200px)
    // But ensure at least some margin from top
    const targetTop = Math.max(scrollY + (viewHeight * 0.1), scrollY + 50);
    modal.style.paddingTop = targetTop + 'px';
    const modalBody = document.getElementById('modal-body');

    // Ensure main title is hidden or empty for Company Modal (we use internal title)
    if (modalTitle) {
        modalTitle.innerText = '';
        modalTitle.style.display = 'none';
    }

    // Reset Content
    modalBody.innerHTML = '';

    // Header
    modalBody.innerHTML += `<h2 class="modal-title-large">${data.title}</h2>`;

    // Metrics Grid
    if (data.keyMetrics) {
        let metricsHtml = '<div class="metrics-grid">';
        data.keyMetrics.forEach(m => {
            metricsHtml += `
    <div class="metric-item">
                    <span class="metric-value">${m.value}</span>
                    <span class="metric-label">${m.label}</span>
                </div>
    `;
        });
        metricsHtml += '</div>';
        modalBody.innerHTML += metricsHtml;
    }

    // Description Content
    modalBody.innerHTML += `<div style="line-height: 1.8; color: #444; margin-bottom: 2rem;">${data.content}</div>`;

    // Actions
    let actionsHtml = '<div class="modal-actions">';

    // ESG Report Button
    if (data.reportUrl && data.reportUrl !== '#') {
        actionsHtml += `
    <a href="${data.reportUrl}" target="_blank" class="btn-secondary">
                📄 閱讀 ESG 報告書
            </a>
    `;
    }

    // Related Jobs Button
    if (data.relatedCategory) {
        if (data.relatedCategory === 'all') {
            actionsHtml += `
    <a href="careers.html" class="btn-primary">
                    💼 建立你的未來
                </a>
    `;
        } else {
            actionsHtml += `
    <a href="careers.html" onclick="sessionStorage.setItem('filter', '${data.relatedCategory}')" class="btn-primary">
                    💼 查看相關職缺(${data.relatedCategory})
                </a>
    `;
        }
    }

    actionsHtml += '</div>';
    modalBody.innerHTML += actionsHtml;

    // Show Modal with Animation
    modal.style.display = 'flex';
    // Small delay to allow display flex to apply before opacity transition
    setTimeout(() => {
        modal.classList.add('show');
    }, 10);
}

function openStatModal(key) {
    const data = sdgStatsData[key];
    if (!data) {
        console.error("Data not found for key:", key);
        return;
    }

    const modal = document.getElementById('modal');
    const modalTitle = document.getElementById('modal-title');
    const modalBody = document.getElementById('modal-body');

    if (!modal || !modalTitle || !modalBody) {
        console.error("Modal elements not found!");
        return;
    }

    modalTitle.style.display = 'block'; // Ensure it's visible for Stats
    modalTitle.innerText = data.title;
    modalBody.innerHTML = `
    <div style="font-size: 1.1rem; line-height: 1.8; color: #444;">
        ${data.content}
        </div>
    <div style="margin-top: 2rem; text-align: right;">
        <a href="${data.link}" target="_blank" class="btn-secondary" style="font-size: 0.9rem;">
            🔗 閱讀原始報告 (${data.source})
        </a>
    </div>
`;

    /* modal.classList.add('stats-modal'); removed */

    // Dynamic Positioning
    const scrollY = window.scrollY || document.documentElement.scrollTop;
    const viewHeight = window.innerHeight;
    const targetTop = Math.max(scrollY + (viewHeight * 0.15), scrollY + 50);
    modal.style.paddingTop = targetTop + 'px';

    modal.style.display = 'flex';
    setTimeout(() => {
        modal.classList.add('show');
    }, 10);
}

function closeModal() {
    const modal = document.getElementById('modal');
    modal.classList.remove('show');
    setTimeout(() => {
        modal.style.display = 'none';
        modal.style.paddingTop = '0'; // Reset
        /* modal.classList.remove('stats-modal'); removed */
    }, 300); // Wait for transition
}

// Close modal when clicking outside
window.onclick = function (event) {
    const modal = document.getElementById('modal');
    if (event.target == modal) {
        closeModal();
    }
}

// Run init if on companies page
if (document.getElementById('company-container')) {
    initCompanies();
}


// SDG Carousel Logic
// SDG Slides loaded from data.js

let currentSlide = 0;
let slideInterval;

function initCarousel() {
    const container = document.getElementById('sdg-carousel');
    const indicatorContainer = document.getElementById('sdg-indicators');
    if (!container) return; // Not on homepage

    // Create Slides
    sdgSlides.forEach((slide, index) => {
        const slideDiv = document.createElement('div');
        slideDiv.className = `sdg-slide ${index === 0 ? 'active' : ''} `;
        slideDiv.innerHTML = `
    <div style="font-size: 4rem; margin-bottom: 1.5rem;">${slide.icon}</div>
            <h2 class="sdg-title" style="margin-bottom: 1rem; font-size: 2rem;">${slide.title}</h2>
            <p class="sdg-desc" style="font-size: 1.15rem; max-width: 800px; line-height: 1.8;">${slide.desc}</p>
`;
        container.appendChild(slideDiv);

        // Create Indicators
        const dot = document.createElement('div');
        dot.className = `dot ${index === 0 ? 'active' : ''} `;
        dot.onclick = () => manualSwitchSlide(index);
        indicatorContainer.appendChild(dot);
    });

    startCarousel();
}

function showSlide(index) {
    const slides = document.querySelectorAll('.sdg-slide');
    const dots = document.querySelectorAll('.dot');

    slides.forEach(s => s.classList.remove('active'));
    dots.forEach(d => d.classList.remove('active'));

    currentSlide = (index + slides.length) % slides.length;

    slides[currentSlide].classList.add('active');
    dots[currentSlide].classList.add('active');
}

function startCarousel() {
    slideInterval = setInterval(() => {
        showSlide(currentSlide + 1);
    }, 5000);
}

function manualSwitchSlide(index) {
    clearInterval(slideInterval);
    showSlide(index);
    startCarousel(); // Restart timer
}


// Initialize if on homepage
if (document.getElementById('sdg-carousel')) {
    initCarousel();
}

// ---------------------------------------------------------
// Careers Page Logic (Filtering & Rendering)
// ---------------------------------------------------------

function initCareers() {
    const container = document.getElementById('roles-container');
    if (!container) return; // Not on careers page

    // Check for saved filter from other pages (e.g., from Companies modal)
    const savedFilter = sessionStorage.getItem('filter');
    const initialFilter = savedFilter || 'all';

    // Clear session storage so it doesn't persist forever
    if (savedFilter) sessionStorage.removeItem('filter');

    // Initial Render
    // Initial Render
    const categorySelect = document.getElementById('category-filter');
    const mbtiSelect = document.getElementById('mbti-filter');

    if (categorySelect) {
        // Set initial value
        if ([...categorySelect.options].some(o => o.value === initialFilter)) {
            categorySelect.value = initialFilter;
        } else {
            categorySelect.value = 'all';
        }

        // Initial Render
        renderCareers(categorySelect.value);

        // Change Listener
        categorySelect.addEventListener('change', () => {
            renderCareers(categorySelect.value);
        });
    }

    if (mbtiSelect) {
        mbtiSelect.addEventListener('change', () => {
            // Get current active category filter
            const currentCategoryFilter = categorySelect ? categorySelect.value : 'all';
            renderCareers(currentCategoryFilter);

            // Update MBTI Info Box
            const infoBox = document.getElementById('mbti-info-box');
            const mbtiDetail = mbtiDescriptions[mbtiSelect.value];

            if (mbtiSelect.value !== 'all' && mbtiDetail && infoBox) {
                document.getElementById('mbti-title').innerText = mbtiDetail.title;
                document.getElementById('mbti-desc').innerText = mbtiDetail.description;
                // Render Traits
                document.getElementById('mbti-traits').innerHTML = mbtiDetail.traits.map(t =>
                    `<span style="background:var(--bg-color); padding:4px 10px; border-radius:20px; border:1px solid #e0e0e0; font-size:0.9rem; color:#666;">#${t}</span>`
                ).join('');

                // Render Deep Analysis Dropdown
                const existingDetails = document.getElementById('mbti-deep-analysis');
                if (existingDetails) existingDetails.remove();

                if (mbtiDetail.details) {
                    const detailsHtml = `
                        <details id="mbti-deep-analysis" style="margin-top: 1.5rem; border-top: 1px solid #eee; padding-top: 1rem;">
                            <summary style="cursor: pointer; color: var(--primary-color); font-weight: bold; list-style: none;">🔍 深度解析：核心特質、優劣勢與挑戰 (點擊展開)</summary>
                            <div style="margin-top: 1rem; padding-left: 1rem; border-left: 3px solid #eee;">
                                <div style="margin-bottom: 1rem;">
                                    <strong>💎 核心特質：</strong>
                                    <p style="margin-top: 0.5rem; white-space: pre-line; color: #555;">${mbtiDetail.details.traits}</p>
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <strong>⚔️ 優勢與劣勢：</strong>
                                    <p style="margin-top: 0.5rem; white-space: pre-line; color: #555;">${mbtiDetail.details.sw}</p>
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <strong>🏔️ 面臨的挑戰：</strong>
                                    <p style="margin-top: 0.5rem; white-space: pre-line; color: #555;">${mbtiDetail.details.challenge}</p>
                                </div>
                                ${mbtiDetail.details.summary ? `
                                <div style="margin-top: 1.5rem; padding: 1rem; background: var(--secondary-color); color: white; border-radius: 8px; font-weight: 500; line-height: 1.6;">
                                    ✨ 總結：${mbtiDetail.details.summary}
                                </div>` : ''}
                            </div>
                        </details>
                    `;
                    document.getElementById('mbti-traits').insertAdjacentHTML('afterend', detailsHtml);
                }

                infoBox.style.display = 'block';
            } else {
                if (infoBox) infoBox.style.display = 'none';
            }
        });
    }
}

function renderCareers(filter) {
    const container = document.getElementById('roles-container');
    if (!container) return;
    container.innerHTML = ''; // Clear current

    const mbtiFilterSelect = document.getElementById('mbti-filter');
    const mbtiTarget = mbtiFilterSelect ? mbtiFilterSelect.value : 'all';

    // Safety check if renderCareers called without arg
    if (!filter) {
        const catSelect = document.getElementById('category-filter');
        filter = catSelect ? catSelect.value : 'all';
    }

    let matchCount = 0;

    for (const [key, role] of Object.entries(careerDetails)) {
        // Determine category
        let categoryKey = 'other';
        let categoryLabel = 'General';

        if (['frontend', 'backend', 'mobile', 'ai', 'game', 'cloud', 'security', 'devops', 'qa', 'blockchain'].includes(key)) {
            categoryKey = 'tech';
            categoryLabel = "💻 軟體 (Software)";
        } else if (['ic_design', 'firmware', 'process', 'hardware_rd', 'equipment'].includes(key)) {
            categoryKey = 'hardware';
            categoryLabel = "🛠️ 硬體 (Hardware)";
        } else if (['ui', 'ux', 'product_design', 'graphic', 'motion', 'interior_design', 'fashion_designer'].includes(key)) {
            categoryKey = 'design';
            categoryLabel = "🎨 設計 (Design)";
        } else if (['dataanalysis', 'pm', 'projectmanager', 'data_scientist', 'data_engineer'].includes(key)) {
            categoryKey = 'data';
            categoryLabel = "📊 數據 & PM";
        } else if (['digitalmarketing', 'content', 'seo', 'pr', 'brand', 'growth', 'community', 'creator'].includes(key)) {
            categoryKey = 'marketing';
            categoryLabel = "📣 行銷 (Marketing)";
        } else if (['sales', 'csm', 'hr', 'bd', 'legal', 'admin', 'recruiter', 'lawyer', 'ip_specialist'].includes(key)) {
            categoryKey = 'business';
            categoryLabel = "💼 商業 (Business)";
        } else if (['investment', 'financial_advisor', 'accountant', 'procurement'].includes(key)) {
            categoryKey = 'finance';
            categoryLabel = "💰 金融 (Finance)";
        } else if (['pharmacist', 'biotech', 'cra', 'nurse', 'doctor', 'clinical_psychologist', 'veterinarian', 'physical_therapist', 'nutritionist'].includes(key)) {
            categoryKey = 'medical';
            categoryLabel = "🏥 醫藥 (Medical)";
        } else if (['tutor', 'trainer', 'career_counselor', 'elementary_teacher', 'high_school_teacher', 'preschool_teacher'].includes(key)) {
            categoryKey = 'education';
            categoryLabel = "🎓 教育 (Education)";
        } else if (['hotel_manager', 'flight_attendant', 'fnb_manager', 'tour_guide', 'pet_groomer'].includes(key)) {
            categoryKey = 'service';
            categoryLabel = "🤝 服務 (Service)";
        } else if (['esg', 'csr', 'carbon_auditor'].includes(key)) {
            categoryKey = 'impact';
            categoryLabel = "🌿 永續 (Impact)";
        } else if (['civil_engineer', 'mechanical_engineer', 'ehs_engineer', 'architect'].includes(key)) {
            categoryKey = 'engineering';
            categoryLabel = "🏗️ 工程 (Engineering)";
        } else if (['civil_servant', 'judge_prosecutor', 'investigative_officer'].includes(key)) {
            categoryKey = 'public';
            categoryLabel = "⚖️ 公職 (Public)";
        } else if (['director', 'illustrator', 'video_editor'].includes(key)) {
            categoryKey = 'art';
            categoryLabel = "🎬 藝術 (Art)";

        } else if (['police_officer', 'firefighter', 'military_officer'].includes(key)) {
            categoryKey = 'uniformed';
            categoryLabel = "👮 軍警消 (Services)";
        }

        // Apply Category Filter
        if (filter !== 'all' && categoryKey !== filter) {
            continue;
        }

        // Apply MBTI Filter
        if (mbtiTarget !== 'all') {
            const roleMbti = role.mbti || '';
            if (!roleMbti.includes(mbtiTarget)) {
                continue;
            }
        }

        // Create Roadmap HTML
        const roadmapHtml = (role.roadmap && role.roadmap.length > 0) ? `
    <div class="role-roadmap">
                <span class="roadmap-label">🚀 學習路徑：</span>
                <div class="roadmap-steps">
                    ${role.roadmap.map((step, i) => `
                        <div class="roadmap-step" onclick="openSkillModal('${step}')" style="cursor:pointer;">
                            <span class="step-num">${i + 1}</span>
                            <span class="step-text" style="border-bottom: 1px dashed #666;">${step}</span>
                        </div>
                    `).join('<div class="step-arrow">↓</div>')}
                </div>
            </div>
    ` : '';

        // Render Card
        const card = document.createElement('div');
        card.className = 'role-card glass';
        // Add animation class for fade in
        card.style.animation = 'fadeIn 0.5s ease forwards';

        // Role Icons Map (Cute & Descriptive)
        const roleIcons = {
            // Tech
            'frontend': '👨‍💻', 'backend': '⚙️', 'mobile': '📱', 'ai': '🧠', 'game': '🎮', 'cloud': '☁️', 'security': '🛡️',
            'devops': '🏗️', 'qa': '🐞', 'blockchain': '⛓️',

            // Hardware
            'ic_design': '💾', 'firmware': '🤖', 'process': '🏭',

            // Design
            'ui': '🎨', 'ux': '🔍', 'interior_design': '🛋️', 'architect': '🏛️', 'video_editor': '🎬',

            // Data & PM
            'dataanalysis': '📈', 'pm': '📝', 'projectmanager': '🗓️',
            'data_scientist': '🧪', 'data_engineer': '🧱', // (Added proactively if keys exist, safe to keep)

            // Marketing
            'digitalmarketing': '📢', 'content': '✍️', 'seo': '🔎',
            'pr': '🎤', 'brand': '✨', 'creator': '📸',

            // Business
            'sales': '🤝', 'csm': '❤️', 'hr': '👥', 'lawyer': '⚖️', 'ip_specialist': '®️',

            // Finance
            'investment': '📉', 'financial_advisor': '💰', 'accountant': '🧮',

            // Medical
            'pharmacist': '💊', 'biotech': '🧬', 'cra': '📋', 'nurse': '👩‍⚕️', 'doctor': '👨‍⚕️', 'clinical_psychologist': '🧠', 'veterinarian': '🐾',

            // Education
            'elementary_teacher': '🎒', 'high_school_teacher': '📚', 'preschool_teacher': '🧸', 'tutor': '💻', 'trainer': '👨‍🏫', 'career_counselor': '🧭',

            // Service
            'hotel_manager': '🏨', 'flight_attendant': '✈️', 'fnb_manager': '🍷', 'tour_guide': '🗺️', 'pet_groomer': '🐩',

            // Impact
            'esg': '🌍', 'csr': '🌱', 'carbon_auditor': '🔎',

            // New Phase 2 Icons
            'civil_engineer': '👷', 'mechanical_engineer': '⚙️', 'ehs_engineer': '⛑️',
            'civil_servant': '🏢', 'judge_prosecutor': '⚖️', 'investigative_officer': '🕵️',
            'director': '🎬', 'illustrator': '🎨', 'fashion_designer': '👗',
            'fitness_coach': '💪', 'physical_therapist': '🏥', 'nutritionist': '🥗',
            'police_officer': '👮', 'firefighter': '🚒', 'military_officer': '🪖'
        };

        card.innerHTML = `
    <span class="role-category">${categoryLabel}</span>
            <div class="role-header" style="display:flex; align-items:center; gap:10px; margin-top:10px;">
                <div class="role-icon" style="font-size:2rem;">${roleIcons[key] || '💼'}</div>
                <div>
                    <h3 class="role-title" style="margin:0;">${role.title.split(' (')[0]}</h3>
                    <div style="font-size: 0.9rem; color: #888; margin-top: 0.2rem;">${role.title.split(' (')[1].replace(')', '')}</div>
                </div>
            </div>
            
            <p class="role-desc" style="margin-top:1rem;">${role.description}</p>
            <p style="font-size: 0.9rem; color: #6c757d; margin-bottom: 0.5rem; background: #f8f9fa; display: inline-block; padding: 4px 10px; border-radius: 6px; border: 1px solid #e9ecef;">🧠 適合特質 (MBTI)：${role.mbti || 'N/A'}</p>
            
            <div role="separator" style="height:1px; background:rgba(0,0,0,0.05); margin:1rem 0;"></div>

            ${roadmapHtml}

            <div class="role-stats" style="margin-top:1rem; font-size:0.9rem; color:#555;">
                <div style="margin-bottom:0.5rem;"><strong>💰 月薪範圍:</strong> 學士 ${role.salary.bachelor} / 碩士 ${role.salary.master}</div>
            </div>

            <div class="role-tags" style="margin-top:1rem;">
                <span style="width:100%; font-size:0.9rem; color:#555; margin-bottom:0.2rem;"><strong>🛠️ 關鍵技能:</strong></span>
                ${role.skills.slice(0, 4).map(skill => `<span class="role-tag" onclick="openSkillModal('${skill}')" style="cursor:pointer;">${skill}</span>`).join('')}
            </div>
`;
        container.appendChild(card);
        matchCount++;
    }

    // No Matches Found
    if (matchCount === 0) {
        container.innerHTML = `
            <div style="grid-column: 1 / -1; text-align: center; padding: 4rem 2rem; background: var(--glass-bg); border-radius: 20px; border: 2px dashed var(--secondary-color);">
                <div style="font-size: 3rem; margin-bottom: 1rem;">🤷‍♂️</div>
                <h3 style="font-size: 1.5rem; margin-bottom: 0.5rem; color: var(--primary-color);">Oops! 目前沒有完全符合這兩個條件的職缺</h3>
                <p style="color: #666; font-size: 1.1rem; margin-bottom: 2rem;">可能是篩選條件太嚴格了，嘗試放寬一點條件吧？</p>
                <div style="display: flex; gap: 15px; justify-content: center;">
                    <button onclick="resetCareersFilter()" class="btn-secondary" style="padding: 0.6rem 1.5rem;">🔄 清除篩選條件</button>
                    <a href="quiz.html" class="btn-primary" style="padding: 0.6rem 1.5rem;">📝 不確定？來做職涯測驗</a>
                </div>
            </div>
        `;
    }
}

function resetCareersFilter() {
    const categorySelect = document.getElementById('category-filter');
    const mbtiSelect = document.getElementById('mbti-filter');

    if (categorySelect) categorySelect.value = 'all';
    if (mbtiSelect) mbtiSelect.value = 'all';

    const infoBox = document.getElementById('mbti-info-box');
    if (infoBox) infoBox.style.display = 'none';

    renderCareers('all');
}



function openSkillModal(skillName) {
    const description = skillGlossary[skillName] || "目前尚無此技能的詳細介紹，我們會盡快補充！";
    const modal = document.getElementById('modal');
    const modalBody = document.getElementById('modal-body');
    const modalTitle = document.getElementById('modal-title');

    // Use the main title element
    if (modalTitle) {
        modalTitle.innerText = skillName;
        modalTitle.style.display = 'block';
        modalTitle.style.color = 'var(--primary-color)';
    }

    modalBody.innerHTML = `
        <div style="line-height: 1.8; color: #444; font-size: 1.1rem;">
            ${description}
        </div>
        <div style="margin-top: 2rem; text-align: right;">
             <button onclick="closeModal()" class="btn-primary" style="padding: 0.5rem 1.5rem;">了解</button>
        </div>
    `;

    // Show Modal
    const scrollY = window.scrollY || document.documentElement.scrollTop;
    const viewHeight = window.innerHeight;
    const targetTop = Math.max(scrollY + (viewHeight * 0.15), scrollY + 50);
    modal.style.paddingTop = targetTop + 'px';

    modal.style.display = 'flex';
    setTimeout(() => {
        modal.classList.add('show');
    }, 10);
}

// Run init if on careers page
if (document.getElementById('roles-container')) {
    initCareers();
}

// ---------------------------------------------------------
// Mobile Menu Logic
// ---------------------------------------------------------
const mobileMenu = document.getElementById('mobile-menu');
const navLinks = document.querySelector('.nav-links');

if (mobileMenu && navLinks) {
    mobileMenu.addEventListener('click', () => {
        mobileMenu.classList.toggle('is-active');
        navLinks.classList.toggle('active');
    });
}

// ---------------------------------------------------------
// Theme Toggle Logic (Dark Mode)
// ---------------------------------------------------------
const themeToggle = document.getElementById('theme-toggle');
const body = document.body;
// Check if user has a saved preference, otherwise default to light
const currentTheme = localStorage.getItem('theme');

// Apply saved theme on load
if (currentTheme === 'dark') {
    body.classList.add('dark-mode');
    if (themeToggle) themeToggle.textContent = '☀️';
} else {
    // If no preference, ensure light mode default
    if (themeToggle) themeToggle.textContent = '🌙';
}

if (themeToggle) {
    themeToggle.addEventListener('click', () => {
        body.classList.toggle('dark-mode');

        if (body.classList.contains('dark-mode')) {
            themeToggle.textContent = '☀️'; // Switch to Sun
            localStorage.setItem('theme', 'dark');
        } else {
            themeToggle.textContent = '🌙'; // Switch to Moon
            localStorage.setItem('theme', 'light');
        }
    });
}
